const initialState = {
	city: [],
	airline: [],
	flights: [],
	booking: [],
	finalbook: [],
};

const Reducer = (state = initialState, action) => {
	console.log("to update", state, action);

	switch (action.type) {
		case "ADD_CITY":
			const cities = action.cities;
			return {
				...state,
				city: [...state.city, cities],
			};

		case "ADD_AIRLINE":
			// const airlines = action.airlines;
			return {
				...state,
				airline: [...state.airline, action],
			};
		case "ADD_FLIGHTS":
			console.log(action, "action coming");
			return {
				...state,
				flights: [...state.flights, action],
			};
		case "BOOK_TICKET":
			return {
				...state,
				boooking: [...state.booking, action],
			};
		// case "FINAL_BOOK_TICKET":
		// 	return {
		// 		...state,

		// 	};

		default:
			return state;
	}
};
export default Reducer;
