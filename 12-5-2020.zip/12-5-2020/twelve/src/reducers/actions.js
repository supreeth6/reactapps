export const addcity = (actionType, cities) => {
	console.log(cities);
	return {
		type: actionType,
		cities: cities,
	};
};

export const addAirline = (actionType, airlines) => {
	console.log(airlines);
	return {
		type: actionType,
		airlines: airlines,
	};
};
export const addflights = (actionType, flights) => {
	console.log(flights);
	return {
		type: actionType,
		flights: flights,
	};
};
export const finalbookticket = (actionType, finalbook) => {
	console.log(finalbook);
	return {
		type: actionType,
		finalbook: finalbook,
	};
};
// export const addingseats = (actionType, flights) => {
// 	console.log(buses);
// 	return {
// 		type: actionType,
// 		buses: buses,
// 	};
// };
// export default bookticket;
export const bookticket = (actionType, book) => {
	console.log(book);
	return {
		type: actionType,
		book: book,
	};
};
