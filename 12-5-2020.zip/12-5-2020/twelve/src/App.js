import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import Addcity from "./components/Addcity";
import Addairlines from "./components/Addairline";
import Addflights from "./components/Addflights";
import Bookflights from "./components/Bookflights";
import Viewdetails from "./components/Viewdetails";

export default class App extends Component {
	render() {
		return (
			<div>
				<AppBar position='static'>
					<Toolbar>
						<Typography variant='h6'> Airline Reservation System</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position='static' color='default'>
					<Router>
						<ul>
							<li>
								<Link to='/Addcity'>Addcity</Link>
							</li>
							<li>
								<Link to='/Addairlines'>Addairlines</Link>
							</li>
							<li>
								<Link to='/Addflights'>Addflights</Link>
							</li>
							<li>
								<Link to='/Boookflights'>Boookflights</Link>
							</li>
							<li>
								<Link to='/Viewdetails'>Viewdetails</Link>
							</li>
						</ul>
						<Switch>
							{/* <Route exact path="/" component={Login}></Route> */}
							<Route exact path='/Addcity' component={Addcity}></Route>
							<Route exact path='/Addairlines' component={Addairlines}></Route>
							<Route exact path='/Addflights' component={Addflights}></Route>
							<Route exact path='/Boookflights' component={Bookflights}></Route>
							<Route exact path='/Viewdetails' component={Viewdetails}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
