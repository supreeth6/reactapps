import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addcity } from "../reducers/actions";

class Addcity extends Component {
	constructor(props) {
		super(props);
		this.state = {
			// detail: {

			cityname: "",
			citycode: "",

			// },
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			// detail: {
			...this.state,
			[name]: value,
			// },
		});
	};

	addCity = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addcity("ADD_CITY", this.state));
		// this.state.cityname = " ";
		// this.state.citycode = " ";
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Name of the city
							<TextField
								id='outlined-basic'
								type='text'
								name='cityname'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							City code
							<TextField
								id='outlined-basic'
								type='text'
								name='citycode'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>

					<Button
						type='button'
						variant='contained'
						onClick={this.addCity}
						color='primary'
					>
						Add City
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		cityAdd: state,
	};
};
export default connect(mapStateToProps)(Addcity);
