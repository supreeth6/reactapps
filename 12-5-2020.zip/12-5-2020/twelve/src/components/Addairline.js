import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addAirline } from "../reducers/actions";

class Addairline extends Component {
	constructor(props) {
		super(props);
		this.state = {
			// detail: {

			airlinename: "",
			airlinecode: "",

			// },
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			// detail: {
			...this.state,
			[name]: value,
			// },
		});
	};

	addAirlines = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addAirline("ADD_AIRLINE", this.state));
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Name of the Airlines
							<TextField
								id='outlined-basic'
								type='text'
								name='airlinename'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Airline code
							<TextField
								id='outlined-basic'
								type='text'
								name='airlinecode'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>

					<Button
						type='button'
						variant='contained'
						onClick={this.addAirlines}
						color='primary'
					>
						Add Airline
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		airlineAdd: state,
	};
};
export default connect(mapStateToProps)(Addairline);
