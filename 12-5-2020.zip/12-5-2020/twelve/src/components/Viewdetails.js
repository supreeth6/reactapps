import React, { Component } from "react";
import { connect } from "react-redux";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import { finalbookticket } from "../reducers/actions";

class ViewDetails extends Component {
	usage = (e) => {
		e.preventDefault();
		// let index=this.props.detailsss.flights.indexOf()
		let i = 0;
		if (i < this.props.detailsss.flights.length) {
			this.props.detailsss.flights.splice(i, 1);
			console.log(this.props.detailsss.flights);
		}
		return this.props.detailsss.flights;
		// let { dispatch } = this.props;
		// dispatch(
		// 	finalbookticket("FINAL_BOOK_TICKET", this.props.detailsss.flights)
		// );
	};
	render() {
		return (
			<TableContainer component={Paper}>
				<Table aria-label='simple table'>
					<TableHead>
						<TableRow>
							<TableCell>Flights</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.detailsss.flights.map((a, b) => {
							console.log(a.flights.flights);
							return (
								<TableRow>
									<TableCell>{a.flights.flights}</TableCell>
									<Button
										type='button'
										varient='contained'
										color='primary'
										onClick={this.usage}
									>
										Book
									</Button>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdfgasdfg", state);
	return {
		detailsss: state,
	};
};
export default connect(mapStateToProps)(ViewDetails);
