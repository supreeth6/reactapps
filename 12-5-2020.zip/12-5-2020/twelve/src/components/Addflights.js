import React, { Component } from "react";

import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import { InputLabel, MenuItem } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import { addflights } from "../reducers/actions";

class Addflights extends Component {
	constructor(props) {
		super(props);
		this.state = {
			// detailone: {
			flights: "",
			srccity: "",
			destcity: "",
			departure: "",
			arrival: "",
			flightno: "",
			noofseats: "",
			// },
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			// detailone: {
			...this.state,
			[name]: value,
			// },
		});
	};
	addListone = (e) => {
		e.preventDefault();
		// console.log(e);
		console.log(this.state);
		let { dispatch } = this.props;
		dispatch(addflights("ADD_FLIGHTS", this.state));
	};

	render() {
		return (
			<div>
				<form>
					<div>
						<br />
						<div>
							<FormControl>
								<InputLabel>Flights</InputLabel>
								<Select
									name='flights'
									value={this.state.flights}
									onChange={this.handleChange}
								>
									{this.props.flightss.airline.map((a, b) => {
										console.log(a);
										return (
											<MenuItem value={a.airlines.airlinename}>
												{a.airlines.airlinename}
											</MenuItem>
										);
									})}

									{/* <MenuItem value="bangalore">Bangalore</MenuItem>
									<MenuItem value="Mysore">Mysore</MenuItem>
									<MenuItem value="Shimoga">Shimoga</MenuItem> */}
								</Select>
							</FormControl>
						</div>

						<br />

						<div>
							<FormControl>
								<InputLabel>Source city</InputLabel>
								<Select
									name='srccity'
									value={this.state.srccity}
									onChange={this.handleChange}
								>
									{this.props.flightss.city.map((a, b) => {
										console.log(a);
										return <MenuItem value={a.cityname}>{a.cityname}</MenuItem>;
									})}
									{/* <MenuItem value="bangalore">Bangalore</MenuItem>
									<MenuItem value="Mysore">Mysore</MenuItem>
									<MenuItem value="Shimoga">Shimoga</MenuItem> */}
								</Select>
							</FormControl>
						</div>
						<div>
							<FormControl>
								<InputLabel>Destination city</InputLabel>
								<Select
									name='destcity'
									value={this.state.destcity}
									onChange={this.handleChange}
								>
									{this.props.flightss.city.map((a, b) => {
										console.log(a);
										return <MenuItem value={a.cityname}>{a.cityname}</MenuItem>;
									})}
									{/* <MenuItem value="bangalore">Bangalore</MenuItem>
									<MenuItem value="Mysore">Mysore</MenuItem>
									<MenuItem value="Shimoga">Shimoga</MenuItem> */}
								</Select>
							</FormControl>
						</div>
						<div>
							<label>
								Departure
								<TextField
									id='outlined-basic'
									type='number'
									name='departure'
									variant='outlined'
									onChange={this.handleChange}
								/>
							</label>
						</div>
					</div>
					<div>
						<label>
							Arrival
							<TextField
								id='outlined-basic'
								type='number'
								name='arrival'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Flight number
							<TextField
								id='outlined-basic'
								type='number'
								name='flightno'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							No of Seats
							<TextField
								id='outlined-basic'
								type='number'
								name='noofseats'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<br />
					<br />

					<Button
						type='button'
						variant='contained'
						color='primary'
						onClick={this.addListone}
					>
						Submit
					</Button>
				</form>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		flightss: state,
	};
};
export default connect(mapStateToProps)(Addflights);
