import React, { Component } from "react";
import ListItems from "./ListItems";

export default class App extends Component {
	constructor(props) {
		super(props);
		this.state = {
			items: [],
			currentItem: {
				name: "",
				number: "",
				type: "",
				wheels: "",
				key: "",
			},
		};
		this.addItem = this.addItem.bind(this);
		this.handleInput = this.handleInput.bind(this);
		this.deleteItem = this.handleInput.bind(this);
		this.setUpdate = this.setUpdate.bind(this);
	}
	addItem(e) {
		e.preventDefault();
		const newItem = this.state.currentItem;
		if (newItem.name !== " ") {
			const items = [...this.state.items, newItem];
			this.setState({
				items: items,
				currentItem: {
					name: "",
					number: "",
					type: "",
					wheels: "",
					key: "",
				},
			});
			console.log(newItem);
		}
	}
	// handleInput(e) {
	// 	this.setState({
	// 		currentItem: {
	// 			name: e.target.value,
	// 			number: e.target.value,
	// 			type: e.target.value,
	// 			wheels: e.target.value,
	// 			key: Date.now(),
	// 		},
	// 	});
	// }

	handleInput = (event) => {
		console.log(event.target.value);
		let name = event.target.name;
		let value = event.target.value;
		this.setState((prevState) => ({
			currentItem: {
				...prevState.currentItem,
				[name]: value,
			},
		}));
	};

	deleteItem(key) {
		const filteredItems = this.state.items.filter((item) => item.key != key);
		this.setState({
			items: filteredItems,
		});
	}

	setUpdate(name, number, type, wheels, key) {
		console.log("items:" + this.state.items);
		const items = this.state.items;
		items.map((item) => {
			if (item.key === key) {
				console.log(item.key + "   " + key);
				item.name = name;
				item.number = number;
				item.type = type;
				item.wheels = wheels;
			}
		});
		this.setState({
			items: items,
		});
	}

	render() {
		return (
			<div>
				<header>
					<form onSubmit={this.addItem}>
						Name
						<input
							type="text"
							name="name"
							value={this.state.currentItem.name}
							onChange={this.handleInput}
						></input>
						Vehicle number
						<input
							type="text"
							name="number"
							value={this.state.currentItem.number}
							onChange={this.handleInput}
						></input>
						Vehicle type
						<select
							name="type"
							value={this.state.currentItem.type}
							onChange={this.handleInput}
						>
							<option>Gear</option>
							<option>Non Gear</option>
						</select>
						No of wheels
						<select
							name="wheels"
							value={this.state.currentItem.type}
							onChange={this.handleInput}
						>
							<option>2</option>
							<option>4</option>
							<option>8</option>
							<option>10</option>
						</select>
						<button type="submit"> Add</button>
					</form>
					<p>{this.state.items.name}</p>
					<p>{this.state.items.number}</p>
					<p>{this.state.items.type}</p>
					<p>{this.state.items.wheels}</p>
					<ListItems
						items={this.state.items}
						deleteItem={this.deleteItem}
						setUpdate={this.setUpdate}
					/>
				</header>
			</div>
		);
	}
}
