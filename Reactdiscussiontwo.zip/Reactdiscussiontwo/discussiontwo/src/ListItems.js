import React from "react";

const ListItems = (props) => {
	return (
		<div>
			{props.items.map((item) => {
				return (
					<div className="list" key={item.key}>
						<p>
							<input
								type="text"
								id={item.key}
								value={item.name}
								onChange={(e) => {
									props.setUpdate(e.target.value, item.key);
								}}
							/>
							<span>
								<button
									onClick={() => {
										props.deleteItem(item.key);
									}}
								>
									Delete
								</button>
							</span>
						</p>
					</div>
				);
			})}
			{/* return <div>{props.items}</div> */}
		</div>
	);
};

export default ListItems;
