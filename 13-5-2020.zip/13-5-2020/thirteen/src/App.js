import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import Addsongs from "./components/Addsongs";
import Createplaylist from "./components/Createplaylist";
import Viewsongs from "./components/Viewsongs";
import Viewplaylist from "./components/Viewplaylist";
import Songsinplay from "./components/Songsinplay";

export default class App extends Component {
	render() {
		return (
			<div>
				<AppBar position='static'>
					<Toolbar>
						<Typography variant='h6'>Music Library App</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position='static' color='default'>
					<Router>
						<ul>
							<li>
								<Link to='/Addsong'>Add song</Link>
							</li>
							<li>
								<Link to='/Createplaylist'>Create Playlist</Link>
							</li>
							<li>
								<Link to='/Viewsongs'>View Songs</Link>
							</li>
							<li>
								<Link to='/Viewplaylist'>View Playlist</Link>
							</li>
						</ul>
						<Switch>
							<Route exact path='/Addsong' component={Addsongs}></Route>
							<Route
								exact
								path='/Createplaylist'
								component={Createplaylist}
							></Route>
							<Route exact path='/Viewsongs' component={Viewsongs}></Route>
							<Route
								exact
								path='/Viewplaylist'
								component={Viewplaylist}
							></Route>
							<Route
								exact
								path='/Songsinplay/:nameoftheplaylist'
								component={Songsinplay}
							></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
