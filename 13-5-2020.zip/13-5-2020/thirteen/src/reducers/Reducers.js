const initialState = {
	song: [],
	searchsong: [],
	playlisting: [],
	showsongsinpl: [],
};
const Reducer = (state = initialState, action) => {
	console.log("to update", state, action);
	switch (action.type) {
		case "ADD_SONGS":
			const songs = action.songs;
			return {
				...state,
				song: [...state.song, songs],
			};
		case "SEARCH_SONGS": {
			console.log(state, action);
			const data = state.song.filter(
				(item) => item.songname === action.search.searchsong
			);
			return {
				...state,
				searchsong: data,
			};
		}
		case "ADD_PLAYLIST":
			const pl = action.playlist;
			return {
				...state,
				playlisting: [...state.playlisting, pl],
			};
		case "SHOW_SONGS_IN_PLAYLIST":
			const sopl = action.songplay;
			return {
				...state,
				showsongsinpl: [...state.showsongsinpl, sopl],
			};

		default:
			return state;
	}
};

export default Reducer;
