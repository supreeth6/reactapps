export const addingsong = (songs) => {
	console.log(songs);
	return {
		type: "ADD_SONGS",
		songs: songs,
	};
};
export const searchsongs = (search) => {
	console.log(search);
	return {
		type: "SEARCH_SONGS",
		search: search,
	};
};
export const playlists = (playlist) => {
	console.log(playlist);
	return {
		type: "ADD_PLAYLIST",
		playlist: playlist,
	};
};
export const songsinplaylist = (songplay) => {
	console.log(songplay);
	return {
		type: "SHOW_SONGS_IN_PLAYLIST",
		songplay: songplay,
	};
};
