import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addingsong } from "../reducers/actions";

class Addsongs extends Component {
	constructor(props) {
		super(props);
		this.state = {
			songname: "",
			movie: "",
			artist: "",
			genre: "",
			duration: "",
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};

	addSong = (e) => {
		e.preventDefault();
		// let { dispatch } = this.props;
		this.props.dispatch(addingsong(this.state));
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Song Name
							<TextField
								id='outlined-basic'
								type='text'
								name='songname'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Movie
							<TextField
								id='outlined-basic'
								type='text'
								name='movie'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Artist
							<TextField
								id='outlined-basic'
								type='text'
								name='artist'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Genre
							<TextField
								id='outlined-basic'
								type='text'
								name='genre'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Duration
							<TextField
								id='outlined-basic'
								type='text'
								name='duration'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type='button'
						variant='contained'
						onClick={this.addSong}
						color='primary'
					>
						Add Song
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		songsadd: state,
	};
};
export default connect(mapStateToProps)(Addsongs);
