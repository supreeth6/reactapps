import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import { MenuItem } from "@material-ui/core";

class Viewsongs extends Component {
	song = (e) => {
		e.preventDefault();
		// console.log(e);
		// console.log(this.state.detailone);
		let { dispatch } = this.props;
		// dispatch(viewsongs("VIEW_SONGS"));
	};
	render() {
		return (
			<TableContainer component={Paper}>
				<Table aria-label='simple table'>
					<TableHead>
						<TableRow>
							<TableCell>Song</TableCell>
							<TableCell>Add to favorates</TableCell>
							{/* <TableCell>select Playlist</TableCell> */}
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.displaysongs.song.map((song, index) => {
							console.log(song);
							return (
								<TableRow key={index}>
									<TableCell>{song.songname}</TableCell>

									<Button
										type='button'
										variant='contained'
										color='primary'
										onClick={this.song}
									>
										add
									</Button>
									{this.props.displaysongs.playlisting.map((a, b) => {
										console.log(a);
										return <MenuItem value={a.playlist}>{a.playlist}</MenuItem>;
									})}
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		displaysongs: state,
	};
};
export default connect(mapStateToProps)(Viewsongs);
