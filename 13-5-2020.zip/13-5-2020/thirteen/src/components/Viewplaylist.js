import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import { MenuItem } from "@material-ui/core";
import { songsinplaylist } from "../reducers/actions";

class Viewplaylist extends Component {
	playlist = (e, nameOfThePlaylist) => {
		e.preventDefault();
		// console.log(e);

		let { dispatch } = this.props;
		dispatch(songsinplaylist(this.props.displayplaylists.searchsong.songname));
		this.props.history.push("/Songsinplay/" + nameOfThePlaylist);
	};
	render() {
		return (
			<TableContainer component={Paper}>
				<Table aria-label='simple table'>
					<TableHead>
						<TableRow>
							<TableCell>Playlist</TableCell>
							<TableCell>No of songs in that playlist</TableCell>
							{/* <TableCell>select Playlist</TableCell> */}
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.displayplaylists.playlisting.map((play, index) => {
							console.log(play);
							return (
								<TableRow key={index}>
									<TableCell>{play.playlist}</TableCell>
									<TableCell>{play.countthesongs}</TableCell>

									<Button
										type='button'
										variant='contained'
										color='primary'
										onClick={(e) => this.playlist(e, play.playlist)}
									>
										show all songs in that playlist
									</Button>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		displayplaylists: state,
	};
};
export default connect(mapStateToProps)(Viewplaylist);
