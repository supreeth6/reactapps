import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { searchsongs, playlists } from "../reducers/actions";

class Createplaylist extends Component {
	constructor(props) {
		super(props);
		this.state = {
			playlist: "",
			countthesongs: 0,
			searchsong: "",
			addsong: " ",
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};

	searchSong = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(searchsongs(this.state));
		// dispatch(playlists(this.state));
	};
	addsong = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		// dispatch(searchsongs(this.state));
		dispatch(playlists(this.state));
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Playlist Name
							<TextField
								id='outlined-basic'
								type='text'
								name='playlist'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>

					<div>
						<label>
							Search songs to add
							<TextField
								id='outlined-basic'
								type='text'
								name='searchsong'
								variant='outlined'
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type='button'
						variant='contained'
						onClick={this.searchSong}
						color='primary'
					>
						Search Song
					</Button>
				</div>
				<div>
					{this.props.playlistadd.searchsong.map((a, b) => {
						console.log(a);
						return <div>{a.songname}</div>;
					})}
				</div>
				<Button
					type='button'
					variant='contained'
					onClick={this.addsong}
					color='primary'
				>
					Add Song
				</Button>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		playlistadd: state,
	};
};
export default connect(mapStateToProps)(Createplaylist);
