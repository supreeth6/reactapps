import React, { Component } from "react";
import ReactDom from "react-dom";
import Switch from "react-switch";

export default class App extends Component {
	constructor() {
		super();
		this.state = {
			checked: false,
			count: 0,
			disabled: false,
		};
		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}
	handleChange(checked) {
		this.setState({ checked });
		const a = this.state.count++;
		console.log(a);
		if (a >= 5) {
			this.setState({ disabled: true });
			alert("Whoa! You clicked too much");
		}
	}

	handleSubmit = (e) => {
		console.log(e);
		this.setState({ checked: false });
		this.setState({ disabled: false });
		this.setState({ count: 0 });
	};
	render() {
		return (
			<div>
				<h2>Toggle switch</h2>
				<label>
					<span>click this switch to</span>
				</label>
				<Switch
					onChange={this.handleChange}
					checked={this.state.checked}
					disabled={this.state.disabled}
				/>
				<p>
					this switch is <b>{this.state.checked ? "on" : "off"}</b>.
				</p>
				<button onClick={this.handleSubmit}>reset</button>
			</div>
		);
	}
}
