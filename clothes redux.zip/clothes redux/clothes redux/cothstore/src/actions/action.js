export const addClothes = (actionType, clothes) => {
    console.log(clothes)
    return {
        type: actionType,
     clothes:clothes  
}
}
export const changeClothes = (actionType, cloth, i) => {
    console.log("ckeck id here first ",cloth,i)
    return {
        type: actionType,
        data: cloth,
        num:i
     }
}