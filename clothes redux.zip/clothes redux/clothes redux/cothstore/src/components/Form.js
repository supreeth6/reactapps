import React, { Component } from "react";
import { connect } from "react-redux";
import { addClothes } from "../actions/action";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import { InputLabel, MenuItem } from "@material-ui/core";
import Select from "@material-ui/core/Select";
class Form extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detail: {
				code: "",
				brand: "",
				gender: "",
				type: "",
				price: "",
				stock: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detail: {
				...this.state.detail,
				[name]: value,
			},
		});
	};
	addList = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addClothes("ADD_LIST", this.state.detail));
	};
	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Unique code
							<TextField
								id="outlined-basic"
								varient="outlined"
								type="text"
								name="code"
								//value={this.state.code}
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Brand
							<TextField
								type="text"
								name="brand"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							<FormControl component="fieldset">
								<FormLabel component="legend">Gender</FormLabel>
								<RadioGroup
									aria-label="gender"
									name="gender1"
									// value="female"
									onChange={this.handleChange}
								>
									<FormControlLabel
										control={<Radio />}
										type="radio"
										color="secondary"
										name="gender"
										value="male"
										onChange={this.handleChange}
										required="true"
										label="Male"
									/>

									<FormControlLabel
										control={<Radio />}
										type="radio"
										name="gender"
										value="female"
										onChange={this.handleChange}
										label="Female"
									/>
								</RadioGroup>
							</FormControl>
						</label>
					</div>

					<div>
						<label>
							<FormControl>
								<InputLabel>Type</InputLabel>
								<Select
									name="type"
									value={this.state.value}
									onChange={this.handleChange}
								>
									<MenuItem>{/* <em>None</em> */}</MenuItem>
									<MenuItem value="Jeans">Jeans</MenuItem>
									<MenuItem value="trousers">trousers</MenuItem>
									<MenuItem value="shirt">shirt</MenuItem>
									<MenuItem value="top">top</MenuItem>
								</Select>
							</FormControl>
						</label>
					</div>
					<br />
					<br />
					<div>
						<label>
							price
							<TextField
								type="text"
								name="price"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							stock
							<TextField
								type="text"
								name="stock"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						color="primary"
						onClick={this.addList}
					>
						Submit
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		clothes: state,
	};
};

export default connect(mapStateToProps)(Form);
