import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
/* import { update } from '../actions/action'; */
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
export class List extends Component {
	render() {
		return (
			<TableContainer component={Paper}>
				<Table area-label="simple table">
					<TableHead>
						<TableRow>
							<TableCell>Dress code</TableCell>
							<TableCell>Brand</TableCell>
							<TableCell>Gender</TableCell>
							<TableCell>Type</TableCell>
							<TableCell>Price</TableCell>
							<TableCell>Stock</TableCell>
							<TableCell>Action</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.clothes.map((cloth, index) => {
							return (
								<TableRow key={index}>
									<TableCell>{cloth.code}</TableCell>
									<TableCell>{cloth.brand}</TableCell>
									<TableCell>{cloth.gender}</TableCell>
									<TableCell>{cloth.type}</TableCell>
									<TableCell>{cloth.price}</TableCell>
									<TableCell>{cloth.stock}</TableCell>

									<TableCell>
										<Button
											variant="contained"
											// color="primary"
											onClick={(e) => {
												this.props.dispatch({
													type: "EDIT_LIST",
													index,
													cloth,
												});
												this.props.history.push("/Update");
											}}
										>
											{/* <Link to="/Update"> Update </Link>{" "} */}
											update
										</Button>
									</TableCell>
									<TableCell>
										<Button
											variant="contained"
											color="primary"
											onClick={(e) =>
												this.props.dispatch({ type: "DELETE_LIST", index })
											}
										>
											Delete
										</Button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
		);
	}
}
const mapStateToProps = (state) => {
	console.log(state);
	return {
		clothes: state.dress,
	};
};
export default connect(mapStateToProps)(List);
