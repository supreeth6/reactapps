import React, { Component } from "react";
import "./App.css";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Form from "./components/Form";
import List from "./components/List";
import Update from "./components/Update";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import Menu from "@material-ui/core/Menu";
class App extends Component {
	render() {
		/*     console.log(this.state) */
		return (
			<div className="App">
				<AppBar position="static">Cloth Shop</AppBar>
				{/* <Button
					aria-controls="simple-menu"
					aria-haspopup="true"
					// onClick={handleClick}
				>
					Open Menu
				</Button> */}
				<AppBar position="static" color="default">
					<Router>
						<ul>
							<li>
								<Link to="/">Home</Link>
							</li>
							<li>
								<Link to="/Form">Add Clothes</Link>
							</li>
							<li>
								<Link to="/ClothList">List</Link>
							</li>
						</ul>
						<Switch>
							<Route exact path="/Form" component={Form}></Route>
							<Route exact path="/ClothList" component={List}></Route>
							<Route exact path="/Update" component={Update}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}

export default App;
