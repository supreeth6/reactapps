const initialState = {
	dress: [],
	cloth: {},
	id: "",
};
const Reducer = (state = initialState, action) => {
	console.log("to updatae", state, action);

	switch (action.type) {
		case "ADD_LIST":
			const { clothes } = action;
			return {
				...state,
				dress: [...state.dress, clothes],
			};
			break;
		case "DELETE_LIST":
			const { index } = action;
			console.log(index);
			return {
				...state,
				dress: state.dress.filter((Element, id) => id !== index),
			};
			break;
		case "EDIT_LIST":
			console.log(action.index);
			const { cloth } = action;
			const id = action.index;
			return {
				...state,
				id: id,
				cloth,
				// id,
			};
			break;
		case "UPDATE_LIST":
			// console.log("coming as updated data", action.data, "the id" + state.data);
			console.log("this is dress", state);
			return {
				// ...state,
				dress: state.dress.map((element, ind) => {
					if (ind === state.id) {
						return action.data;
					}
					return element;
				}),
			};
			break;
		default:
			return state;
	}
};
export default Reducer;
