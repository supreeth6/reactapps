import React, { Component } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";

export default class App extends Component {
	constructor(props) {
		super(props);
		this.state = {
			statearray: ["karnataka", "goa", "andra"],
		};
	}

	render() {
		return (
			<Formik
				initialValues={{
					name: "",
					email: "",
					phoneno: "",
					address: {
						country: "",
						state: "",
						city: "",
					},
				}}
				validationSchema={Yup.object().shape({
					name: Yup.string().required("required"),
					email: Yup.string().required("required"),
					mobileNumber: Yup.string().required("required"),
					address: Yup.string().required("required"),
				})}
				onSubmit={(values, { setErrors, resetForm }) => {
					console.log(values);
				}}
			>
				{({ dirty, isvalid, touched, errors, handleChange, values }) => {
					return (
						<Form>
							{/* name
							{touched.name && errors.name ? <p>{errors.name}</p> : ""}
							<Field type="text" name="name" />
							mobileNumber
							{touched.mobileNumber && errors.mobileNumber ? (
								<p>{errors.mobileNumber}</p>
							) : (
								""
							)}
							<Field type="number" name="phoneno" />
							email:
							{touched.email && errors.email ? <p>{errors.email}</p> : ""}
							<Field type="number" name="email" /> */}
							Name:
							<Field name="name" />
							<br></br>
							<ErrorMessage name="name" />
							Number:
							<Field name="phoneno" />
							<br></br>
							<ErrorMessage name="phoneno" />
							Email:
							<Field name="email" />
							<br></br>
							<ErrorMessage name="email" />
							Country
							<Field name="address.country" as="select">
								<option value="">select</option>
								<option value="India">India</option>
								<option value="us">US</option>
								<option value="japan">JAPAN</option>
								<option value="china">China</option>
							</Field>
							State
							<Field name="address.state" as="select">
								{this.state.statearray.map((ele) => (
									<option value={ele}>{ele}</option>
								))}

								{/* <option value="">select</option>
								<option value="">Karnataka</option>
								<option value="">Goa</option>
								<option value="">Orissa</option>
								<option value="">Andra</option> */}
							</Field>
							City
							<Field name="address.city" as="select">
								<option value="">select</option>
								<option value="">Bangalore</option>
								<option value="">Shimoga</option>
								<option value="">Tumkur</option>
								<option value="">Tarikere</option>
							</Field>
							<br />
							<br />
							<button type="submit">submit</button>
						</Form>
					);
				}}
			</Formik>
		);
	}
}
