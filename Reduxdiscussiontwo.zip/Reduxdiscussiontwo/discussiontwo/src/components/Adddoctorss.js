import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addingdoctors } from "../actions/addAdmins";
import Addadmin from "./Addadmins";
import Adddoctors from "./Adddoctorss";
import Addstocks from "./Addstockss";

class Adddoctorss extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detaildoctors: {
				name: "",
				email: "",
				password: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detaildoctors: {
				...this.state.detaildoctors,
				[name]: value,
			},
		});
	};
	addList = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addingdoctors("ADD_DOCTORS", this.state.detaildoctors));
	};
	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Name
							<TextField
								id="outlined-basic"
								type="text"
								name="name"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Email
							<TextField
								id="outlined-basic"
								type="text"
								name="email"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Password
							<TextField
								id="outlined-basic"
								type="password"
								name="password"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addList}
						color="primary"
					>
						Add Doctors
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		doctors: state,
	};
};
export default connect(mapStateToProps)(Adddoctorss);
