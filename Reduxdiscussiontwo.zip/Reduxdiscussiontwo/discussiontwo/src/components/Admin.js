import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { adding } from "../actions/addAdmins";
import Addadmin from "../components/Addadmins";
import Adddoctors from "./Adddoctorss";
import Addstocks from "./Addstockss";

import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

class Admin extends Component {
	render() {
		return (
			<Router>
				<ul>
					<li>
						<Link to="/Addadmin">Add Admin </Link>
					</li>
					<li>
						<Link to="/Adddoctors">Add Doctors </Link>
					</li>
					<li>
						<Link to="/Addstocks">Add Stocks</Link>
					</li>
				</ul>
				<Switch>
					<Route exact path="/Addadmin" component={Addadmin}></Route>
					<Route exact path="/Adddoctors" component={Adddoctors}></Route>
					<Route exact path="/Addstocks" component={Addstocks}></Route>
				</Switch>
			</Router>
		);
	}
}

export default Admin;
