import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addingstockssyringes } from "../actions/addAdmins";
import { addingstocksmask } from "../actions/addAdmins";
import { addingstocksgloves } from "../actions/addAdmins";
import Addadmin from "./Addadmins";
import Adddoctors from "./Adddoctorss";
import Addstocks from "./Addstockss";

class Addstockss extends Component {
	constructor(props) {
		super(props);
		this.state = {
			// detailstocks: {
			//all updates
			syringes: 0,
			gloves: 0,
			mask: 0,
			// },
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			// detailstocks: {
			...this.state,
			[e.target.name]: value,
			// },
		});
	};
	addListsyringes = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		console.log(e);
		dispatch(addingstockssyringes("UPDATE_SYRINGES", this.state.syringes));
	};
	addListgloves = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addingstocksgloves("UPDATE_GLOVES", this.state.gloves));
	};
	addListmask = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addingstocksmask("UPDATE_MASKS", this.state.mask));
	};
	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Update Syringes
							<TextField
								id="outlined-basic"
								type="text"
								name="syringes"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Update Gloves
							<TextField
								id="outlined-basic"
								type="text"
								name="gloves"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Update Mask
							<TextField
								id="outlined-basic"
								type="text"
								name="mask"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addListsyringes}
						color="primary"
					>
						Add Stocks syringes
					</Button>
					<Button
						type="button"
						variant="contained"
						onClick={this.addListgloves}
						color="primary"
					>
						Add Stocks gloves
					</Button>
					<Button
						type="button"
						variant="contained"
						onClick={this.addListmask}
						color="primary"
					>
						Add Stocks mask
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		stocks: state.stockreducers,
	};
};
export default connect(mapStateToProps)(Addstockss);
