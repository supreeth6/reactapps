import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { adding } from "../actions/addAdmins";
import Addadmin from "../components/Addadmins";
import Adddoctors from "./Adddoctorss";
import Addstocks from "./Addstockss";

class Addadmins extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detail: {
				name: "",
				email: "",
				password: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detail: {
				...this.state.detail,
				[name]: value,
			},
		});
	};
	addList = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(adding("ADD_ADMINS", this.state.detail));
	};
	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Admin Name
							<TextField
								id="outlined-basic"
								type="text"
								name="name"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Admin Email
							<TextField
								id="outlined-basic"
								type="text"
								name="email"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Admin Password
							<TextField
								id="outlined-basic"
								type="password"
								name="password"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addList}
						color="primary"
					>
						Add Admins
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		admins: state,
	};
};
export default connect(mapStateToProps)(Addadmins);
