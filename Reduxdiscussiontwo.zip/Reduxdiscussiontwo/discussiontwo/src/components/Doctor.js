import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addingone } from "../actions/addAdmins";

class Doctor extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detailone: {
				patientname: "",
				noofsyringesused: "",
				noofglovesused: "",
				noofmaskused: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detailone: {
				...this.state.detailone,
				[name]: value,
			},
		});
	};
	addListone = (e) => {
		e.preventDefault();
		console.log(this.state.detailone);
		let { dispatch } = this.props;
		dispatch(addingone("ADD_USAGE", this.state.detailone));
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Name of Patient
							<TextField
								id="outlined-basic"
								type="text"
								name="patientname"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							No of syringes
							<TextField
								id="outlined-basic"
								type="text"
								name="noofsyringesused"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							No of gloves used
							<TextField
								id="outlined-basic"
								type="text"
								name="noofglovesused"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							No of mask used
							<TextField
								id="outlined-basic"
								type="text"
								name="noofmaskused"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addListone}
						color="primary"
					>
						Update
					</Button>
				</div>
			</form>
		);
	}
}

const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		usage: state.other,
	};
};
export default connect(mapStateToProps)(Doctor);
