export const adding = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		admins: admins,
	};
};
export const addingone = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		usage: admins,
	};
};
export const addingdoctors = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		doctors: admins,
	};
};
export const login = (actionType, admins) => {
	console.log(admins);
	return {
		type: "LOGIN",
		datas: admins,
	};
};
export const makingAdmin = (actionType, admins) => {
	console.log(admins);
	return {
		type: "MAKE_ADMIN",
	};
};
export const addingstockssyringes = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		stocks: admins,
	};
};
export const addingstocksgloves = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		stocks: admins,
	};
};
export const addingstocksmask = (actionType, admins) => {
	console.log(admins);
	return {
		type: actionType,
		stocks: admins,
	};
};
