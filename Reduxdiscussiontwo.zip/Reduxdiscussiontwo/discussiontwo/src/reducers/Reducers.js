const initialState = {
	hospital: [],
	doctorsss: [],
	addingdoctors: [],
	// addingstocks: [],
};
export const Reducer = (state = initialState, action) => {
	// console.log("to update", state, action);

	switch (action.type) {
		case "ADD_ADMINS":
			const { admins } = action;
			return {
				...state,
				hospital: [...state.hospital, admins],
			};
			break;
		case "ADD_USAGE":
			const { usage } = action;
			return {
				...state,
				doctorsss: [...state.doctorsss, usage],
			};
			break;
		case "ADD_DOCTORS":
			const { doctors } = action;
			return {
				...state,
				addingdoctors: [...state.addingdoctors, doctors],
			};
			break;
		// case "ADD_STOCKS":
		// 	const { stocks } = action;
		// 	return {
		// 		...state,
		// 		addingstocks: [...state.addingstocks, stocks],
		// 	};
		// 	break;
		default:
			return state;
	}
};

const initialStock = {
	gloves: 1000,
	syringes: 1000,
	masks: 1000,
};

export const stockReducer = (state = initialStock, action) => {
	console.log("supreeth", action);
	switch (action.type) {
		case "UPDATE_MASKS":
			let { stocks } = action;
			return {
				...state,
				masks: Number(state.masks) + Number(action.stocks),
			};
			break;

		case "UPDATE_GLOVES":
			let { stocksone } = action;
			return {
				...state,
				gloves: Number(state.gloves) + Number(action.stocks),
			};
			break;

		case "UPDATE_SYRINGES":
			let { stockstwo } = action;
			return {
				...state,
				syringes: Number(state.syringes) + Number(action.stocks),
			};

		case "ADD_USAGE":
			return {
				...state,
				masks: Number(state.masks) - Number(action.usage.noofmaskused),
				syringes:
					Number(state.syringes) - Number(action.usage.noofsyringesused),
				gloves: Number(state.gloves) - Number(action.usage.noofglovesused),
			};
	}
	return state;
};

export const loginReducer = (
	state = { email: "supreeth@gmail.com", password: "supreeth", isAdmin: false },
	action
) => {
	console.log(action);

	// eslint-disable-next-line default-case
	switch (action.type) {
		case "LOGIN":
			return {
				...state,
				isAdmin:
					action.datas.email === state.email && action.datas.password
						? (state.isAdmin = true)
						: (state.isAdmin = false),
			};
		// eslint-disable-next-line no-duplicate-case
		case "MAKE_ADMIN":
			return {
				...state,
				isAdmin: (state.isAdmin = true),
			};
	}
	return state;
};
