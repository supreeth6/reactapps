import { Reducer, stockReducer, loginReducer } from "../reducers/Reducers";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
	otherreducers: Reducer,
	stockreducers: stockReducer,
	//   ///cart: cartReducer,
	userDetails: loginReducer,
});
export default rootReducer;
