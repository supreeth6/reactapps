import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import Login from "./components/Login";
import Admin from "./components/Admin";
import Doctor from "./components/Doctor";
import Listdoctor from "./components/Listdoctor";
import Protected from "./components/Protected";

export default class App extends Component {
	render() {
		return (
			<div>
				<AppBar position="static">
					<Toolbar>
						<Typography variant="h6"> Hospital</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position="static" color="default">
					<Router>
						<ul>
							{/* <li>
								<Link to="/">Home </Link>
							</li> */}
							{/* <li>
								<Link to="/">Login </Link>
							</li> */}
							<li>
								<Link to="/Admin">Admin</Link>
							</li>
							<li>
								<Link to="/Doctor">Doctor</Link>
							</li>
							<li>
								<Link to="/Listdoctor">Patients list</Link>
							</li>
						</ul>
						<Switch>
							{/* <Route exact path="/" component={Login}></Route> */}
							<Route exact path="/Admin" component={Admin}></Route>
							<Route exact path="/Doctor" component={Doctor}></Route>
							<Route exact path="/Listdoctor" component={Listdoctor}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
