import React, { Component } from "react";
import EventForm from "./EventForm";
import AllEvents from "./AllEvents";
import { BrowserRouter, Switch, Route } from "react-router-dom";

export default class App extends Component {
	render() {
		return (
			<div>
				<EventForm />
				<AllEvents />
			</div>
		);
	}
}
