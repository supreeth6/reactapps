import React, { Component } from "react";
import EventForm from "./EventForm";
import AllEvents from "./AllEvents";
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";
import Routing from "./Routing";
import { render } from "react-dom";
import { withFormik, Form, Field } from "formik";
import * as Yup from "yup";
import Signup from "./Signup";

const routing = (
	<BrowserRouter>
		<div>
			<ul>
				{/* <li>
					<Link to="/">Home</Link>
				</li> */}
				{/* <li>
					<Link to="/users">users</Link>
				</li>
				<li>
					<Link to="/contact">contact</Link>
				</li> */}
			</ul>
			<hr />
			<Switch>
				<Route exact path="/signup" component={Signup} />
				<Route path="/routing" component={Routing} />
				{/* <Route path="/contact" component={contact} />
				<Route component={Notfound} /> */}
			</Switch>
		</div>
	</BrowserRouter>
);

export default routing;
