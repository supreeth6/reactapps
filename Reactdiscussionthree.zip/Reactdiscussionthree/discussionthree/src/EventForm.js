import React, { Component } from "react";
import { connect } from "react-redux";
import AppBar from "@material-ui/core/AppBar";
import { Toolbar } from "@material-ui/core";
// import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

class EventForm extends Component {
	handleSubmit = (e) => {
		e.preventDefault();
		const title = this.getTitle.value;
		const message = this.getMessage.value;
		const data = {
			id: new Date(),
			title,
			message,
			editing: false,
		};
		console.log(data);
		this.props.dispatch({
			type: "Add_EVENT",
			data,
		});
		this.getTitle.value = "";
		this.getMessage.value = "";
		// console.log(data);
	};
	render() {
		return (
			<div>
				<AppBar position="static">
					<Toolbar>
						<Typography variant="h6" gutterBottom>
							<h1>Admin Dashboard</h1>
							<h2>Create Event</h2>
						</Typography>
					</Toolbar>
				</AppBar>
				<br />
				<form onSubmit={this.handleSubmit}>
					<input
						required
						type="text"
						ref={(input) => (this.getTitle = input)}
						label="Enter the Event Title"
						id="outlined-basic"
						variant="outlined"
					/>
					<br />
					<br />
					<TextField
						as="input"
						required
						rows="5"
						ref={(input) => (this.getMessage = input)}
						cols="28"
						label="Enter Event description"
						id="outlined-basic"
						variant="outlined"
					/>
					<br />
					<br />
					<Button type="submit" variant="contained" color="primary">
						Add Event
					</Button>
				</form>
			</div>
		);
	}
}

export default connect()(EventForm);
