//combined reducer
