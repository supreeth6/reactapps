const postReducer = (state = [], action) => {
	switch (action.type) {
		case "Add_EVENT":
			return state.concat([action.data]);
		case "DELETE_EVENT":
			return state.filter((event) => event.id !== action.id);
		case "EDIT_EVENT":
			return state.map((event) =>
				event.id === action.id ? { ...event, editing: !event.editing } : event
			);
		case "UPDATE":
			return state.map((event) => {
				if (event.id === action.id) {
					return {
						...event,
						title: action.data.newTitle,
						message: action.data.newMessage,
						editing: !event.editing,
					};
				} else return event;
			});
		default:
			return state;
	}
};
export default postReducer;
