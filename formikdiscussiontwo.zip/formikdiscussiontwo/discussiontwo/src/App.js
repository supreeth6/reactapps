import React, { Component } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";

export default class App extends Component {
	render() {
		return (
			<Formik
				initialValues={{
					types: "",
					boyname: "",
				}}
				validationSchema={Yup.object().shape({
					types: Yup.string().required("required"),
					boyname: Yup.string().required("required"),
				})}
				onSubmit={(values, { setErrors, resetForm }) => {
					console.log(values);
					if ((values.types === "Hindu" || values.types === "TOI") > 1) {
						setErrors({ types: "already selected" });
						resetForm({});
					} else resetForm({});
					// if ((values.boyname === "Hindu" || values.boyname === "TOI") > 1) {
					// 	setErrors({ types: "error" });
					// }
				}}
			>
				{({ dirty, isvalid, values, errors }) => {
					return (
						<Form>
							{/* {console.log(errors.types)} */}
							Type:
							<Field name="types" as="select">
								<option value="">select</option>
								<option value="Hindu">Hindu</option>
								<option value="TOI">TOI</option>
							</Field>
							<br></br>
							<ErrorMessage name="types" />
							<br />
							Boyname:
							<Field name="boyname" as="select">
								<option value="">select</option>
								<option value="Ram">Ram</option>
								<option value="Sham">Sham</option>
							</Field>
							<br></br>
							<ErrorMessage name="boyname" />
							<br></br>
							<button type="submit">submit</button>
						</Form>
					);
				}}
			</Formik>
		);
	}
}
