import React, { Component } from "react";
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import AppBar from "material-ui/AppBar";
import { List, ListItem } from "material-ui/List";
import Button from "material-ui/RaisedButton";

export class Conform extends Component {
	continue = (e) => {
		e.preventDefault();
		this.props.nextStep();
	};
	back = (e) => {
		e.preventDefault();
		this.props.prevStep();
	};
	render() {
		const {
			values: { firstName, lastName, email, occupation, city, bio },
		} = this.props;
		return (
			<MuiThemeProvider>
				<AppBar title="Confirm User Data" />
				<List>
					<ListItem primaryText="First Name" secondaryText={firstName} />

					<br />

					<ListItem primaryText="Last Name" secondaryText={lastName} />

					<br />

					<ListItem primaryText="Email" secondaryText={email} />

					<br />

					<ListItem primaryText="Occupation" secondaryText={occupation} />

					<br />

					<ListItem primaryText="City" secondaryText={city} />

					<br />

					<ListItem primaryText="Bio" secondaryText={bio} />
				</List>
				<br />

				<Button
					label="Conform and Continue"
					primary={true}
					style={styles.button}
					onClick={this.continue}
				/>
				<Button
					label="Back"
					primary={false}
					style={styles.button}
					onClick={this.back}
				/>
			</MuiThemeProvider>
		);
	}
}
const styles = {
	button: {
		margin: 15,
	},
};

export default Conform;
