// import React, { Component } from "react";
// import Form from "./Components/Form";
// import List from "./Components/List";
// class App extends Component {
// 	constructor(props) {
// 		super(props);

// 		this.state = {
// 			clothes: [],
// 			cloth: "",
// 			index: ""
// 		};
// 	}
// 	changer = cloth => {
// 		const { clothes } = this.state;
// 		this.setState({
// 			clothes: [...clothes, cloth]
// 		});
// 	};

// 	deleteList = (index, e) => {
// 		const { clothes } = this.state;
// 		this.setState({
// 			clothes: clothes.filter((Element, i) => index !== i)
// 		});
// 	};
// 	render() {
// 		return (
// 			<div>
// 				<h1>CLOTH STORE</h1>
// 				<Form clicker={this.changer} />
//         <List data={this.state.clothes}
//         remove={this.deleteList} />
// 			</div>
// 		);
// 	}
// }

// export default App;
