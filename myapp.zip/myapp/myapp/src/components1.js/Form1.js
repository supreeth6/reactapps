import React, { Component } from "react";
class Form1 extends Component {
	constructor(props) {
		super(props);
		this.state = {
			dresscode: "",
			gender: "",
			skills: ""
		};
	}
	handleChange = e => {
		this.setState({
			[e.target.name]: e.target.value
		});
	};
	render() {
		return (
			<div>
				<form>
					dresscode
					<input
						name="dresscode"
						type="text"
						placeholder="enter dresscode"
						onChange={this.handleChange}
					/>
					<br />
					Gender
					<input
						type="radio"
						name="gender"
						value="male"
						onChange={this.handleChange}
					/>
					male
					<input
						type="radio"
						name="gender"
						value="female"
						onChange={this.handleChange}
					/>
					female
					<br />
					Skills
					<select
						value={this.state.value}
						name="skills"
						onChange={this.handleChange}
					>
						<option value="jeans">jeans</option>
						<option value="shirt">shirt</option>
						<option value="trousers">trousers</option>
					</select>
					<button type="button" onClick={e => this.props.clicker(this.state)}>
						add
					</button>
				</form>
			</div>
		);
	}
}
export default Form1;
