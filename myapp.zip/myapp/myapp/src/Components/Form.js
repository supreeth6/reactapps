// import React, { Component } from "react";

// export default class Form extends Component {
// 	constructor(props) {
// 		super(props);

// 		this.state = {
// 			code: "",
// 			gender: "",
// 			type: ""
// 		};
// 	}
// 	handler = e => {
// 		this.setState({
// 			[e.target.name]: e.target.value
// 		});
// 	};
// 	render() {
// 		return (
// 			<div>
// 				<form>
// 					Code:
// 					<input type="text" name="code" onChange={this.handler} />
// 					<br />
// 					Gender: Male
// 					<input
// 						type="radio"
// 						name="gender"
// 						value="male"
// 						onChange={this.handler}
// 					/>
// 					Female
// 					<input
// 						type="radio"
// 						name="gender"
// 						value="female"
// 						onChange={this.handler}
// 					/>
// 					<br />
// 					type:
// 					<select name="type" value={this.state.value} onChange={this.handler}>
// 						<option value="jeans">jeans</option>
// 						<option value="shirt">shirt</option>
// 						<option value="trousers">trousers</option>
// 					</select>
// 					<br />
// 					<button type="button" onClick={e => this.props.clicker(this.state)}>
// 						ADD
// 					</button>
// 				</form>
// 			</div>
// 		);
// 	}
// }
