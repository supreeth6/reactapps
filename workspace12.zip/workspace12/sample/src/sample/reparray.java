package sample;

import java.lang.reflect.Type;
import java.util.Scanner;

public class reparray {
	//int size;
	//size=4;
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int size;
		size=4;
		int arr1[]=new int [size];
		System.out.println("enter the elements in array");
		for(int i=0;i<size;i++) {
			 arr1[i]=scan.nextInt();
		}
	//	int oddprime[];
		int result1[]=new int [size];
		methods(arr1, size);
	//	System.out.println(result1);
	}
			
		
	public static void methods(int[] arr1,int size){
		
		int i=0;

		for(i=0;i<size;i++) {
			if(arr1[i] % 2!=0) {
				int a=arr1[i];
					int count=0;
					for(int j=1;j<=a;j++) {
						if(arr1[i]%j==0) {
							count++;
						}
					}
					if(count==2) {
						System.out.println(arr1[i]+" ");
					}
					
				}
			
		//	return arr1[i];
			
		}
			//return arr1;

	} 

	
		
}
	
	
	

	
	
	
	
	
	
	
	
	