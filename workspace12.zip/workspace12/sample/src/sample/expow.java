package sample;

import java.util.Scanner;

public class expow {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int arr1[]=new int[5];
	    int result[]=new int [5];
		System.out.println("enter the elements of first array");
		for(int i=0;i<=5;i++) {
			arr1[i]=scan.nextInt();
		}
		System.out.println("enter the expontial power");
		int n=scan.nextInt();
		for(int i=0;i<=5;i++) {
			for(int j=0;j<=5;j++) {
				result[i]=arr1[i]*result[j];
			}
		}
		System.out.println(result);	
		
	}

}
