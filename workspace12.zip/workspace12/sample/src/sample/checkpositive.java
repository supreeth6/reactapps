package sample;

import java.util.Scanner;

public class checkpositive {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int a=scan.nextInt();
		int flag=0;
		while(flag==0) {
		if(a>0) {
			System.out.println("The number is positive");
			flag=1;
		}
		else {
			System.out.println("enter positive number");
			a=scan.nextInt();
			flag=0;
		
		}
			}

}
}
