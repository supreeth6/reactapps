package sample;

import java.util.Scanner;

public class delmul {
	static Scanner scan= new Scanner(System.in);
	public static void main(String args[]) {
		System.out.println("enter the size of array");
		int n=scan.nextInt();
		int arr1[]=new int[n];
		int index=2;
		System.out.println("enter the array elements");
		for(int i=0;i<n;i++) {
			arr1[i]=scan.nextInt();
		 int result	=deleteelement(arr1,n,index);
		// System.out.println(result);
		int result1	=multiply(result,n);
		System.out.println(result1);
		}
	}
	public static int deleteelement(int[] arr1,int n,int index) {
		int deletedArray[]=new int[arr1.length];
		for(int i=0,k=0;i<arr1.length;i++) {
			if(i==index) {
				continue;
			}
			deletedArray[k+1]=arr1[i];
		}
		return deletedArray;
		
		
	}
	public static int multiply(int arr1[],int n) {
		int resultArray[]=new int[5];
		for(int i=0;i<n;i++) {
		resultArray=arr1[i]*2;
		}
		return resultArray;
	}
	

}
