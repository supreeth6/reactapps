package sample;

import java.util.Scanner;

public class hello {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int size=scan.nextInt();
		//int result[]=new int[size];
		  int arr[]=new int[size];
		  int arr2[]=printar(arr);
		for(int i=0;i<arr2.length;i++) {
			System.out.println(arr2[i]);
		}
		
	}
	public static int[] printar(int arr[]) {
		int i;
		Scanner scan=new Scanner(System.in);
	  //  int arr[]=new int[size];
		for( i=0;i<arr.length;i++) {
			arr[i]=arr[i]+5;
		}
		return arr;
		
		

}
}
