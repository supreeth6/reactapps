package sample;

public class Stringsample {
	public static void main(String args[]) {
		String s1="welcome";
	//	String s1=s1.concat("to kalinga");
		System.out.println(s1.concat("to kalinga"));
	}

}
