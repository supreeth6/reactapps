package sample;

public class whileloop {
	public static void main(String args[]) {
		int i=1,j=1;
		while(i<=50) {
			int count=0;
		
		while(j<=i) {
			if(i%j==0) {
				++count;
				
			}
			++j;
		}
		if(count==2) {
			System.out.println(i+"");
		}
		++i;
		j=1;
	}

}
}
