import {ALL_USERS} from "./action-types"
const initialState={
  user:[]
}
const Reducer=(state=initialState,action)=>{
    switch(action.type){
        case ALL_USERS: {
            console.log(action);
            return {
              ...state,
              user: action.payload,
            };
          }
    }
};
export default Reducer