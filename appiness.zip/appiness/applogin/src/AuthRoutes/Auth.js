
import React from 'react'
class Auth {
    constructor() {
        this.authenticated = false;
        // this.authenticated = true;
    }
  
    login(cb) {
      this.authenticated = true;
      cb();
    }
  
    logout(cb) {
      this.authenticated = false;
      cb();
    }
  
    isAuthenticated() {
      if (window.performance) {
        if (performance.navigation.type == 1) 
          this.authenticated = true;
      }
      return this.authenticated;
    }
  }
  
  export default new Auth();
  