import React, { Component } from 'react'
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import {fetchallusers} from "../Reducers/actions";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
class Users extends Component {
    componentDidMount() {
        let { dispatch } = this.props;
    
        dispatch(fetchallusers());
      }
    render() {
        console.log(this.props.user)
        return (
            <div>
            <h2>Employee List</h2>
            {/* {this.props.user?.user?.map(coordinate => {
    return coordinate.name;
})} */}
<TableContainer component={Paper}>
				<Table area-label="simple table">
					<TableHead>
						<TableRow>
							<TableCell>ID</TableCell>
							<TableCell>NAME</TableCell>
							<TableCell>AGE</TableCell>
							<TableCell>GENDER</TableCell>
							<TableCell>EMAIL</TableCell>
							<TableCell>PHONE NUMBER</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.user?.user?.map((cloth, index) => {
							return (
								<TableRow key={index}>
									<TableCell>{cloth.id}</TableCell>
									<TableCell>{cloth.name}</TableCell>
									<TableCell>{cloth.age}</TableCell>
									<TableCell>{cloth.gender}</TableCell>
									<TableCell>{cloth.email}</TableCell>
									<TableCell>{cloth.phoneNo}</TableCell>

									
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
            </div>
        )
    }
}
function mapStateToProps(state) {
    console.log(state)
    return { user: state};
  }
export default withRouter(connect(mapStateToProps)(Users));
