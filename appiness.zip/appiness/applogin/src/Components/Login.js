import React, { Component } from 'react'
import { connect } from 'react-redux';
// import { useFormik } from 'formik';
// import * as yup from 'yup';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
// import TextField from '@material-ui/core/TextField';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Checkbox from '@material-ui/core/Checkbox';
// import Link from '@material-ui/core/Link';
// import Grid from '@material-ui/core/Grid';
// import Box from '@material-ui/core/Box';
import { withRouter } from 'react-router-dom';

import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
// import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { FormControl, InputLabel, Input } from '@material-ui/core';
// import { useHistory } from 'react-router-dom'

 class Login extends Component {
   
    constructor(props) {
        super(props);
        this.state = {
          email: '',
          password: '',
          emailError: "",
          passwordError: "",
          loginFormError: "",
        };
      }
      handleChange = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        // console.log(name,"this is state")
        this.setState({
          [name]: value,
        });
      };
   
      validate = () => {
        var currentCharacter = "";
        var numberPresent = false;
        // var lowerCasePresent = false;
        // var upperCasePresent = false;
        // var specialCharacterPresent = false;
        var passwordTemp = this.state.password;
        if (this.state.email !== "") {
          if (!this.state.email.includes("@")) {
            this.setState({
              emailError: "Email should have an @ with domain name.",
            });
            return false;
          }
        } else return false;
    
        for (var i = 0; i < passwordTemp.length; i++) {
          currentCharacter = passwordTemp.charAt(i);
        //   if (passwordTemp.charAt(i).match(/[A-Z]/g)) upperCasePresent = true;
        //   if (passwordTemp.charAt(i).match(/[a-z]/g)) lowerCasePresent = true;
          if (passwordTemp.charAt(i).match(/[0-9]/g)) numberPresent = true;
        //   if (
        //     passwordTemp.charAt(i).match(/[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/g)
        //   )
            // specialCharacterPresent = true;
        }
        if (
          i < 8 ||
        //   upperCasePresent === false ||
          numberPresent === false 
        //   lowerCasePresent === false ||
        //   specialCharacterPresent === false
        ) {
          this.setState({
            passwordError:
              " Password must contain at least one number, one specialCharacter character and one uppercase and lowercase letter, and at least 8 or more characters",
          });
          return false;
        }
        this.setState({ passwordError: "", emailError: "" });
        return true;
      };
      submit=()=>{
          const isValid=this.validate();
          console.log(this.state,"this is state");
          if(isValid){
          if(this.state.email==="hruday@gmail.com" && this.state.password==='hruday123'){
          this.props.history.push("/userpage");
          }
          else{
              alert("enter valid user name and password")
          }
        }
      }
    render() {
        console.log(this.state.password,"this is state")

        return (
            <div>
                <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div >
          <br/>
        <Avatar  style={{margin:"auto",width:"60",background:'red'}}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        
        
        <FormControl margin="normal">
          <InputLabel htmlFor="email">Email </InputLabel>
          <Input name="email" type="text" onChange={this.handleChange} />
        </FormControl>
        <p>{this.state.emailError}</p>
        <br/>
        <FormControl margin="normal">
          <InputLabel htmlFor="password">Password </InputLabel>
          <Input name="password" type="password" onChange={this.handleChange} />
        </FormControl>
        <p>{this.state.passwordError}</p>
        <br/>
        <Button
          type="button"
          variant="contained"
          color="primary"
          onClick={this.submit}
        >
          Login
        </Button>
        
      </div>
     
    </Container>
            </div>
        )
    }
}
function mapStateToProps(state) {
    return { state: state };
  }
export default withRouter(connect(mapStateToProps)(Login));