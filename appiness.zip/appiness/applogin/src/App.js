// import logo from './logo.svg';
import './App.css';
import Login from "./Components/Login";
import Userpage from "./Components/Users"
import { BrowserRouter as Router,Route, Link, Switch, Redirect } from "react-router-dom";

function App() {
  return (
    <div className="App">
      {/* <header className="App-header"> */}
        {/* <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a> */}
        {/* <Router > */}
        <Switch>
        <Route exact path="/">
              <Redirect  to="/login" />
            </Route>
            <Route
              exact
              path="/login"
              component={Login}
            ></Route>
                <Route exact path="/userpage" component={Userpage} />
                </Switch>
                {/* </Router> */}
        {/* <Login/> */}
      {/* </header> */}
    </div>
  );
}

export default App;
