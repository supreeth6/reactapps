
import React from 'react';
import ReactDOM from 'react-dom';
import Parent from './Parent'

const white = '#fff';
const yellow = '#000';
const gray="#f0f0f0";
const darkgray="#666";


export default class Toggle extends React.Component{
  constructor(props){
    super(props);
    this.state = { color: white ,fontcolor:"#000"};
    this.changeColor = this.changeColor.bind(this);

  }
  changeColor(){
    const newColor = this.state.color == white ? yellow :white;
    const newfontColor = this.state.fontcolor == yellow ? white :yellow;
    this.setState({ color: newColor ,fontcolor:newfontColor});
   }

  render(){
    return(
      <div style={{backgroundColor: this.state.color ,color:this.state.fontcolor}}>
      <button onClick={this.changeColor}>Change theme</button>
      <Parent/>
      </div>
    )
  }
}
ReactDOM.render(<Toggle />, document.getElementById('root'))