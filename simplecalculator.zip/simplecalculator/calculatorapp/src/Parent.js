import React, { Component } from 'react'
import App from "./App";
import Scientific from './components/scientific'
export default class Parent extends Component {
    constructor(props) {
        super(props);
        this.state = {
          isToggle:false,
        }
      }
      handleclick(){
          this.setState({isToggle : !this.state.isToggle })
      }

    render() {
        if(this.state.isToggle){
            return(
                <div>
                     <button onClick={()=>this.handleclick()}>TO manual mode</button>
                      <Scientific/>
                </div>
            )
        }
        else{
            return(
                <div>
                    <button onClick={()=>this.handleclick()}>TO Scientific mode</button>
                    <App/>
                </div>
            
            )
        }
      }
}
