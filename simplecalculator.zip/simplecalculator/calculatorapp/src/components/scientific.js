import React, { Component } from 'react'
import KeyPadComponent from "./keyPadComponent"
export default class scientific extends Component {
    constructor(){
        super();
        this.state = {
        scientificresult: ""
        }
    }

    onClick=(scientificbutton)=>{
        if(scientificbutton === "="){
            this.calculate()
        }

        else if(scientificbutton === "C"){
            this.reset()
        }
        else if(scientificbutton === "--"){
            this.togglesign()
        }
        else if(scientificbutton === "CE"){
            this.backspace()
        }
        else if(scientificbutton === "square"){
            this.FindSquare()
        }
        else if(scientificbutton === "squareroot"){
            this.FindSquareRoot()
        }

        else {
            this.setState({
                scientificresult: this.state.scientificresult +scientificbutton
            })
        }
    }

    togglesign=()=>{
        var B;
        var A=this.state.scientificresult;
        if(A<0){
         B=A*-1;
         this.setState({
            scientificresult: this.state.scientificresult.replace(this.state.scientificresult,B.toString())
        })
        }
        else{
            B=-(A);
            this.setState({
                scientificresult: this.state.scientificresult.replace(this.state.scientificresult,B.toString())
            })
        }

    }

    FindSquare=()=>{
        var A = this.state.scientificresult ;
        var B = Math.pow(A, 2);
        this.setState({
        scientificresult: this.state.scientificresult.replace(this.state.scientificresult,B.toString())
        })
       
        }
        FindSquareRoot=()=>{
    
            var A = this.state.scientificresult ;
          
            var B = Math.sqrt(A)
          
            // Alert.alert("SquareRoot = " + B.toString());
            this.setState({
                scientificresult: this.state.scientificresult.replace(this.state.scientificresult,B.toString())
            })
      }

    calculate = () => {
        var checkResult = ''
        if(this.state.scientificresult.includes('--')){
            checkResult = this.state.scientificresult.replace('--','+')
        }

        else {
            checkResult = this.state.scientificresult
        }

        try {
            this.setState({
                // eslint-disable-next-line
                scientificresult: (eval(checkResult) || "" ) + ""
            })
        } catch (e) {
            this.setState({
                scientificresult: "error"
            })

        }
    };
   
    reset = () => {
        this.setState({
            scientificresult: ""
        })
    };

    backspace = () => {
        this.setState({
            scientificresult: this.state.scientificresult.slice(0, -1)
        })
    };

    render() {
        return (
            <div>
                <h1>Scientific Calculator</h1>
                {this.state.scientificresult}
                <br/>
                <button name="--" onClick={(e)=>this.onClick(e.target.name)}>Sign button</button>
                <button name="square" onClick={(e)=>this.onClick(e.target.name)}>Square button</button>
                <button name="squareroot" onClick={(e)=>this.onClick(e.target.name)}>Squareroot button</button>
                <KeyPadComponent onClick={this.onClick}/>
            </div>
        )
    }
}
