import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
import Home from './Home'
import { Provider } from 'react-redux'
import Reducer from './Redux'
import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
// const axios = require('axios')
// const ReduxThunk = require('redux-thunk').default
// import thunk from 'redux-thunk'
// import { createStore, applyMiddleware } from 'redux'
// const applymiddleware = redux.applyMiddleware
// const thunkMiddleware = require('redux-thunk').default

const store = createStore(Reducer,
  applyMiddleware(thunk)
);


// const logger=store=>{
//     return next=>{
//         return action=>{

//         }
//     }
// }
// const store = createStore(Reducer, applyMiddleware(thunkMiddleware))
ReactDOM.render(<Provider store={store}><Home /></Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
