import axios from 'axios'
const addToReducerAsync = (name, mid, track) => {
    console.log('inside dipatch')
    console.log(name, mid, track)
    return {
        type: 'updateuser',
        payload: { name: name, mid: mid, track: track }
    }
}
const addToReducer = (name, mid, track) => {
    console.log('inside dispatch')
    console.log(name, mid, track)
    return dispatch=>{
        axios.post('http://localhost:4000/user/CreateUser/')
        .then(res=>
            console.log(res.data))
        .then(user=>{
            dispatch(addToReducerAsync(name,mid,track))
        })
    }
}
export {
    addToReducer,
    addToReducerAsync
}