import React from 'react';
import './App.css';
import Button from '@material-ui/core/Button';
import CreateUser from './Adduser'
import DisplayUser from './Displayusers'
import { BrowserRouter, Link, Route } from 'react-router-dom'
// import { connect } from 'react-redux'
// import TextField from '@material-ui/core/TextField';
class App extends React.Component {
  render() {
    return (
      <div className="App">
        <BrowserRouter>
          <h2 className="header">User Assignment using React-Redux</h2>
          <Button variant="contained" color="primary"><Link to="/CreateUser">CreateUser</Link></Button><br></br><br></br>
          <Button variant="contained" color="primary"><Link to="DisplayUser">DisplayUsers</Link></Button>
          <Route path='/CreateUser' component={CreateUser}></Route>
          <Route path='/DisplayUser' component={DisplayUser}></Route>
        </BrowserRouter>
      </div>
    )
  }
}

export default App;
