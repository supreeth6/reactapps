import React from 'react'
import App from './App'
class Home extends React.Component{
    render(){
        return(
            <div>
                <App />
            </div>
        )
    }
}
export default Home