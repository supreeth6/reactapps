const initialstate = {
    
    name:[],
    mid:[],
    track:[]
}
const Reducer = (state = initialstate, action) => {
    switch (action.type) {
        case 'updateuser': console.log('in update')
            console.log(action.payload)
            return{
                ...state,
                name:[...state.name,action.payload.name],
                mid:[...state.mid,action.payload.mid],
                track:[...state.track,action.payload.track]
                
            }
        default: console.log('invalid entry')
    }
}
export default Reducer
