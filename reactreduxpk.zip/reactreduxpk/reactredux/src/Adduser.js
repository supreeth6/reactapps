import React, { Component } from 'react'
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import { connect } from 'react-redux'
import * as actionCreator from './Action'
class AddUsers extends Component {
    state = {
        name: '',
        mid: '',
        track: ''
    }
    ontext = (e) => {
        this.setState({
            name: e.target.value
        })
        console.log(this.state.name)
    }
    ontext1 = (e) => {
        this.setState({
            mid: e.target.value
        })
        console.log(this.state.mid)

    }
    ontext2 = (e) => {
        this.setState({
            track: e.target.value
        })
        console.log(e.target.value)
        console.log(this.state.name, this.state.mid, this.state.track)
    }

    render() {

        return (
            <div >
                <TextField id="standard-basic username" label="UserName" onChange={this.ontext} /> <br></br>
                <TextField id="standard-basic usermid" label="Mid" onChange={this.ontext1} /> <br></br>
                <TextField id="standard-basic usertrack" label="Track" onChange={this.ontext2} /> <br></br> <br></br>
                <Button variant="contained" color="primary" onClick={() => this.props.adduser(this.state.name, this.state.mid, this.state.track)}>Submit</Button>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        // name:state.name,
        // mid:state.mid,
        // track:state.track
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        adduser: (name, mid, track) => dispatch(actionCreator.addToReducer(name, mid, track))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(AddUsers);


