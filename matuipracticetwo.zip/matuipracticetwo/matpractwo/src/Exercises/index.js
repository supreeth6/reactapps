import React from "react";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";

const styles = {
	Paper: { padding: 20, marginTop: 10, marginBottom: 10 },
};

const index = ({ exercises }) => {
	return (
		<Grid container>
			<Grid item sm>
				<Paper styles={styles.Paper}>Left Pane</Paper>
			</Grid>
			<Grid item sm>
				<Paper styles={styles.Paper}>Right Pane</Paper>
			</Grid>
		</Grid>
	);
};

export default index;
