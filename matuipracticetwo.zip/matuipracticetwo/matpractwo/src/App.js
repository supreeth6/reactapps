import React, { Component, Fragment } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Exercises from "./Exercises/index";
// import { muscles, exercises } from "./store";

export default class App extends Component {
	// state = {
	// 	exercises,
	// };
	// getExercisesByMuscles() {
	// 	return this.state.exercises.reduce((exercises, exercise) => {
	// 		const { muscles } = exercise;

	// 		exercises[muscles] = exercises[muscles]
	// 			? [...exercises[muscles], exercise]
	// 			: [exercise];
	// 		return exercises;
	// 	}, {});
	// }
	render() {
		// const exercises = this.getExercisesByMuscles();
		return (
			<Fragment>
				<Header />

				<Exercises />

				<Footer />
			</Fragment>
		);
	}
}
