import React, { Fragment } from "react";
import { Link } from "react-router-dom";

const index = (props) => {
	console.log(props);
	return (
		<Fragment>
			<ul>
				{props.writers.map(({ id, name }) => (
					<li key={id}>
						<Link to=" ">{name}</Link>
					</li>
				))}
			</ul>
		</Fragment>
	);
};

export default index;
