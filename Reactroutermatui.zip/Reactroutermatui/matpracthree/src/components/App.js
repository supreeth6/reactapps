import React, { Component, Fragment } from "react";
import { BrowserRouter, Link, Route } from "react-router-dom";
import Writers from "./../writers.js";

export default class App extends Component {
	state = {
		writers: [],
	};
	render() {
		const { writers } = this.state;
		return (
			<BrowserRouter>
				<Fragment>
					<ul>
						<li>
							<Link to="/">Home</Link>
						</li>
						<li>
							<Link to="/Writers">Writers</Link>
						</li>
					</ul>
					<Route exact path="/" render={() => <div>Home</div>} />
					<Route
						path="/writers"
						render={(props) => <Writers {...props} writers={writers} />}
					/>
				</Fragment>
			</BrowserRouter>
		);
	}
}
