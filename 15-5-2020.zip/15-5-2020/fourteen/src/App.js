import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Addcity from "./components/Addcity";
import Addproperty from "./components/Addproperty";
import Propertydetails from "./components/Propertydetails";
import Propertysearch from "./components/Propertysearch";
import Showproperty from "./components/Showproperties";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";

export default class App extends Component {
	render() {
		return (
			<div>
				<AppBar position='static'>
					<Toolbar>
						<Typography variant='h6'>Property Management</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position='static' color='default'>
					<Router>
						<ul>
							<li>
								<Link to='/Addcity'>Addcity</Link>
							</li>
							<li>
								<Link to='/Addproperty'>Addproperty</Link>
							</li>
							<li>
								<Link to='/Propertydetails'>Propertydetails</Link>
							</li>
							<li>
								<Link to='/Searchproperty'>Searchproperty</Link>
							</li>
							<li>
								<Link to='/Showproperty'>Showproperties</Link>
							</li>
						</ul>
						<Switch>
							<Route exact path='/Addcity' component={Addcity}></Route>
							<Route exact path='/Addproperty' component={Addproperty}></Route>
							<Route
								exact
								path='/Propertydetails'
								component={Propertydetails}
							></Route>
							<Route
								exact
								path='/Searchproperty'
								component={Propertysearch}
							></Route>
							<Route
								exact
								path='/Showproperty'
								component={Showproperty}
							></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
