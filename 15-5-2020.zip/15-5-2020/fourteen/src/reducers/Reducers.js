const initialState = {
	city: [],
	property: [],
	propertydetails: [],
	propertysearch: [],
	reqproperty: [],
};

const reducer = (state = initialState, action) => {
	console.log("something", action);
	switch (action.type) {
		case "ADD_CITIES":
			return {
				...state,
				city: [...state.city, action.details],
			};
		case "ADD_PROPERTIES":
			return {
				...state,
				property: [...state.property, action.detailtwo],
			};
		case "PROPERTY_DETAILS":
			return {
				...state,
				propertydetails: [...state.propertydetails, action.detailthree],
			};
		case "PROPERTY_SEARCH":
			return {
				...state,
				propertysearch: [...state.propertysearch, action.detailfour],
			};
		case "PROPERTY_SEARCH_REQ": {
			console.log(state, action);
			const data = state.propertydetails.filter(
				(item) => item.propertycity === action.detailfive.city
			);
			return {
				...state,
				// reqproperty: [...state.reqproperty, action.detailfive],
				reqproperty: data,
			};
		}
		default:
			return state;
	}
};
export default reducer;
