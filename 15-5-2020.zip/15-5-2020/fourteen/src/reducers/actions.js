export const addcity = (details) => {
	console.log(details);
	return {
		type: "ADD_CITIES",
		details: details,
	};
};

export const addproperty = (detailtwo) => {
	console.log(detailtwo);
	return {
		type: "ADD_PROPERTIES",
		detailtwo: detailtwo,
	};
};
export const propdetail = (detailthree) => {
	console.log(detailthree);
	return {
		type: "PROPERTY_DETAILS",
		detailthree: detailthree,
	};
};
export const searchproperty = (detailfour) => {
	console.log(detailfour);
	return {
		type: "PROPERTY_SEARCH",
		detailfour: detailfour,
	};
};
export const searchreqproperty = (detailfive) => {
	console.log(detailfive);
	return {
		type: "PROPERTY_SEARCH_REQ",
		detailfive: detailfive,
	};
};
