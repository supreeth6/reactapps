import React, { Component } from "react";
import { connect } from "react-redux";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { searchproperty, searchreqproperty } from "../reducers/actions";
import {
	FormControl,
	MenuItem,
	FormLabel,
	FormControlLabel,
} from "@material-ui/core";
import { InputLabel } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import Slider from "@material-ui/core/Slider";

class Propertydetails extends Component {
	constructor(props) {
		super(props);
		this.state = {
			pricerangefrom: "",
			pricerangeto: "",
			noofrooms: "",
			noofbalcony: "",
			parking: "",
			garden: "",
			city: "",
		};
	}
	searchprop = (e) => {
		e.preventDefault();
		this.props.dispatch(searchproperty(this.state));
		this.props.dispatch(searchreqproperty(this.state));
	};
	handlechange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};

	render() {
		return (
			<div>
				<div>
					<label>
						Price range from
						<TextField
							id='outlined-basic'
							type='number'
							name='propertyaddress'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>
				<div>
					<label>
						Price range to
						<TextField
							id='outlined-basic'
							type='number'
							name='pricerangeto'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>

				<div>
					<FormControl>
						<InputLabel>No of rooms</InputLabel>
						<Select
							name='noofrooms'
							value={this.state.noofrooms}
							onChange={this.handlechange}
						>
							<MenuItem value={1}>1</MenuItem>
							<MenuItem value={2}>2</MenuItem>
							<MenuItem value={3}>3</MenuItem>
							<MenuItem value={4}>4</MenuItem>
							<MenuItem value={5}>5</MenuItem>
							<MenuItem value={6}>6</MenuItem>
							<MenuItem value={7}>7</MenuItem>
							<MenuItem value={8}>8</MenuItem>
							<MenuItem value={9}>9</MenuItem>
							<MenuItem value={10}>10</MenuItem>
						</Select>
					</FormControl>
				</div>
				<div>
					<FormControl>
						<InputLabel>No of Balcony</InputLabel>
						<Select
							name='noofbalcony'
							value={this.state.noofbalcony}
							onChange={this.handlechange}
						>
							<MenuItem value={1}>1</MenuItem>
							<MenuItem value={2}>2</MenuItem>
							<MenuItem value={3}>3</MenuItem>
							<MenuItem value={4}>4</MenuItem>
							<MenuItem value={5}>5</MenuItem>
							<MenuItem value={6}>6</MenuItem>
							<MenuItem value={7}>7</MenuItem>
							<MenuItem value={8}>8</MenuItem>
							<MenuItem value={9}>9</MenuItem>
							<MenuItem value={10}>10</MenuItem>
						</Select>
					</FormControl>
				</div>
				<div>
					<FormControl>
						<InputLabel>Parking</InputLabel>
						<Select
							name='parking'
							value={this.state.parking}
							onChange={this.handlechange}
						>
							<MenuItem value={this.state.parking}>yes</MenuItem>
							<MenuItem value={this.state.parking}>No</MenuItem>
						</Select>
					</FormControl>
				</div>
				<div>
					<FormControl>
						<InputLabel>Garden</InputLabel>
						<Select
							name='parking'
							value={this.state.garden}
							onChange={this.handlechange}
						>
							<MenuItem value={this.state.garden}>yes</MenuItem>
							<MenuItem value={this.state.garden}>No</MenuItem>
						</Select>
					</FormControl>
				</div>
				<br />
				<br />
				<div>
					<label>
						City
						<TextField
							id='outlined-basic'
							type='text'
							name='city'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>

				<Button
					type='button'
					onClick={this.searchprop}
					variant='contained'
					color='primary'
				>
					Search
				</Button>
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("something", state);
	return {
		searchpropertydetails: state,
	};
};
export default connect(mapStateToProps)(Propertydetails);
