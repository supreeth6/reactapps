import React, { Component } from "react";
import { connect } from "react-redux";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addproperty } from "../reducers/actions";
class Addproperty extends Component {
	constructor(props) {
		super(props);
		this.state = {
			propertytype: "",
			propertycode: "",
		};
	}
	addprop = (e) => {
		e.preventDefault();
		this.props.dispatch(addproperty(this.state));
	};
	handlechange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};
	render() {
		return (
			<div>
				<div>
					<label>
						Type
						<TextField
							id='outlined-basic'
							type='text'
							name='propertytype'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>
				<div>
					<label>
						Property code
						<TextField
							id='outlined-basic'
							type='text'
							name='propertycode'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>
				<Button
					type='button'
					onClick={this.addprop}
					variant='contained'
					color='primary'
				>
					submit
				</Button>
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("something", state);
	return {
		propertyadd: state,
	};
};
export default connect(mapStateToProps)(Addproperty);
