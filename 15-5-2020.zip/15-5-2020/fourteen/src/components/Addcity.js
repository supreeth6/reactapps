import React, { Component } from "react";
import { connect } from "react-redux";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addcity } from "../reducers/actions";
class Addcity extends Component {
	constructor(props) {
		super(props);
		this.state = {
			city: "",
			state: "",
		};
	}
	addcity = (e) => {
		e.preventDefault();
		this.props.dispatch(addcity(this.state));
	};
	handlechange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};
	render() {
		return (
			<div>
				<div>
					<label>
						city
						<TextField
							id='outlined-basic'
							type='text'
							name='city'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>
				<div>
					<label>
						State
						<TextField
							id='outlined-basic'
							type='text'
							name='state'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>
				<Button
					type='button'
					onClick={this.addcity}
					variant='contained'
					color='primary'
				>
					Submit
				</Button>
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("something", state);
	return {
		cityadd: state,
	};
};
export default connect(mapStateToProps)(Addcity);
