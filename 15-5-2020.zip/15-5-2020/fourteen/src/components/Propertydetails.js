import React, { Component } from "react";
import { connect } from "react-redux";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { propdetail } from "../reducers/actions";
import {
	FormControl,
	MenuItem,
	FormLabel,
	FormControlLabel,
} from "@material-ui/core";
import { InputLabel } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";

class Propertydetails extends Component {
	constructor(props) {
		super(props);
		this.state = {
			propertyaddress: "",
			propertycity: "",
			propertyroom: "",
			propertyarea: "",
			propertybalcony: "",
			parkingspace: "",
			garden: "",
			terace: "",
			costperarea: "",
			cost: [],
			room: [],
			property: [],
			balcony: [],
		};
	}
	addcity = (e) => {
		e.preventDefault();
		this.props.dispatch(propdetail(this.state));
		// console.log(this.state.propertyarea);
		// console.log(this.state.costperarea);

		const price = this.state.propertyarea * this.state.costperarea;
		this.setState({ cost: price });
	};
	handlechange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};
	room = () => {
		this.setState({ room: [...this.state.room, this.state.propertyroom] });
	};
	// property = () => {
	// 	this.setState({
	// 		property: [...this.state.property, this.state.propertyarea],
	// 	});
	// };
	balcony = () => {
		this.setState({
			balcony: [...this.state.balcony, this.state.propertybalcony],
		});
	};
	render() {
		return (
			<div>
				<div>
					<label>
						Address
						<TextField
							id='outlined-basic'
							type='text'
							name='propertyaddress'
							varient='outlined'
							onChange={this.handlechange}
						/>
					</label>
				</div>
				<div>
					<FormControl>
						<InputLabel>Cities</InputLabel>
						<Select
							name='propertycity'
							value={this.state.propertycity}
							onChange={this.handlechange}
						>
							{this.props.propertydetails.city.map((a, b) => {
								console.log(a);
								return <MenuItem value={a.city}>{a.city}</MenuItem>;
							})}
						</Select>
					</FormControl>
				</div>
				<div>
					<div>
						<label>
							Add Rooms
							<TextField
								id='outlined-basic'
								type='number'
								name='propertyroom'
								varient='outlined'
								onChange={this.handlechange}
							/>
						</label>
					</div>
				</div>
				<div>
					<button onClick={this.room}>AddMoreRooms</button>
					<div>
						{this.state.room
							? this.state.room.map((element) => {
									return <div>{element}</div>;
							  })
							: " "}
					</div>
				</div>
				<div>
					<div>
						<label>
							Add Area of property
							<TextField
								id='outlined-basic'
								type='number'
								name='propertyarea'
								varient='outlined'
								onChange={this.handlechange}
							/>
						</label>
					</div>
				</div>
				{/* <div>
					<button onClick={this.property}>AddMoreProperty</button>
					<div>
						{this.state.property
							? this.state.property.map((element) => {
									return <div>{element}</div>;
							  })
							: " "}
					</div>
				</div> */}
				<div>
					<div>
						<label>
							Add Balcony of property
							<TextField
								id='outlined-basic'
								type='number'
								name='propertybalcony'
								varient='outlined'
								onChange={this.handlechange}
							/>
						</label>
					</div>
				</div>
				<div>
					<button onClick={this.balcony}>Add More Balcony</button>
					<div>
						{this.state.balcony
							? this.state.balcony.map((element) => {
									return <div>{element}</div>;
							  })
							: " "}
					</div>
				</div>
				<div>
					<FormLabel component='legend'>parkingspace</FormLabel>
					<RadioGroup
						aria-label='parkingspace'
						name='parkingspace'
						onChange={this.handlechange}
					>
						<FormControlLabel
							control={<Radio />}
							type='radio'
							color='secondary'
							name='parkingspace'
							value='yes'
							onChange={this.handlechange}
							required='true'
							label='Yes'
						/>
						<FormControlLabel
							control={<Radio />}
							type='radio'
							color='secondary'
							name='parkingspace'
							value='no'
							onChange={this.handlechange}
							required='true'
							label='no'
						/>
					</RadioGroup>
				</div>
				<div>
					<FormLabel component='legend'>garden</FormLabel>
					<RadioGroup
						aria-label='garden'
						name='garden'
						onChange={this.handlechange}
					>
						<FormControlLabel
							control={<Radio />}
							type='radio'
							color='secondary'
							name='garden'
							value='yes'
							onChange={this.handlechange}
							required='true'
							label='Yes'
						/>
						<FormControlLabel
							control={<Radio />}
							type='radio'
							color='secondary'
							name='garden'
							value='no'
							onChange={this.handlechange}
							required='true'
							label='no'
						/>
					</RadioGroup>
				</div>
				<div>
					<FormLabel component='legend'>terace</FormLabel>
					<RadioGroup
						aria-label='terace'
						name='terace'
						onChange={this.handlechange}
					>
						<FormControlLabel
							control={<Radio />}
							type='radio'
							color='secondary'
							name='terace'
							value='yes'
							onChange={this.handlechange}
							required='true'
							label='Yes'
						/>
						<FormControlLabel
							control={<Radio />}
							type='radio'
							color='secondary'
							name='terace'
							value='no'
							onChange={this.handlechange}
							required='true'
							label='no'
						/>
					</RadioGroup>
				</div>
				<div>
					<div>
						<label>
							cost per area
							<TextField
								id='outlined-basic'
								type='number'
								name='costperarea'
								varient='outlined'
								onChange={this.handlechange}
							/>
						</label>
					</div>
				</div>

				<Button
					type='button'
					onClick={this.addcity}
					variant='contained'
					color='primary'
				>
					Submit
				</Button>
				<div>
					<p>{this.state.cost}</p>
				</div>
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("something", state);
	return {
		propertydetails: state,
	};
};
export default connect(mapStateToProps)(Propertydetails);
