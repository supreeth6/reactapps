const fs = require("fs");
const readline = require("readline");
// const GoogleCharts = require("google-charts");
var i = -1;
var arr = [];
var totalamount = 0;

async function processLineByLine() {
	const fileStream = fs.createReadStream("customerdata.txt");

	const rl = readline.createInterface({
		input: fileStream,
		crlfDelay: Infinity,
	});
	// Note: we use the crlfDelay option to recognize all instances of CR LF
	// ('\r\n') in input.txt as a single line break.

	var i = 0;
	for await (const line of rl) {
		// Each line in input.txt will be successively available here as `line`.
		if (i === 0) {
			++i;
			continue;
		}
		let data = line.split(",");
		arr.push(data[2]);
		totalamount += parseInt(data[3]);
	}
	return arr;
}

async function getCustDetails() {
	let dict = {};
	await processLineByLine();
	arr.forEach((num) => {
		if (dict[num] === undefined) {
			dict[num] = 1;
		} else {
			dict[num] = ++dict[num];
		}
	});

	return dict;
}

var one = [];
var two = [];
var three = [];
var four = [];
var more = [];

getCustDetails().then((dict) => {
	var keys = Object.keys(dict);

	// console.log(keys.length);
	for (var i = 0; i < keys.length; ++i) {
		if (dict[arr[i]] === 1) {
			one.push(keys[i]);
		} else if (dict[arr[i]] === 2) {
			two.push(keys[i]);
		} else if (dict[arr[i]] === 3) {
			three.push(keys[i]);
		} else if (dict[arr[i]] === 4) {
			four.push(keys[i]);
		} else {
			more.push(keys[i]);
		}
	}
	//1
	console.log("total number of orders", arr.length);

	console.log("total transaction amount", totalamount);

	console.log("Made one transaction", one);
	console.log("Made two transaction", two);
	console.log("Made three transaction", three);
	console.log("Made four transaction", four);
	console.log("Made more than five transaction", more);

	// const data = GoogleCharts.api.visualization.arrayToDataTable(
	// 	one,
	// 	two,
	// 	three,
	// 	four,
	// 	more
	// );
	// const pie_1_chart = new GoogleCharts.api.visualization.PieChart(
	// 	document.getElementById("chart1")
	// );
	// pie_1_chart.draw(data);
});

// GoogleCharts.load(call);

// fs.readFile("customerdata.txt", (err, data) => {
// 	if (err) throw err;
// 	console.log(data.toString());
// 	// const nbLines = "customerdata.txt".split("\n").length;
// 	// console.log(nbLines);
// });
