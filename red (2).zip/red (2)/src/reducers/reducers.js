import React from "react";

const reducer = (state, action) => {
	console.log(action);
	switch (action.type) {
		case "ADD":
			return {
				cloths: [...state.cloths, action.detail]
			};
		case "DELETE":
			console.log(state.cloths);
			let newClot = state.cloths.filter(obj => {
				if (obj.DressCode !== action.detail) {
					console.log("old", obj.DressCode, "new", action.detail);
					return obj;
				}
			});
			console.log(newClot);
			return {
				cloths: newClot
			};
		case "UPDATE":
			let newcl = state.cloths.map(obj => {
				if (obj.DressCode === action.detail.code) {
					return action.detail.newCloth;
				} else {
					return obj;
				}
			});
			return { cloths: newcl };

		default:
			return state;
	}
};

export default reducer;
