import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class Sample extends Component {
	render() {
		return (
			<div>
				<Link to="/add">add</Link>
				<br></br>
				<Link to="/list">list</Link>
				<br></br>
			</div>
		);
	}
}
