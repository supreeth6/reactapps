import React, { Component } from "react";
import { connect } from "react-redux";
import { update } from "../actions/action";
class Update extends Component {
	constructor(props) {
		super(props);
		this.state = {
			details: {
				DressCode: this.props.details.DressCode,
				Brand: this.props.details.Brand,
				Gender: this.props.details.Gender,
				Type: this.props.details.Type,
				Price: this.props.details.Price,
				Stock: this.props.details.Stock
			}
		};
	}
	submit = () => {
		let { dispatch } = this.props;
		dispatch(update(this.state.details, this.props.details.DressCode));
	};
	onModelChange = event => {
		console.log(event.target.value);
		let name = event.target.name;

		let value = event.target.value;
		this.setState(prevState => ({
			details: {
				...prevState.details,
				[name]: value
			}
		}));
	};
	render() {
		console.log(this.props);
		return (
			<div>
				DressCode:{" "}
				<input
					type="text"
					onChange={this.onModelChange}
					name="DressCode"
					defaultValue={this.props.details.DressCode}
				/>
				<br></br>
				Brand:
				<input
					type="text"
					onChange={this.onModelChange}
					name="Brand"
					defaultValue={this.props.details.Brand}
				/>
				<br></br>
				Gender: Male
				<input
					onChange={this.onModelChange}
					type="radio"
					name="Gender"
					value="Male"
				/>
				Female
				<input
					onChange={this.onModelChange}
					type="radio"
					name="Gender"
					value="Female"
				/>
				<br></br>
				Type:
				<input
					onChange={this.onModelChange}
					type="text"
					name="Type"
					defaultValue={this.props.details.Type}
				/>
				<br></br>
				Price:
				<input
					onChange={this.onModelChange}
					type="number"
					name="Price"
					defaultValue={this.props.details.Price}
				/>
				<br></br>
				Stock:
				<input
					onChange={this.onModelChange}
					type="number"
					name="Stock"
					defaultValue={this.props.details.Stock}
				/>
				<br></br>
				<button onClick={this.submit}>Submit</button>
			</div>
		);
	}
}
function mapStateToProps(state) {
	//	console.log("hello", state);
	return {};
}

export default connect(mapStateToProps)(Update);
