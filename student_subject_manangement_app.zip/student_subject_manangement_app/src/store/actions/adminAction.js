import {
    ADD_SUBJECT,
    DELETE_SUJECT,
    UPDATE_SUBJECT,
    ADD_CURRENT_UPDATE_SUBJECT,
    HANDLE_CURRENT_UPDATED_SUBJECT,
    ADD_STUDENT,
    LOGIN,
    ADD_ADMIN,
    LIST_OF_ADMIN,
    ADMIN,
    LOGOUT,
    RESET_SUBJECT
    
} from '../constants/action-types';

//for login only
export function login(payload){
    return{type:LOGIN, payload:payload}
}
export function admin(payload){
    return{type:ADMIN,payload:payload}
}
export function logout(payload){
    return{type:LOGOUT,payload:payload}
}
//for adding the subject 
export function addSubjects(payload){
    return { type: ADD_SUBJECT, payload: payload}
}
export function updateSubjects(payload){
    return {type:UPDATE_SUBJECT,payload:payload}}

export function addRecientUpdatedSubject(payload){
    return {type:ADD_CURRENT_UPDATE_SUBJECT,payload:payload}
}
export function handleRecientUpdatedSubject(payload){
    return {type:HANDLE_CURRENT_UPDATED_SUBJECT,payload:payload}
}
export function deleteSubject(payload){
    return {type:DELETE_SUJECT,payload:payload}
}

//for adding the students only
export function addStudents(payload){
    return {type:ADD_STUDENT,payload:payload}
}
export function resetSubjects(){
    return{type:RESET_SUBJECT}
}
export function listSubject(payload) {
	return { type: "LIST_OF_SUBJECT", payload: payload };
}

//for admin addition only
export function addAdmins(payload){
    return{type:ADD_ADMIN,payload:payload}
}
export function listOfAdmins(payload){
    return {type:LIST_OF_ADMIN,payload:payload}
}