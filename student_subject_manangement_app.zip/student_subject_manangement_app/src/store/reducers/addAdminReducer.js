import {ADD_ADMIN,LIST_OF_ADMIN} from '../constants/action-types';
const initialState = {
    admins:[],
    listofadmins:[]
};
 const addAdminReducer = (state=initialState,action)=>{
    switch (action.type){
        case ADD_ADMIN :{
        return {
            ...state,
            admins:[...state.admins,action.payload]
        };
        
    }
    case LIST_OF_ADMIN:{
        return{
            ...state ,
            listofadmins:[...state,...action.payload]
        }
    }
    default:return state;
        
    }
}
export default  addAdminReducer;