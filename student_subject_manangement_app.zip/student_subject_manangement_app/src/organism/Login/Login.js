import React from 'react';
import {connect} from 'react-redux';
import * as Yup from "yup";
import { login,admin } from "../../store/actions/adminAction";
import {withRouter} from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Button from '../../atoms/Button';
import InputField from '../../atoms/InputField';
import {Formik,Form,ErrorMessage} from 'formik';
import CssBaseline from '@material-ui/core/CssBaseline';
import Container from '@material-ui/core/Container';
import { makeStyles } from '@material-ui/core/styles';
import Field from '../../molecules/Form/FormFields';
import TitleComponent from '../../atoms/TitleComponent';
const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

 function  Login(props)
 {
    const classes = useStyles();
        return (  
        <Container component="main" maxWidth="xs">
         <CssBaseline />
        <div className={classes.paper}>
     <TitleComponent>login</TitleComponent>
        <Formik initialValues={{
            email:'',
            password:''
      
          }}
          validationSchema={Yup.object().shape({
            email:Yup.string().email("enter a valid email").required("this is required field")
            .max(35,"email not more than 35 char").matches(/^[A-Za-z].*$/,"email should not start with number or special char"),
            password:Yup.string().required("it is required field"),
           
          })}
         onSubmit={(fields)=>{
          console.log(props);


         console.log(fields);
         props.dispatch(login(fields))      
         console.log(props.users.students);
         console.log(props.login);
         
         console.log(props.login.isAdmin===true);
         if(props.login.isAdmin===true &&props.login.password===fields.password )
         {
           props.history.push('/dashboard');
         }
         else if (props.users.students.length > 0) {
           if(
            props.users.students.find(
              (object) =>
                object["email"] === fields.email &&
                object["password"] === fields.password 
            )
          ) {
            // console.log("admin");
            // props.dispatch(admin());
            props.history.push(`/`);
          }
          else {
             alert("invalid user");
            console.log("not a valid user");
          }
        } else alert("invalid user");
   }}
          // } else if (
          //   props.users.students.find(
          //     (object) =>
          //       object["email"] === fields.email &&
          //       object["password"] === fields.password &&
          //       object["roll"] === fields.password 
          //     )){

          
          // ) {
          //   // props.history.push(`/usereventlist/?email:${fields.email}`);
          //   props.history.push(`/listSubject`);
        //  else{ 
        //    alldetails.map((item)=>{
        //     console.log(item);
        //     if(item.password === item.passwords){
        //       props.history.push('/listSubject');
        //     }
        //    })
           
           
        //  }}}
         >
        {({values,isValid ,touched,errors,dirty})=>(
        <Form className={classes.form} >
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Field
                type="input" placeholder="email"   
                as={InputField} 
                label="email"
                value={values.email}
                variant="outlined"
                fullWidth
                autoComplete="email"
                name="email"
                className={"form-control"+(errors.email && touched.email ? "is-invalid":"")}  
              />
              <ErrorMessage name="email" component="div"/>
            </Grid>
            
            <Grid item xs={12}>
              <Field
              name="password"
              label="password"
               type="password"
               placeholder="password"
               as={InputField}
                variant="outlined"
                value={values.password}
                fullWidth
                className = {"form-control"+(errors.password && touched.password ? "is-invalid":"")}
                autoComplete="password"
              />
               <ErrorMessage name="password" component="div"/>
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            disabled={!dirty || !isValid}
          >
           Login
          </Button>
        </Form>
         )}
        </Formik>
      </div>
    </Container>
  );
}
const mapStateToProps = state => {
	console.log(state);
    
  return {users: state.students,
  login:state.login};
};
export default withRouter(connect(mapStateToProps,null)(Login))

