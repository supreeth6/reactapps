import React from 'react';
import { Switch, Route} from 'react-router-dom';
import AddSubject from '../pages/Dashboard/AddSubject';
import Dashboard from '../pages/Dashboard/Header';
import Home from '../pages/Home/Home';
import LogoutView from '../pages';
import PrivateRoute from './PrivateRouter';
import Header from '../pages/Home/Header';
import AddStudent from '../pages/Dashboard/AddStudent';
import ListSubject from '../pages/Dashboard/ListSubject';
import UpdateSubject from '../pages/Dashboard/Updated';
import ListOfStudents from '../pages/Dashboard/ListOfStudents';
import Login from '../organism/Login/Login';
import NewListOfSubject from '../pages/NewListOfSubject';
const Router = (props) => (
<Switch>
<Route exact path="/login" component={Login}></Route>
<Route exact path="/logout" component={LogoutView}></Route>
<PrivateRoute exact path='/dashboard' component={Dashboard}/>
<Route  exact path="/" component={Header}/>
<Route exact path='/addSubject' component={AddSubject}/> 
<PrivateRoute exact path='/listSubject' component={ListSubject}/> 
<Route exact path='/addStudent' component={AddStudent}></Route>
 <Route exact path='/updatesubject' component={UpdateSubject}/>
 <Route exact path='/listofsubjects' component={ListSubject}/>
<Route exact path='/newlistofsubject' component={NewListOfSubject}/>
</Switch>
)
 
export default Router;