import React from 'react';
import AddStudents from '../../organism/Students/AddStudents';


function AddStudent() {
  return (   
    <div>
   <AddStudents/>
   </div>
  );
}

export default AddStudent;
