import React from 'react'
import Header from './index'
import { Container } from '@material-ui/core'

export default function dashboard() {
    return (
        <div>
            
            <Header/>
        
        </div>
    )
}
