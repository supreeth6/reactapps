import React from 'react';
import { Link } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    justifyContent: 'space-around',
    backgroundColor:'black',
    color:'white'
   
  },
  menuButton: {
    marginRight: theme.spacing(2),
    color:'white'
  },
  title: {
    flexGrow: 1,
    color:'white'
  },
}));

export default function Header() {
  const classes = useStyles();

  return (
    <div className={classes.root} >
      <AppBar position="static" >
        <Toolbar className={classes.root}>
          <Typography variant="h6" className={classes.root}>
        Admin 
          </Typography>
          <Typography className={classes.root}> <Link to="/dashboard">Dashboard</Link></Typography>
          <Typography className={classes.root}> <Link to="/addSubject">Add Subject</Link></Typography>
          <Typography className={classes.root}> <Link to="/listSubject">List Subject</Link></Typography>
          <Typography className={classes.root}> <Link to="/updatesubject">Update Subject</Link></Typography>
          <Typography className={classes.root}> <Link to="/addStudent">Add Student </Link></Typography>
          <Typography className={classes.root}> <Link to="/listOfStudents">List of Student </Link></Typography>

        </Toolbar>
      </AppBar>
    </div>
  );
}
