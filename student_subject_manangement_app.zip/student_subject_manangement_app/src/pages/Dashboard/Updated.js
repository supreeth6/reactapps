import React from 'react';
import Update from '../../organism/Subjects/Update';


function UpdatedSubject() {
  return (   
    <div>
 <Update/>
   </div>
  );
}

export default UpdatedSubject;
