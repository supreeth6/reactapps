import React from 'react'
import  FormControl from '../organism/FormControl';
import Toolbar from '@material-ui/core/Toolbar';

function NewListOfSubject() {
    return (
        <Toolbar>
       <FormControl/>
      </Toolbar>
    )
}

export default NewListOfSubject
