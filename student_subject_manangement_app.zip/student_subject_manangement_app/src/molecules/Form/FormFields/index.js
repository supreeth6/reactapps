import React from 'react';
import {Field } from 'formik';
import label from '../../../atoms/Label';
import PropTypes from 'prop-types';
import InputField from '../../../atoms/InputField';

const Fields = ({
  name,
  label,
  type = 'text',
  required = false,
}) => {
  return (
    <Field
      required={required}
      autoComplete="off"
      as={InputField}
      label={label}
      name={name}
      variant="outlined"
      margin="normal"
      fullWidth
      type={type}
    />
  );
};
Field.propTypes = {
  name: PropTypes.string,
  type: PropTypes.string,
  required: PropTypes.bool,
  label: PropTypes.string,
//   error: PropTypes.string,
};
export default Fields;
