import React from 'react';
import { ErrorMessage, Field } from 'formik';
import InputFields from '../atoms/InputField';
import PropTypes from 'prop-types';
import Label from '../atoms/Label';
const FormikField = ({
  name,
  type = 'text',
  required = false,
  error,
}) => {
  return (
    <Field
      required={required}
      autoComplete="off"
      as={InputFields}
      label={Label}
      name={name}
      fullWidth
      type={type}
      error={error}
      helperText={<ErrorMessage name={name} />}
    />
  );
};
FormikField.propTypes = {
  name: PropTypes.string,
  type: PropTypes.string,
  required: PropTypes.bool,
  label: PropTypes.string,
  error: PropTypes.string,
};
export default FormikField;
