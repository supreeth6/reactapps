import React from 'react';
import { FormLabel } from '@material-ui/core';
import PropTypes from 'prop-types';
const label = props => {
  return (
    <div>
      <FormLabel component="label">{props.name}</FormLabel>
    </div>
  );
};
label.propTypes = {
  name: PropTypes.string,
};
export default label;
