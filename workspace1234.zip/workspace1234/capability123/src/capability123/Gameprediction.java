package capability123;

import java.util.Scanner;

public class Gameprediction {
	static int n;
	static int r=0;
	static int win2=0;
	static String[] tn=new String[n];
	 static int mat[]=new int[n];
	 static int goals[]=new int[n];
	 static int players[]=new int[n];
	 static int pid[]=new int[n];
	 static int amt[]=new int[n];

	 static Scanner scan=new Scanner(System.in);
	public static void main(String args[]) {
	// static Scanner scan=new Scanner(System.in);
		 boolean d=true;
			while(d) {
				System.out.println("press 1 to take the input for team details and betting details");
				System.out.println("press 2 for insertion sort ");
				System.out.println("press 3 to predict the team which is going to win");
				System.out.println("press 4 to binary search");
				System.out.println("press 5 to exit");
				System.out.println();
				System.out.println("enter your choice");
				int choice=scan.nextInt();
				switch(choice)
				{
				case 1:InputTeamDetails();
				       InputBettingDetails();
				       break;
				case 2:System.out.println(insertionsort(pid)); 
						 break;
				case 3:Predict(tn);
				       break;
				case 4: 
					   Bsearch(pid);
				       break;
				case 5:System.out.println("done");
				       d=false;
				       System.exit(0);
				default:System.out.println("enter the correct choice");       
					
				}
			}
		}
	
	public static int InputTeamDetails() {
		
		System.out.println("enter the no of teams");
		  n=scan.nextInt();
		String[] tn=new String[n];
		int mat[]=new int[n];
		int goals[]=new int[n];
		String city[]=new String[n];
		int players[]=new int[n];
		 r=0;
		while(r!=n) {
		System.out.println("enter the team name");
		tn[r]=scan.next();
		System.out.println("enter the matches played");
		mat[r]=scan.nextInt();
		System.out.println("enter the no of goals");
		goals[r]=scan.nextInt();
		System.out.println("enter the city");
		city[r]=scan.next();
		System.out.println("enter the no of players");
		players[r]=scan.nextInt();
		r++;
		
	}
		//InputBettingDetails();
		return 1;
		//System.out.println(tn);
		//System.out.println(mat);
		//System.out.println(goals);
		//System.out.println(city);
		//System.out.println(players);
	}
	public static void InputBettingDetails() {
		int pid[]=new int[n];
	//	int amt[]=new int[n];
	//	int tn2[]=new int[n];
		System.out.println("betting details");
		while(r!=n) {
			System.out.println("enter the person id");
			pid[r]=scan.nextInt();
			System.out.println("on which team the betting is on");
			tn[r]=scan.next();
			System.out.println("enter the amount");
			amt[r]=scan.nextInt();
		}
	}
	public static void Predict(String tn[]) {
		int win1[]=new int[n];
		// win1=0;
		//int win2=0;
		for(int i=0;i<n;i++) {
		win1[i]=mat[i]*goals[i];
		win2=win1[i]/players[i];
		System.out.println(win2);
		
		}
	}
	public static void Bsearch(int[] result1) {
		
		int first=0;
		int last=result1.length-1;
		int key;
		System.out.println("binary search");
		System.out.println("enter the element to search");
		key=scan.nextInt();
		int mid=(first+last)/2;
				
		while(first <= last)
		{
			mid=(first+last)/2;
			if(result1[mid] == key)
			{
				for(int i=0;i<n;i++) {
				if(win2>pid[i])
				System.out.println("won"+amt[i]);
				else
				{
					System.out.println("lost"+amt[i]);
				}
				return;
			}
			}
			if(result1[mid] < key)
				first = mid+1;
			else
				last = mid-1;
		}
		System.out.println("Element not found");
	}
	
	
	public static int[] insertionsort(int[]result1){
		InputBettingDetails();
		int n=result1.length;
		System.out.println("insertion sort");
		for(int i=0;i<n;i++) {
			int key=result1[i];
			int j=i-1;
			while((j>-1) &&(result1[j]>key) ) {
				result1[j+1]=result1[j];
				j--;
			}
			result1[j+1]=key;
		}
		for (int i = 0; i < result1.length; i++) 
		{
			System.out.print(result1[i]+" ");
		}
		System.out.println();
		
		return result1;
	}


		
	}



