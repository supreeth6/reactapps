import React, { Component } from "react";
function Show(params) {
	let { details } = params;
	console.log("this is the props", params);
	console.log("fghjp", params.name);
	return (
		<div>
			<h3>Name:{details.name}</h3>
			<h3>Email:{details.email}</h3>
			<h3>Password:{details.password}</h3>
			<h3>Gender:{details.gender}</h3>
			<h3>Skills:{details.skills}</h3>
			<h3>Hobbies:{details.hobbies}</h3>
			<h3>Quali:{details.higest}</h3>
		</div>
	);
}

class App extends Component {
	constructor() {
		super();
		this.state = {
			details: {
				name: "",
				email: "",
				password: "",
				gender: "",
				skills: [],
				hobbies: "",
				higest: ""
			},
			flag: false
		};
	}

	onModelChange = event => {
		//e	console.log(event.target.value);
		let name = event.target.name;

		let value = event.target.value;
		this.setState(prevState => ({
			details: {
				...prevState.details,
				[name]: value
			}
		}));
	};
	// name = e => {
	// 	console.log(e.target.value);
	// 	this.setState({ name: e.target.value });
	// };
	// email = e => {
	// 	this.setState({ email: e.target.value });
	// };
	// password = e => {
	// 	this.setState({ password: e.target.value });
	// };

	// genderMale = e => {
	// 	//	console.log("pass", e.target.value);
	// 	this.setState({ gender: "Male" });
	// };
	// genderFemale = e => {
	// 	//	console.log("pass", e.target.value);
	// 	this.setState({ gender: "Female" });
	// };
	// hobbies = e => {
	// 	console.log(typeof e);
	// 	this.setState({ hobbies: e.target.value });
	// };
	change = e => {
		console.log(e);
		//this.setState({ details.flag: true });
		this.setState({
			flag: true
		});
	};

	render() {
		console.log(this.state.details);
		console.log("name", this.state.details.name);
		console.log("email", this.state.email);
		console.log("pass", this.state.password);
		console.log("gen", this.state.gender);
		console.log("hobbies", this.state.hobbies);
		return (
			<div>
				<form>
					Name:
					<input type="text" name="name" onChange={this.onModelChange} />
					<br></br>
					Email:
					<input type="text" name="email" onChange={this.onModelChange} />
					<br></br>
					password:
					<input
						type="password"
						name="password"
						onChange={this.onModelChange}
					/>
					<br></br>
					Gender:
					<input
						onChange={this.onModelChange}
						type="radio"
						name="gender"
						value="Male"
					/>
					Male
					<input
						onChange={this.onModelChange}
						type="radio"
						name="gender"
						value="Female"
					/>
					Female <br></br>Skills:
					<input
						onChange={this.onModelChange}
						type="checkbox"
						value="HTML"
						name="skills"
					/>
					HTML
					<input
						onChange={this.onModelChange}
						type="checkbox"
						name="skills"
						value="CSS"
					/>
					CSS <input type="checkbox" name="skills" value="JS" />
					JS <input type="checkbox" name="skills" value="MONGODB" />
					MONGODB <input type="checkbox" name="skills" value="CSS" />
					EXPRESS <input type="checkbox" name="skills" value="CSS" />
					NODEJS <input type="checkbox" name="skills" value="CSS" />
					REACTJS
					<input type="checkbox" name="skills" value="CSS" />
					ANGULAR
					<br></br>
					Hobbies:
					<textarea onChange={this.onModelChange} name="hobbies"></textarea>
					<br></br>
					Highest Quali: skills:
					<select name="higest" onChange={this.onModelChange}>
						<option>10TH</option>
						<option>12TH</option>
						<option>B.TECH</option>
						<option>M.TECH</option>
					</select>
					<br></br>
				</form>
				<button onClick={this.change}>submit</button>
				{this.state.flag && (
					<div>
						<h1>Details</h1>
						<Show details={this.state.details} />
					</div>
				)}
			</div>
		);

		//<button onClick={this.change}>SUBMIT</button>
	}
}

export default App;
