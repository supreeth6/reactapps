export const addEmployee = (actionType, employee) => {
	console.log(employee);
	return {
		type: actionType,
		employee: employee,
	};
};

export const makeTeams = (actionType, teams) => {
	console.log(teams);
	return {
		type: actionType,
		teams: teams,
	};
};

export const receive_post = (post) => {
	return {
		type: "FETCHED_USER",
		data: post,
	};
};

export const thunk_action_creator = (username) => {
	// const user = username.replace(/\s/g, " ");
	// store.dispatch(fetch_post());
	console.log(username);
	return function (dispatch, getState) {
		return fetch(`https://api.github.com/users/rakeshgsharma`)
			.then((data) => data.json())
			.then((data) => {
				if (data.message === "Not Found") {
					throw new Error("no user found");
				} else dispatch(receive_post(data));
			});
	};
};
