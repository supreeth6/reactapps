import React, { Component } from "react";
import { connect } from "react-redux";
import { addEmployee } from "../action/Actions";
import { thunk_action_creator } from "../action/Actions";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

class AddEmployee extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detail: {
				empname: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detail: {
				...this.state.detail,
				[name]: value,
			},
		});
	};
	addList = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addEmployee("ADD_EMPLOYEE", this.state.detail));
		dispatch(thunk_action_creator("FETCHED_USER", this.state.detail));
	};

	render() {
		return (
			<div>
				<form>
					<div>
						<label>
							Employee Name
							<br />
							<TextField
								id="filled-basic"
								varient="filled-basic"
								type="text"
								name="empname"
								//value={this.state.code}
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						color="primary"
						onClick={this.addList}
					>
						Submit
					</Button>
				</form>
			</div>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		employees: state,
	};
};

export default connect(mapStateToProps)(AddEmployee);
