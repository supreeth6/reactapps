import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

class ViewTeams extends Component {
	render() {
		return (
			<TableContainer component={Paper}>
				<Table aria-label="simple table">
					<TableHead>
						<TableRow>
							<TableCell>Team name</TableCell>
							<TableCell>Team owner</TableCell>
							<TableCell>Teammates</TableCell>
							<TableCell>Description</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.teamss.team.map((team, index) => {
							console.log(team);
							return (
								<TableRow key={index}>
									<TableCell>{team.teams.nameofteam}</TableCell>
									<TableCell>{team.teams.ownerofteam}</TableCell>
									<TableCell>{team.teams.addteammates}</TableCell>
									<TableCell>{team.teams.description}</TableCell>
								</TableRow>
							);
						})}
						{/* <p> {this.props.teamss.userData}</p> */}
						{/* {this.props.teamss.userData.map((us, id) => {
							console.log(us);
							// return (
							// 	<TableRow key={id}>
							// 		<TableCell>{us.userData.login}</TableCell>
							// 	</TableRow>
							// );
						})} */}
					</TableBody>
				</Table>
			</TableContainer>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		teamss: state,
	};
};
export default connect(mapStateToProps)(ViewTeams);
