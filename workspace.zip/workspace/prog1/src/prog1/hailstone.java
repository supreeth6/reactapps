package prog1;

import java.util.Scanner;

public class hailstone {
	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter a number");
	    int n=s.nextInt();
	   
	    int count=0;
	    while(n!=1) {
	    	 int number=n;
	    	if(n%2==0) {
	    		n=n/2;
	    		System.out.println(+number+"is even so i take half:"+n);
	    		
	    	}
	    	else {
	    		n=3*n+1;	
	    	System.out.println(+number+"is odd so i make 3n+1:"+n);
	    	
	    	}
	    	count++;
	    }
	    System.out.println("Thereare total"+count+"steps to reach 1"  );
	}

}
