package prog1;

public class Factorial {
	public static void main(String args[]) {
		int num=5,fact=1;
		for(int j=num;j>1;j--) {
			fact=fact*j;
		}
		System.out.println("the factorial of"+num+ "is" +fact );
		
		
	}

}
