package prog1;

import java.util.Scanner;

public class progfive {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int employeeid=scan.nextInt();
		String jobband=scan.next();
		int deptcode=scan.nextInt();
		if(validjobbond(jobband)&&validdeptcode(deptcode)) {
			System.out.println(employeeid);
			
			
		}
		else {
			System.out.println("error");
		}
		
		
		
		
	}
	static boolean validjobbond( String jobband) {
		if(jobband.equals("c1")||jobband.equals("c2")||
				jobband.equals("c3")||jobband.equals("c4")) {
			
			return true;
		}
		else
			return false;
	}
		
	
	static boolean validdeptcode( int deptcode) {
		if(deptcode>110&& deptcode<125) {
			
			return true;
		}
		else
			return false;

}
}
