package prog1;

import java.util.Scanner;

public class program {
	public static void main(String args[]) {
	Scanner s=new Scanner(System.in);
	int n1=s.nextInt();
	int n2=s.nextInt();
	int count=0;
	if(n1>n2) {
		System.out.println("Invalid");
		System.exit(0);
	}
	else if(n1<=0||n2<=0){
		System.out.println("Print Invalid");
		System.exit(0);
	}
	else {
		while(count<10) {
			
			 n1=n1+n2;
			 n2=n2+10;
			System.out.println(+n1+ "and"+n2);
			count ++;
			
		}
	}
	}
}



