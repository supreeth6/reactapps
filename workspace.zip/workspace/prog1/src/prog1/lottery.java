package prog1;

import java.util.Scanner;

public class lottery {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int b=scan.nextInt();
		int c=scan.nextInt();
		if(a!=b && b!=c && c!=a) 
		{
			System.out.println("0");
		}
		else if(a==b && b==c) 
		{
			System.out.println("20");
		}
			else if(a==b || b==c || c==a) {
				System.out.println("10");
			}
		}
	}


