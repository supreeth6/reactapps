package prog1;

public class multi {
	public static void main(String args[]) {
		int i,number=10,result;
		for(i=1;i<=12;i++) {
			result=number*i;
			System.out.println(+number+"x"+i+"="+result);
		}
		
	}

}
