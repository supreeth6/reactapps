package prog1;

public class kalinga {
	public static void main(String[]args) {
		System.out.println("hello minds");
	}

}
