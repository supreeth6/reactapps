package prog1;

import java.util.Scanner;

public class lcm {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int b=scan.nextInt();
		int c=lcms(a,b);
		int d=gcds(a,b,c);
		System.out.println("lcm"+c+"gcd"+d);
		
		
	}
	public static int lcms(int a,int b){
		int large;
		if(a>b) {
			large=a;
		}
		else {
			large=b;
		}
		while(true) {
			if(large%a==0&& large%b==0) {
				return large;
			}
			large++;
		}
		
		
		
	}
	public static int gcds(int a,int b,int c) {
		return a*b/c;
		
	}

}
