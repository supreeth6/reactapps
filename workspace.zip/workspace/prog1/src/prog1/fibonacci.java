package prog1;

import java.util.Scanner;

public class fibonacci {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		
		
		System.out.println(evenFibonacciSum(n));
	}
		
	
	public static int evenFibonacciSum(Integer n){
		Scanner scan=new Scanner(System.in);
		int result=0;
		int a=0;
		int b=1;
		while(a+b<n) {
		int sum=a+b;
		a=b;
		b=sum;
		if(sum%2==0) {
			 result=result+sum;
		
		}
			
		}
		return result;
		
		
	} 

}
	
