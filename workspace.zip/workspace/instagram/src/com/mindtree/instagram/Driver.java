package com.mindtree.instagram;

public class Driver {

	public static void main(String[] args) {

		Instagram nidhi = new Instagram("nidhiR", "RanveerIsAwesome", 1000, 5, "Default");
		Instagram atul = new Instagram("nidhiR", "RanveerIsAwesome", 1000, 5, "Default");
		if (nidhi.equals(atul)) {
			System.out.println(true);
		} else {
			System.err.println(false);
		}

	}

}
