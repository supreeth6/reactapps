package prog3;

import java.util.Scanner;

public class searchsort {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the choice");
		int ch=scan.nextInt();
		switch(ch) {
		case 1:
			   System.out.println("enter the number of elements in array");
			   int n=scan.nextInt();
			   String arr[]=new String[n];
			   System.out.println("enter the elements");
			   for(int i=0;i<n;i++) {
				   arr[i]=scan.next();
			   }
			   int num=arr.length;
			   String temp;
			   for(int i=0;i<num;i++) {
				   for(int j=0;j<num-i-1;j++) {
					   if(arr[j].charAt(0)>arr[j+1].charAt(0)) {
						   temp=arr[j];
						   arr[j]=arr[j+1];
						   arr[j+1]=temp;
					   }
				   }
			   }
			   for(int k=0;k<num;k++) {
			   System.out.println(arr[k]);
			   }
		case 2:	System.out.println("enter the no of elements in array");
				int n1=scan.nextInt();
				System.out.println("enter the elements in an array");
				String arr1[]=new String[n1];
				for(int i=0;i<n1;i++) {
					arr1[i]=scan.next();
				}
				int num1=arr1.length;
				for(int j=1;j<n1;j++) {
					String pos=arr1[j];
					int i=j-1;
					while((i>-1)&& (arr1[i].compareTo(pos)>0)) {
						arr1[i+1]=arr1[i];
						i--;
					}
					arr1[i+1]=pos;
				}
				for(int i=0;i<n1;i++) {
				System.out.println(arr1[i]);
			}
		case 3:System.out.println("enter the no of elements in array");
		       int a=scan.nextInt();
	           System.out.println("enter the elements in array");
		       String arr2[]= new String[a];
		       for(int i=0;i<a;i++) {
			   arr2[i]=scan.next();
		       }
		       int a1=arr2.length;
				int flag=0;
				System.out.println("enter the key element");
				String key=scan.next();
				for(int i=0;i<a;i++) {
					if(key.equals(arr2[i])) {
						flag=1;
					System.out.println(" key found");	
						
					}
				}
				
				if(flag==0)
				{
					System.out.println(" not found");
				}
		case 4:	System.exit(0);
					
				
				
			}

			
				}
				}
				
