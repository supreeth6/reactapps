package prog3;

import java.util.Scanner;

public class musicRoom {
	public static void main(String args[]) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the length of room");
		int n=scanner.nextInt();
		System.out.println("enter the breadth of room");
		int m=scanner.nextInt();
		String arr[][]=new String[n][m];
		System.out.println("enter the person names");
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
		arr[i][j]=scanner.next();
			}
		}
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				if(arr[i][j].equals(arr[i][j+1])){
	                arr[i][j+1] = arr[i][j+1];
	            }
				

			}
		}
		System.out.println("Matrix");
        for(int i=0; i < arr.length; i++){
            for(int j=0; j < arr[i].length-1; j++){

                System.out.println("[" +(i) + "][" + (j) + "]= " + arr[i][j] + " [" + (i) + "][" + (j+1) + "]= " + arr[i][j+1]  );
            }

        }
    
	
		for( int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				arr[0][n]=arr[0][0];
				arr[0][0]=arr[m][0];
				arr[m][0]=arr[m][n];
				arr[m][n]=arr[0][n];
				System.out.println(arr[i][j]);
			}
		}
		String result1[]=new String[arr.length];
		if(m%2!=2) {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
                
        	 result1[i]=arr[i][j];
         
			}
		}
		}
		
		String[] s1=result1;
		System.out.println("");
		String s="";
		int count=0;
		for(int i1=0;i1<arr.length;i1++)
		{
			if(arr.length!=' ')
			{
				s=s+arr.length;
			}
			else
			{
				s1[count]=s;
				s="";
				count++;
			}
		}
		s1[count]=s;
		s="";
		for(int i1=0;i1<=count;i1++)
		{
			System.out.println(s1[i1]);
			
				if(s1[i1].charAt(0)>='a' && s1[i1].charAt(0)<='z')
				{
					s=s+(char)(s1[i1].charAt(0)-32);
				}
				else if(s1[i1].charAt(0)>='A' && s1[i1].charAt(0)<='Z')
				{
					s=s+(char)(s1[i1].charAt(0)+32);
				}
				else {
					s=s+(s1[i1].charAt(0));
				}
				for(int k=1;k<s1[i1].length()-1;k++)
				{
					if(s1[i1].charAt(k)>='A' && s1[i1].charAt(k)<='Z')
					{
						s=s+(char)(s1[i1].charAt(k)+32);
					}
					else {
						s=s+(s1[i1].charAt(k));
					}
				}
				if(s1[i1].charAt(s1[i1].length()-1)>='a' && s1[i1].charAt(s1[i1].length()-1)<='z')
				{
					s=s+(char)(s1[i1].charAt(s1[i1].length()-1)-32);
				}
				else if(s1[i1].charAt(s1[i1].length()-1)>='A' && s1[i1].charAt(s1[i1].length()-1)<='Z')
				{
					s=s+(char)(s1[i1].charAt(s1[i1].length()-1)+32);
				}
				else {
					s=s+(s1[i1].charAt(s1[i1].length()-1));
				}
			
			System.out.println(s);
			s="";
		}
		
	

	String result2[]=new String[arr.length];

	for(int i=0;i<arr.length;i++) {
		for(int j=0;j<arr.length;j++) {
            if(i==j) {
    	 result2[i]=arr[i][j];
     
		}
	}
	}
	int low=0;
	int high=arr.length-1;
	int mid=low+high/2;
	String key1="fgh";
	while(high>=low)
	{
		
	if(arr[mid].equals(key1)) {
		System.out.println("element found");;
	}
	else if(arr[mid].charAt(0)<key1.charAt(0)){
		high=mid-1;
		mid=(high+low)/2;
	}
	else if(arr[mid].charAt(0)>key1.charAt(0)) {
		low=mid+1;
		mid=(high+low)/2;
	}
}
	System.out.println("element not found");;

		
	}
}



