package prog3;

import java.util.Scanner;

public class alternatecase {
	static Scanner scan= new Scanner(System.in);
	public static void ConvertToUCnLC()
	{
		String string;
		System.out.println("enter the string");
		string=scan.next();
		String resulting="";
		for(int i=0;i<string.length();i++)
		{
			if(i%2==0) {
				resulting+=string.charAt(i);
			}
			else if(i%2==1)
			{
				if(string.charAt(i)>=97 && string.charAt(i)<=122)
				{
					resulting+=(char)(string.charAt(i)-32);
				}
				else {
					resulting+=string.charAt(i);
				}
			}
			else if(string.charAt(i)==32) {
				resulting+=(char)32;
			}
		}
		System.out.println(resulting);
		
	}
	public static void Replace()
	{
		String str;
		System.out.println("enter the string");
		str=scan.next();
		int count=0;
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='o'||str.charAt(i)=='o')
			{
				count++;
			}
		}
		if(count>2)
		{
			for(int k=0;k<str.length();k++)
			{
				if(str.charAt(k)=='o'|| str.charAt(k)=='o') {
					char c=' ';
					c=str.charAt(k);
					c='@';
				}
			}
		}
		System.out.println(str);
	}
	public static void main(String[] args) {
		while(true) {}
	}

}
