package prog3;

import java.util.Scanner;

public class insertionsort {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the no of elements in array");
		int n=scan.nextInt();
		System.out.println("enter the elements in an array");
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=scan.nextInt();
		}
		insertsort(arr);
	}
public static void insertsort(int[]arr) {
	int n=arr.length;
	for(int j=1;j<n;j++) {
		int pos=arr[j];
		int i=j-1;
		while((i>-1)&& (arr[i]>pos)) {
			arr[i+1]=arr[i];
			i--;
		}
		arr[i+1]=pos;
	}
	for(int i=0;i<n;i++) {
	System.out.println(arr[i]);
}
}
}
