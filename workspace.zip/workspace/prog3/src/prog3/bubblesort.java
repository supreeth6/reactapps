package prog3;

import java.util.Scanner;

public class bubblesort {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the number of elements in array");
		int n=scan.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=scan.nextInt();
		}
		int result[]=bsort(arr);
		for(int i=0;i<arr.length;i++) {
			System.out.println(result[i]);
		}
	
	}
	public static int[] bsort(int arr[]) {
		int n=arr.length;
		int temp;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n-i-1;j++) {
				if(arr[j]>arr[j+1]) {
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		return arr;
		
	}
}
