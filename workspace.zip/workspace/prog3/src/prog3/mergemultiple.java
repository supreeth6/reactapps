package prog3;

import java.util.Scanner;

public class mergemultiple {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int n=0,m=0,s=0;
		int a[][]=new int[n][m];
		int b[]=new int[m*n];
		System.out.println("enter the number of array");
		n=scan.nextInt();
		System.out.println("enter the size of array");
		m=scan.nextInt();
		for(int i=0;i<n;i++) {
			System.out.println("enter the"+ i+ "th array elements");
			for(int j=0;j<m;j++) {
				a[i][j]=scan.nextInt();
			}
		}
		for(int k=0;k<n;k++) {
			for(int l=0;l<m;l++) {
				b[s]=a[k][l];
				s++;
			}
		}
		int x=b.length;
		int temp=0;
		for(int i=0;i<x;i++) {
			for(int j=0;j<x-i-1;j++) {
				if(b[j]>b[j+1]) {
					temp=b[j];
					b[j]=b[j+1];
					b[j+1]=temp;
				}
			}
		}
		for(int i=0;i<x;i++)
		System.out.println(b[i]);
		
	}

}
