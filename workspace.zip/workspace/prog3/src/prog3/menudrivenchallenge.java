package prog3;

import java.util.Scanner;

//import org.omg.CORBA.PUBLIC_MEMBER;

import java.lang.*;

public class menudrivenchallenge {
	static Scanner scan = new Scanner(System.in);
	public static void main(String args[]) {
		while(true) {
			System.out.println("1.print at 3rd and 8th position");
			System.out.println("2.perform bubble sort");
			System.out.println("3.search for particular word");
			System.out.println("4.toggle the first and last character of each word");
			System.out.println("5.2d array operations");
			int choice;
			System.out.println();
			choice=scan.nextInt();
			switch(choice) {
			case 1:int arr[]=new int[10];
				   printdigits(arr);
				   break;
			case 2:String arr1[]=new String[5];
			       bubblesort(arr1);
				   break;
			case 3:
				   break;
			case 4:String a;
				   a="mindtree Kalinga";
				   togglestring1(a);
				   break;
			case 5:System.out.println("enter the elements for 2d array");
				    int arr2[][]=new int[3][3];
					for (int i = 0; i < arr2.length; i++) 
					{
						for (int j = 0; j < arr2.length; j++) 
						{
							arr2[i][j] = scan.nextInt();
						}
					}
				   convert(arr2);
				   break;
			default:
				System.out.println("invalid option");
			}
		
	}

}
	public static int printdigits(int[] arr) {
		System.out.println("enter the array");
		for(int i=0;i<arr.length;i++) {
			arr[i]=scan.nextInt();
		}
		for(int i=0;i<arr.length;i++) {
			if( i==2) {
			System.out.println(arr[i+1]);
		}
		
			if(i==7) {
				System.out.println(arr[i+1]);
			}
		}
		return 1;
	}
	public static int bubblesort(String[]arr1 ) {
		int n=arr1.length;
		   System.out.println("enter the elements");
		   for(int i=0;i<n;i++) {
			   arr1[i]=scan.next();
		   }
		   int num=arr1.length;
		   String temp;
		   for(int i=0;i<num;i++) {
			   for(int j=0;j<num-i-1;j++) {
				   if(arr1[j].charAt(0)>arr1[j+1].charAt(0)) {
					   temp=arr1[j];
					   arr1[j]=arr1[j+1];
					   arr1[j+1]=temp;
				   }
			   }
		   }
		   for(int k=0;k<num;k++) {
		   System.out.println(arr1[k]);
		   }
		   return 1;
	}
	public static  void togglestring1(String a) {
		String [] s1=new String[10];
		String s="";
		int count=0;
		for(int i=0;i<a.length();i++)
		{
			if(a.charAt(i)!=' ')
			{
				s=s+a.charAt(i);
			}
			else
			{
				s1[count]=s;
				s="";
				count++;
			}
		}
		s1[count]=s;
		s="";
		for(int i=0;i<=count;i++)
		{
			System.out.println(s1[i]);
			
				if(s1[i].charAt(0)>='a' && s1[i].charAt(0)<='z')
				{
					s=s+(char)(s1[i].charAt(0)-32);
				}
				else if(s1[i].charAt(0)>='A' && s1[i].charAt(0)<='Z')
				{
					s=s+(char)(s1[i].charAt(0)+32);
				}
				else {
					s=s+(s1[i].charAt(0));
				}
				for(int k=1;k<s1[i].length()-1;k++)
				{
					if(s1[i].charAt(k)>='A' && s1[i].charAt(k)<='Z')
					{
						s=s+(char)(s1[i].charAt(k)+32);
					}
					else {
						s=s+(s1[i].charAt(k));
					}
				}
				if(s1[i].charAt(s1[i].length()-1)>='a' && s1[i].charAt(s1[i].length()-1)<='z')
				{
					s=s+(char)(s1[i].charAt(s1[i].length()-1)-32);
				}
				else if(s1[i].charAt(s1[i].length()-1)>='A' && s1[i].charAt(s1[i].length()-1)<='Z')
				{
					s=s+(char)(s1[i].charAt(s1[i].length()-1)+32);
				}
				else {
					s=s+(s1[i].charAt(s1[i].length()-1));
				}
			
			System.out.println(s);
			s="";
		}
		
	}
	public static void convert(int[][] arr2) {
		int count=0;
		int result1[]=new int[arr2.length*arr2.length];
		
		for(int i=0;i<arr2.length;i++) {
			for(int j=0;j<arr2.length;j++) {
               
        	 result1[count++]=arr2[i][j];
			}
		}
			for (int i = 0; i < result1.length; i++)
			{
				System.out.print(result1[i]+" ");
			}
			System.out.println();
        	 int r3[]=new int[result1.length/2];
        	 for(int i=0;i<r3.length;i++) {
        		 r3[i]=result1[i];
        	 }
        	 int j=0;
        	 int r4[]=new int[result1.length/2+1];
        	 for(int i=r3.length;i<result1.length;i++) {
        		 r4[j++]=result1[i];
        	 }
        	 int result2[]=new int[result1.length];
        	  result2=bsort(r3);
        	  System.out.println(result2);
        	  int result4[]=new int[result1.length];
        	  result4=insertionsort(r4);
        	 
			
		
	
	
}
	public static int[]  bsort(int result1[]) {
		int n=result1.length;
		int temp;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n-i-1;j++) {
				if(result1[j]>result1[j+1]) {
					temp=result1[j];
					result1[j]=result1[j+1];
					result1[j+1]=temp;
				}
			}
		}
	//	insertionsort(result1);
		
		for (int i = 0; i < result1.length; i++) 
		{
			System.out.println(result1[i]+" ");
		}
		 Bsearch(result1);
		 System.out.println();
		return result1;
		
	}
		
	public static int[] insertionsort(int[]result1){
		int n=result1.length;
		for(int i=0;i<n;i++) {
			int key=result1[i];
			int j=i-1;
			while((j>-1) &&(result1[j]>key) ) {
				result1[j+1]=result1[j];
				j--;
			}
			result1[j+1]=key;
		}
		for (int i = 0; i < result1.length; i++) 
		{
			System.out.print(result1[i]+" ");
		}
		System.out.println();
		Bsearch(result1);
		return result1;
	}
	public static void Bsearch(int[] result1) {
	
		int first=0;
		int last=result1.length-1;
		int key;
		System.out.println("enter the element to search");
		key=scan.nextInt();
		int mid=(first+last)/2;
		
		while(first <= last)
		{
			mid=(first+last)/2;
			if(result1[mid] == key)
			{
				System.out.println("Element found");
				return;
			}
			if(result1[mid] < key)
				first = mid+1;
			else
				last = mid-1;
		}
		System.out.println("Element not found");
	}

}
