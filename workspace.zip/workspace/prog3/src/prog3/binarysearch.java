package prog3;

import java.util.Scanner;

public class binarysearch {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the choice");
		int ch=scan.nextInt();
		switch(ch) {
		case 1:System.out.println("enter the no of elements in array");
	        	int n=scan.nextInt();
		        System.out.println("enter the elements in an array");
		        int arr[]=new int[n];
		        for(int i=0;i<n;i++) {
			    arr[i]=scan.nextInt();
	             	}
                System.out.println("enter the key element");
		 		int key=scan.nextInt();
			   boolean b= findElement(arr,key);
			   System.out.println(b);
		case 2:System.out.println("enter the no of elements in array");
		       int n1=scan.nextInt();
		       System.out.println("enter the elements in an array");
		       String arr1[]=new String[n1];
		       for(int i=0;i<n1;i++) {
			   arr1[i]=scan.next();
		        }

			   System.out.println("enter the key element");
		       String key1=scan.next();
		    boolean c=findString(arr1,key1);
		    System.out.println(c);
		case 3:System.exit(0);       
		}
	}
	public static boolean findElement(int arr[],int key) {
		int low=0;
		int high=arr.length-1;
		int mid=low+high/2;
		while(high>=low)
		{
			
		if(arr[mid]==key) {
			return true;
		}
		else if(arr[key]<arr[mid]){
			high=mid-1;
			mid=(high+low)/2;
		}
		else if(arr[key]>arr[mid]) {
			low=mid+1;
			mid=(high+low)/2;
		}
	}
		return false;

}
	public static boolean findString(String names[],String key1) {
		int low=0;
		int high=names.length-1;
		int mid=low+high/2;
		while(high>=low)
		{
			
		if(names[mid].equals(key1)) {
			return true;
		}
		else if(names[mid].charAt(0)<key1.charAt(0)){
			high=mid-1;
			mid=(high+low)/2;
		}
		else if(names[mid].charAt(0)>key1.charAt(0)) {
			low=mid+1;
			mid=(high+low)/2;
		}
	}
		return false;

		
	}
}
