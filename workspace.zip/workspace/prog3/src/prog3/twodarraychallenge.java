package prog3;

import java.util.Scanner;

public class twodarraychallenge {
	static Scanner scan=new Scanner(System.in);
	public static void ReplaceDiagonals(int [][] array1, int [][] array2,int n) {
			
				int result1[]=new int[array1.length];
				for(int i=0;i<array1.length;i++) {
					for(int j=0;j<array1.length;j++) {
		                if(i==j) {
		        	 result1[i]=array1[i][j];
		         }
					}
				}
				int []result2=new int[array2.length];
				for(int i=0;i<array2.length;i++) {
					for(int j=0;j<array2.length;j++) {
						if(i==j) {
							result2[i]=array2[i][j];
			}
		}
		
	}
			int[]temp=new int[array1.length];
			for(int i=0;i<temp.length;i++) {
				temp[i]=result1[i];
				result1[i]=result2[i];
				result2[i]=temp[i];
			}
				for(int i=0;i<array1.length;i++) {
					for(int j=0;j<array1.length;j++) {
						if(i==j) {
							array1[i][j]=result1[i];
						}
					}
				}
				for(int i=0;i<array2.length;i++) {
					for(int j=0;j<array2.length;j++) {
						if(i==j) {
							array2[i][j]=result2[i];
						}
					}
				}
				for(int i=0;i<array1.length;i++) {
					for(int j=0;j<array1.length;j++) {
						System.out.println(array1[i][j]);
					}
				}
				System.out.println();
				for(int i=0;i<array2.length;i++) {
					for(int j=0;j<array2.length;j++) {
						System.out.println(array2[i][j]);
					}
				}

}
			public static int[]SumofRows(){
				int len;
				System.out.println("enter the length of matrix");
				len=scan.nextInt();
				int[][] newarray1=new int[len][len];
				int[][] newarray2=new int[len][len];
				System.out.println("enter the first matrix elements");
				for(int i=0;i<len;i++) {
					for(int j=0;j<len;j++) {
						 newarray1[i][j]=scan.nextInt();
					}
				}
				System.out.println("enter the second matrix elements");
				for(int i=0;i<len;i++) {
					for(int j=0;j<len;j++) {
						 newarray2[i][j]=scan.nextInt();
					}
				}
				int[]resmat=new int[len+len];
				
				for(int i=0;i<len;i++) {
					int sum1=0;
					for(int j=0;j<len;j++) {
					 sum1=sum1+newarray1[i][j];
				}
					resmat[i]=sum1;
				}
			
			
			
			

			for(int i=0;i<len;i++) {
				int sum2=0;
				for(int j=0;j<len;j++) {
					sum2=sum2+newarray2[i][j];
				}
				for(int k=newarray2.length;k<=len;k++) {
					resmat[k]=sum2;
				}
		}
			return resmat;
			}
			
			
			public static int[] Replaceby(int[] res){
				for(int i=0;i<res.length;i++) {
					if(res[i]%2==0) {
						res[i]=-1;
					}
				}
				return res;
			}
			public static int Bsearch(int[] result) {
				int[] sortedarray=InsertionSort(result);
				int first=0;
				int last=sortedarray.length;
				int key;
				System.out.println("enter the element to search");
				key=scan.nextInt();
				int mid=(first+last)/2;
				while(first<=last) {
					if(sortedarray[mid]<key) {
						first=mid+1;
					}else if(sortedarray[mid]==key){
						return mid;
					}else
						last=mid-1;
					mid=(last+first)/2;
				}
				return 0;
			}
			public static int[]InsertionSort(int[]res){
				int n=res.length;
				for(int i=0;i<n;i++) {
					int key=res[i];
					int j=i-1;
					while((j>-1) &&(res[j]>key) ) {
						res[j+1]=res[j];
						j--;
					}
					res[j+1]=key;
				}
				return res;
			}
			public static void main(String[] args) {
				System.out.println("enter the value of n where row is equal to column");
				int n;
				n=scan.nextInt();
				int[][] array1=new int[n][n];
				int[][] array2=new int[n][n];
				System.out.println("enter the array1 matrix elements");
				for(int i=0;i<n;i++) {
					for(int j=0;j<n;j++) {
						array1[i][j]=scan.nextInt();
					}
				}
				System.out.println("enter the array2 matrix elements");
				for(int i=0;i<n;i++) {
					for(int j=0;j<n;j++) {
						array2[i][j]=scan.nextInt();
					}
				}
				int[] result=new int[n];
				int[] resarray=new int[n];
				boolean e=true;
				//while(e) {
				while(true) {
					System.out.println("1.replace left diagnol of two array");
					System.out.println("2.add the sum of rows of two matrix and add in 1d array");
					System.out.println("3.replace all even numbers by -1");
					System.out.println("4.binary search by sorting using insertion sort");
					System.out.println("5.exit");
					int choice;
					System.out.println();
					choice=scan.nextInt();
					switch(choice) {
					case 1:
						ReplaceDiagonals(array1,array2,n);
						break;
					case 2:
						result=SumofRows();
						System.out.println("Resultant array");
						for(int i=0;i<result.length;i++) {
							System.out.println(result[i]);
						}
						break;
					case 3:
						resarray=Replaceby(result);
						System.out.println("Replaced array");
						for(int i=0;i<resarray.length;i++) {
							System.out.println(resarray[i]);
						}
						break;
					case 4:
						int element=Bsearch(resarray);
						if(element>0) {
							System.out.println("element found");
						}
						else {
							System.out.println("element not found");
						}
						break;
					case 5: //e=false;
						System.exit(0);
						break;
					default:
						System.out.println("invalid option");
					}
				}
			}
}
