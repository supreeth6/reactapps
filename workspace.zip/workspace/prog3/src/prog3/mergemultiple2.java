package prog3;

import java.util.Scanner;

public class mergemultiple2 {
	static Scanner scan=new Scanner(System.in);
	static int size=0;
	public static void main(String args[]) {
		int b[]=null;
		boolean d=true;
		char c[]=null;
	//	char c[]=null;
		while(d) {
			System.out.println("press 1 to enter the number:");
			System.out.println("press 2 from int to char ");
			System.out.println("press 3 to print the vowels");
			System.out.println("press 4 to addition");
			System.out.println("press 5 to exit");
			System.out.println();
			System.out.println("enter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:b=enterNumber();
			       for(int i=0;i<size;i++)
			       {
			    	   if(b[i]>=65 && b[i]<83) {
			    	   System.out.println(b[i]+" ");
			       }
			       }
			       break;
			case 2:c=intToChar(b);
					 for(int i=0;i<size;i++) {
						 System.out.println(c[i]);
					 }
					 break;
			case 3:char c1[]=vowels(c);
			for(int i=0;i<c1.length;i++)
				System.out.println(c1[i]);

				//System.out.println(addition(b));
			      // break;
			case 4://char c1[]=vowels(c);
				//for(int i=0;i<c1.length;i++)
					//System.out.println(c1[i]);
			//	char c2[]=vowels(c);
				char c111[]=vowels(c);
				System.out.println(addition(c111));
			      // break;

				break;
			case 5:System.out.println("done");
			       d=false;
			       break;
			      // System.exit(0);
			default:System.out.println("enter the correct choice");       
				
			}
		}
	}
	public static int[] enterNumber() {
		System.out.println("size of array");
		size=scan.nextInt();
		int a[]=new int[size];
		System.out.println("enter the elements");
		for(int i=0;i<size;i++) {
			a[i]=scan.nextInt();
		}
		return a;
	}
	public static char[] intToChar(int b[]) {
		char a1[]=new char[size];
		for(int i=0;i<size;i++) {
			a1[i]=(char)b[i];//Explicit type casting
		}
		return a1;
	}
	public static int addition(char[] cs) {
		int sum=0;
		for(int i=0;i<size;i++) {
			sum=sum+cs[i]; 
		}
		return sum;
	}
	public static char[]vowels(char c[]){
		char g[]=new char[c.length];
		for(int i=0;i<c.length;i++) {
			if(c[i]=='A'||c[i]=='E'||c[i]=='I'||c[i]=='O'||c[i]=='U') {
				g[i]=c[i];
			}
		}
		return g;
	}

}
