package prog3;

import java.util.Scanner;

public class linearsearch {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the no of elements in array");
		int a=scan.nextInt();
		System.out.println("enter the elements in array");
		int arr[]= new int[a];
		for(int i=0;i<a;i++) {
			arr[i]=scan.nextInt();
		}
		
		searchElement(arr);
			
		
		
	}
	public static void searchElement(int arr[]) {
		int a=arr.length;
		Scanner scan=new Scanner(System.in);
		int flag=0;
		System.out.println("enter the key element");
		int key=scan.nextInt();
		for(int i=0;i<a;i++) {
			if(key==arr[i]) {
				flag=1;
			System.out.println(" key found");	
				
			}
		}
		
		if(flag==0)
		{
			System.out.println(" not found");
		}
			
			
		
		
	}

}
