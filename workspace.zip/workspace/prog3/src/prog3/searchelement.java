package prog3;

import java.util.Scanner;

public class searchelement {
	public static void main(String args[]) {
	Scanner scan=new Scanner(System.in);
	System.out.println("enter the no of elements in array");
	int n=scan.nextInt();
	System.out.println("enter the elements in an array");
	int arr[]=new int[n];
	for(int i=0;i<n;i++) {
		arr[i]=scan.nextInt();
	}
	System.out.println("enter the element to be searched");
	int t=scan.nextInt();
	int res=seel(arr,t);
    System.out.println(+res);
}
	public static int seel(int arr[],int t) {
		if(arr==null) {
			return -1;
		}
		int len=arr.length;
		int i=0;
		while(i<len) {
			if(arr[i]==t) {
				return i;
			}
			else {
				i=i+1;
			}
		}
		return -1;
	}
}
