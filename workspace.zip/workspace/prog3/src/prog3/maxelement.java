package prog3;

import java.util.Scanner;

public class maxelement {
	static Scanner scan=new Scanner(System.in);

public static void main(String args[]) {
	//Scanner scan=new Scanner(System.in);
	System.out.println("enter the no of elements in an array");
	int n=scan.nextInt();
	System.out.println("enter the elements in an array");
	int arr[]=new int[n];
	for(int i=0;i<n;i++) {
		arr[i]=scan.nextInt();
	}
	maxindex(arr);
}
public static void maxindex(int []arr) {
System.out.println("enter the first index");
int i=scan.nextInt();
System.out.println("enter the second index");
int j=scan.nextInt();
if(arr[i]>arr[j]) {
	System.out.println("the first index is greater");
}
else {
	System.out.println("the second index is greater");
}

}
}
