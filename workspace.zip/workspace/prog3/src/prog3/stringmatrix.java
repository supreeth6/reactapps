package prog3;

import java.util.Scanner;

public class stringmatrix {
  //  int l=a.length();

	public static void main(String args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the value of n ");
		int n;
		n=scanner.nextInt();
		String[][] array1=new String[n][n];
		
		System.out.println("enter the array1 matrix elements");
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				array1[i][j]=scanner.next();
				System.out.println(array1);
			}
		}

		int num1=array1.length;
		for(int j=1;j<n;j++) {
			String[] pos=array1[j];
			int i=j-1;
			while((i>-1)&& (array1[i].length>0)) {
				array1[i+1]=array1[i];
				i--;
			}
			array1[i+1]=pos;
		}
		for(int i=0;i<n;i++) {
		System.out.println(array1[i]);
	}
		int flag=0;
		System.out.println("enter the key element");
		String key=scanner.next();
		for(int i=0;i<n;i++) {
			if(key.equals(array1[i])) {
				flag=1;
			System.out.println(" key found");	
				
			}
		}
		
		if(flag==0)
		{
			System.out.println(" not found");
		}
		

		
	}

}

