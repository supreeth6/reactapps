package jancoding;

import java.util.Scanner;

public class studscore {
	public static void main(String args[]) {
		int size=10;
		int arr[]=new int[size];
		int marks[]=new int[size];
		int ch;
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the choice");
		ch=scan.nextInt();
		switch(ch) {
		case 1:
		       System.out.println("enter the marks");
		       for(int i=0;i<size;i++) {
		        marks[i]=scan.nextInt();
		        }
		case 2:int largest=marks[size],smallest=marks[0],temp=0;
		       while(smallest<largest) {
			      for(int i=0;i<marks.length;i++) {
			          smallest=largest;
			          largest=temp;
			          temp=smallest;
				
				System.out.println(smallest);
			}
			
		}
	
	}

}
}
