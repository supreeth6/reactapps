package jancoding;

import java.util.Scanner;

public class leading {
	int num;
	public static void main(String args[]) {
		int a,num;
		Scanner scan=new Scanner(System.in);
		a=scan.nextInt();
		int result=firstnum(a);
		System.out.println(result);
	}
	public static int firstnum(int a) {
		int num=0;
		
		while(num>=10) {
			
		    num=a/10;
			return num;
			
			
		}
		if(a<=0) {
			System.out.println("print invalid");
			return(1);
		}
		return(1);
		
	}

}
