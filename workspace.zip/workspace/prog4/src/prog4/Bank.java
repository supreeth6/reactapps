package prog4;

public class Bank {
	int customer_id;
	String customer_name;
	String customer_add;
	String Account_type;
	double curr_Balance;
	public Bank(int customer_id, String customer_name, String customer_add, String account_type, double curr_Balance) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.customer_add = customer_add;
		Account_type = account_type;
		this.curr_Balance = curr_Balance;
	}
	public Bank() {
		super();
		
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(int i) {
		this.customer_name = i;
	}
	public String getCustomer_add() {
		return customer_add;
	}
	public void setCustomer_add(String i) {
		this.customer_add = i;
	}
	public String getAccount_type() {
		return Account_type;
	}
	public void setAccount_type(String account_type) {
		Account_type = account_type;
	}
	public double getCurr_Balance() {
		return curr_Balance;
	}
	public void setCurr_Balance(double curr_Balance) {
		this.curr_Balance = curr_Balance;
	}
	

	

}
