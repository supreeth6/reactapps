package prog4;

public class employee {
	int empid;
	String empname;
	String empdesig;
	String empdept;
public employee(int empid, String empname,String empdesig,String empdept) {
	this.empid=empid;
	this.empname=empname;
	this.empdesig=empdesig;
	this.empdept=empdept;
}
public employee() {
	
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int id) {

	empid = id;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	if(empname.equals(null)) {
	System.out.println("enter the valid input");
	}
	else {
	this.empname = empname;
	}
}
public String getEmpdesig() {
	
		return empdesig;
	
	
}
public void setEmpdesig(String empdesig) {
	if(empdesig.equals("developer") || empdesig.equals("tester") || empdesig.equals("lead") ||empdesig.equals("manager") ) {
	this.empdesig = empdesig;
}
	else {
		System.out.println("Invalid designation");
	}
	}
public String getEmpdept() {
	return empdept;
}
public void setEmpdept(String empdept) {
	if(empdept.equals("TTH")|| empdept.equals("RCM") || empdept.equals("DIGITAL") || empdept.equals("DEVOPS"))
	this.empdept = empdept;
	else
		System.out.println("invalid dept");
}

}

