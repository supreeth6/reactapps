package prog4;

import java.util.Scanner;

public class employeelaunch {
	static Scanner scanner=new Scanner(System.in);
	public static void main(String args[]) {
		 employee emp1=new  employee();
	//	 emp1.setEmpid(12);
	//	  System.out.println(emp1.empid);
		 int empid;
		 String empname;
		 String empdesig;
		 String empdept;
		 System.out.println("enter the employee id");
		 empid=scanner.nextInt();
		 System.out.println("enter the employee name");
		 empname=scanner.next();
		 System.out.println("enter the employee designation");
		 empdesig=scanner.next();
		 System.out.println("enter the employee department");
		 empdept=scanner.next();
	}

}
