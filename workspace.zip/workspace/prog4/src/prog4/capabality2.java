package prog4;

import java.util.Scanner;

public class capabality2 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in) ;
		int i,j;
		System.out.println("enter the string");
		String s=scan.nextLine();
		int b[]=new int [25];
		int o[]=new int[25];
		int k=0,x=0,y=0;
		for( i=0;i<s.length();i++) {
			//for(int j=0;j<s[i].length();j++) {
				if(s.charAt(i)>='0'&& s.charAt(i)<='9') {
					 b[k]=Character.getNumericValue(s.charAt(i));
					k++;
				
			}
		}
		System.out.println(b[k]);
		int r;
		r=k;
		for( i=0;i<r;i++) {
			if(b[i]%2==0) {
				o[y]=b[i];
				y++;
			}
		}
			
		
	}

}
