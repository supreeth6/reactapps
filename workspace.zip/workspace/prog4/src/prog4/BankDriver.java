package prog4;

import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class BankDriver {
	private static final int Count = 0;

	public static void main(String args[]) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the input");
	int input=scanner.nextInt();
	Bank obj=new Bank();
	switch(input) {
	case 1:if(Count<len+3) {
		System.out.println("enter the id\tname\taddress");
		obj.setCustomer_id(scanner.nextInt());
		obj.setCustomer_name(scanner.nextInt());
		obj.setCustomer_add(scanner.nextInt());
		customer_data[count]=obj;
		count++;
	}
	else {
		System.out.println("you have already entered"+len+"Customers data");
	}
	break;
		
		
	}
	case 2:if(count<len+3) {
		System.out.println("enter the id");
		obj.setCustomer_id(scanner.nextInt());
		obj.setCustomer_name(scanner.nextInt());
		customer_data[count]=obj;
		count++;
	}
	else {
		System.out.println("");
	}
	

}
}
