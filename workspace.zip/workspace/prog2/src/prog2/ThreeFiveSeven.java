package prog2;
import java.util.Scanner;
public class ThreeFiveSeven {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int rows=scan.nextInt();
		System.out.println("enter the number of columns");
		int columns=scan.nextInt();
		int arr[][]=new int[rows][columns];
		System.out.println("enter the elements");
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				arr[i][j]=scan.nextInt();
			}
		}
		boolean bool=true;
		do
		{
			System.out.println("Press 1 for display matrix");
			System.out.println("Press 2 for display resultant matrix");
			System.out.println("Press 3 for exit");
		    System.out.println("Enter your choice");
		    int choice=scan.nextInt();
		    switch(choice)
		    {
		    case 1://display(arr);
		    	for(int i=0;i<arr.length;i++) {
					for(int j=0;j<arr.length;j++) {
						System.out.print(arr[i][j]+" ");
					}
					System.out.println();
				}
		    		break;
		    case 2:int arr1[][]=resultantMatrix(arr);
		    		display(arr1);
		    		break;
		    case 3:bool=false;
		    		System.out.println("end");
		    		break;
		    default:System.out.println("enter the correct choice");
		    }
		}while(bool);
	}
	public static int[][] resultantMatrix(int[][]arr){
		for(int i=0;i<arr.length-1;i++) {
			for(int j=0;j<arr.length-1;j++) {
				if(arr[i][j]%3==0 || arr[i][j]%5==0 || arr[i][j]%7==0) {
					arr[i][j]=arr[i][j]+i+j;
				}
			}
		}
		return arr;
	}
	public static void display(int[][] arr) {
		for(int i=0;i<arr.length-1;i++) {
			for(int j=0;j<arr.length-1;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}

}
