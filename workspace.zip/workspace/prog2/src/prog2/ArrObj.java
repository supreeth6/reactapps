package prog2;
import java.util.*;
public class ArrObj {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {

		System.out.println("enter the size");
		int size=sc.nextInt();
		
		Entity[] arr= new Entity[size];
	
		for(int i=0;i<size;i++)
		{
			System.out.println("enter  id");
			int id =sc.nextInt();
			sc.nextLine();
			System.out.println("enter the name");
			String name = sc.next();
			
			arr[i]=new Entity(id,name);
		}
		

		for(int i=0;i<size;i++)
		{
			System.out.println("=====================================");
			System.out.println(arr[i].getId()+" "+arr[i].getName());
		}
	
		arr[0].setName("xyz");
		System.out.println(arr[0].getId()+" "+arr[0].getName());
		
	}

	
}
