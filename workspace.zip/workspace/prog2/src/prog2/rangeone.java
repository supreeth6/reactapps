package prog2;

import java.util.Scanner;

public class rangeone {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int b=scan.nextInt();
		int c=scan.nextInt();
		int result;
		result=verify(a,b,c);
		System.out.println(result);
	}



	public static int verify(int a,int b, int c) {
		int sum=0;
		if(a>=0 && a<=50) {
			if(a%2==0) {
				sum=sum+a;
		//	System.out.println(+sum);
			}
		}
       // int sum2=0;
		if(b>=0 && b<=50) {
			if(b%2==0) {
				sum=sum+b;
	 //	System.out.println(+sum);
		}
		}
		//int sum3=0;
		if(c>=0 && c<=50) {
			if(c%2==0) {
				sum=sum+c;
		//	System.out.println(sum);
			}
		}
			//if(a%2==0 && b%2==0) {
			//int 	result1=a+b;
			//System.out.println(result1);
			//}
			 //if(b%2 ==0 && c%2==0) {
				//int result2=b+c;
				//System.out.println(result2);
		//	}
			
			//if(c%2==0 && a%2==0) {
				//int result3=c+a;
				//System.out.println(result3);
			
			
			
				
					
			
			
			

		
		
		
		
		//System.out.println(sum);
		return sum;
	}
 
}

