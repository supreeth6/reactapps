package prog2;

import java.util.Scanner;

public class max {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int b=scan.nextInt();
		int c=scan.nextInt();
		int s=GetMax(a,b,c);
		System.out.println(s);
		
	}
	public static int GetMax(int a,int b,int c) {
		if(a>b && a>c) {
			return a;
		}
		else if(b>c) {
			return b;
		}
		else {
			return c;
		}
		
	}

}
