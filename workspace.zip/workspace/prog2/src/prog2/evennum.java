package prog2;

public class evennum {
	public static void main(String args[]) {
		int i=0;
	    int n=100;
	    for(i=0;i<n;i++) {
	    	if(i%2==0) {
	    		System.out.println(i);
	    	}
	    }
	}

}
