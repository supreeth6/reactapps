package prog2;
import java.util.Scanner;

public class validation 
{
	public static void main(String args[])
	{
		String  usn;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the USN");
		usn =scan.nextLine();
		if(usn.length()==10) 
		{
			if(usn.charAt(0)=='1' || usn.charAt(0)=='2') 
			{
				if((usn.charAt(1)>='A' || usn.charAt(1)<='z') && (usn.charAt(2)>='A' || usn.charAt(2)<='Z' ))
				{
					if((usn.charAt(3)>=0 || usn.charAt(3)<=9 )&& (usn.charAt(4)>=0 || usn.charAt(4)<=9)) 
					{
						if((usn.charAt(5)=='C'|| usn.charAt(5)=='I')|| (usn.charAt(5)=='E'|| usn.charAt(5)=='M') && (usn.charAt(6)=='S' || usn.charAt(6)=='S'||usn.charAt(6)=='C' ||usn.charAt(6)=='E'))
						{
								if((usn.charAt(7)>=0 || usn.charAt(7)<=9)&&(usn.charAt(8)>=0 || usn.charAt(8)<=9))
								{
										System.out.println("success");
								}else
									System.out.println("failure");
							}else
								System.out.println("failure");
						}else
							System.out.println("failure");
					}else
						System.out.println("failure");
						
				}else
					
			System.out.println("failure");
			}else
		System.out.println("failure");
				
		}
}			
	
		

