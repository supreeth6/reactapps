package prog2;

import java.util.Scanner;

public class magicarray {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the odd matrix size");
		int n=scan.nextInt();
		generate(n);
	//	System.out.println(result);
	}
	static void generate(int n)
	{
		int x,a[][]=new int[n][n],r=0,c=n/2;
		for(x=1;x<n*n;x++)
		{
			a[r][c]=x;
			if(x%n==0)
				r++;
			else
			{
				r--;c--;
				if(r<0)
					r+=n;
				if(c<0)
					c+=n;
			}
		}
		for(r=0;r<n;r++) {
			for(c=0;c<n;c++) {
				System.out.println(a[r][c]);
			}
			System.out.println();
		}
		//return a[r][c];
	}

}
