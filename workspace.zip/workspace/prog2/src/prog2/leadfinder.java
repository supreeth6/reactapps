package prog2;

import java.util.Scanner;

public class leadfinder {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the size of array elements");
		int n=scan.nextInt();
		int arr[]=new int[n];
		System.out.println("enter the array elements");
		for(int i=0;i<n;i++) {
			 arr[i]=scan.nextInt();
		}
		int result=LeadFinder(arr);
		System.out.println(result);
	}
	public static int LeadFinder(int[]arr)
	{
		int large=arr[0];
		for(int i=0;i<arr.length;i++) {
			if(large<arr[i]) {
				large=arr[i];
			}
		}
		return large;
		
	}

}



