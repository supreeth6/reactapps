package prog2;

public class addmatrix {
	public static void main(String args[]) {
		int a[][]={{1,2,3},{4,5,6}}; 
		int b[][]= {{4,5,6},{7,8,9}};
		int result[][]=new int[2][3];
		 functcall(a,b,result);
	}
	public static void functcall(int[][] a,int[][] b, int[][] result) {
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++) 
			{
				result[i][j]=a[i][j]+b[i][j];
				//System.out.print(result[i][j]);
			}
		}	
			for(int k=0;k<2;k++)
			{
				for(int l=0;l<3;l++) 
				{
				System.out.print(" "+result[k][l]);
			}
				System.out.println();
		}
		
	}

}

