package prog2;

import java.util.Scanner;

public class OddorEven {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int rows=scan.nextInt();
		System.out.println("enter the number of columns");
		int columns=scan.nextInt();
		int arr[][]=new int[rows][columns];
		System.out.println("enter the elements");
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				arr[i][j]=scan.nextInt();
			}
		}
		boolean bool=true;
		do
		{
			System.out.println("Press 1 for display matrix");
			System.out.println("Press 2 for display resultant matrix");
			System.out.println("Press 3 for exit");
		    System.out.println("Enter your choice");
		    int choice=scan.nextInt();
		    switch(choice)
		    {
		    case 1://display(arr);
		    	int arr1[][]=interchange(arr);
		    	for(int i=0;i<arr1.length;i++) {
		    		for(int j=0;j<arr1.length;j++) {
		    			System.out.println(arr1);
		    		}
		    	}
		    		break;
		    case 2:int arr1[][]=resultantMatrix(arr);
		    		display(arr1);
		    		break;
		    case 3:bool=false;
		    		System.out.println("end");
		    		break;
		    default:System.out.println("enter the correct choice");
		    }
		}while(bool);
	}
	}

}
