package prog2;

import java.util.Scanner;

public class rowmagic {
	static boolean rowmagic(int a[][],int b,int c) {
		int d=0,k=0,flag=0;
		for(int i=0;i<b;i++) {
			for(int j=0;j<c;j++) {
				if(i==0) {
					d+=a[i][j];
				}
				else {
					k+=a[i][j];
				}
			}
			//System.out.println(k);
			if(i>0&&d!=k) {
				flag=1;
			}
			k=0;
		}
		if(flag==0) {
			return true;
		}
		else
		{
			return false;
		}
	}
	public static void main(String ar[])
	{
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int b=scan.nextInt();
		int c[][]=new int[a][b];
		for(int i=0;i<a;i++) {
			for(int j=0;j<b;j++) {
				c[i][j]=scan.nextInt();
				
			}
		}
		boolean r=rowmagic(c,a,b);
		if(r) {
			System.out.println("Array is an row magic"); 
		}
		else
		{
			System.out.println("Array is not a row magic"); 
			scan.close();
		}
		
	}
	
	}
	