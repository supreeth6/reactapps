package prog2;

import java.util.Scanner;

public class reverse {
	public static void main(String args[]) {
	    Scanner scan=new Scanner(System.in);
		 int num=scan.nextInt();
		int result=reversenumber(num);
		System.out.println(result);
		
	}
	public static int reversenumber(int num) {
		int rev=0,rem=0;
		//num=num/10;
		while(num>0) {
		rem = num%10;
		rev = rev*10+rem;
		num=num/10;
		
		
		
		
	}
		return(rev);

}
}
