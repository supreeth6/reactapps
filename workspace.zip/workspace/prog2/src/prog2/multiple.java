package prog2;

import java.util.Scanner;

public class multiple {
	public static void main(String args[]){
	Scanner scan=new Scanner(System.in);
	System.out.println("enter array size");
	int size=scan.nextInt();
	double[]a1=new double[size];
	System.out.println("enter elements");
	for(int i=0;i<a1.length;i++) {
		a1[i]=scan.nextDouble();
	}
	System.out.println("enter the array size");
	int size1=scan.nextInt();
	double[]a2=new double[size];
	System.out.println("enter elements");
	for(int i=0;i<a2.length;i++) {
		a2[i]=scan.nextDouble();
	}
	int maxL,minL,flag=0;
	if(a1.length>a2.length) {
		maxL=a1.length;
		minL=a2.length;
		flag=1;
	}else {
		maxL=a2.length;
		minL=a1.length;
	}
	int[]a3=new int[maxL];
	for(int i=0;i<minL;i++) {
		a3[i]=(int)(a1[i]+a2[i]);
	}
	for(int i=minL;i<maxL;i++)
	{
		if(flag==1) {
			a3[i]=(int)(a1[i]+a2[i]);
		}
		else
		{
			a3[i]=(int)a2[i];
		}
	}
	for(int i=0;i<a3.length;i++) {
		System.out.println(a3[i]);
	}
}
	
		
	}



