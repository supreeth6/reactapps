package prog2;

public class sum {
	public static void main(String args[]) {
		//int arr[]=new int[5];
		int arr[]= {1,2,3,4,5};
		int result=0;
		for(int i=0;i<5;i++) {
		    result=result+arr[i];
			
			
		}
		System.out.println(result);
	}

}
