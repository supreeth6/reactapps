package prog2;

import java.util.Scanner;

public class exchange {
	public static void main(String args[])
	{ 
	 Scanner scan=new Scanner(System.in) ;
	 
	 String[] first=new String[2];
	 String[] last=new String[2];
	 
	 System.out.println("enter the first");
	 for(int i=0;i<2;i++)
	 {
		 first[i]=scan.next();
	 }
	 System.out.println("enter the last");
	 for(int i=0;i<2;i++) {
		 last[i]=scan.next();
	 }
	 rev(first,last);
		
		
	}
	public static void rev(String[] first,String[] last)
	{
		String l1=first[2-1];
		String l2=last[2-1];
		first[2-1]=l2;
		last[2-1]=l1;
		
		
		System.out.println("After swapping first name:");
		for(int i=0;i<2;i++) 
		{
			System.out.print(first[i]);
		}
		System.out.println();
		System.out.println("After swapping last name:");
		for(int i=0;i<2;i++) {
			System.out.print(last[i]);
		}
	}
}
	


