package prog2;

import java.util.Scanner;

public class uniqueelements {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int n,m;
		System.out.println("enter the number of elements in first array");
		n=scan.nextInt();
		int[] a1=new int[n];
		System.out.println("Enter first array elements");
		for(int i=0;i<n;i++)
		{
			a1[i]=scan.nextInt();
		}
		System.out.println("enter the number of elements in second array");
		m=scan.nextInt();
		int[] a2=new int[m];
		System.out.println("enter the second array elements");
		for(int j=0;j<m;j++)
		{
			a2[j]=scan.nextInt();
		}
		FindUnique(a1,a2);
		
		
		
	}
	public static void FindUnique(int[] a1,int[] a2) {
		boolean temp=false;
		for(int i=0;i<a1.length;i++) {
			temp=false;
			for(int j=0;j<a2.length;j++) {
				if(a1[i]==a2[j]) {
					temp=true;
				}
			}
			if(!temp)
			{
				System.out.println(a1[i]);
			}
		}
		for(int i=0;i<a2.length;i++) {
			temp=false;
			for(int j=0;j<a1.length;j++) {
				if(a2[i]==a1[j]) {
					temp=true;
				}
			}
			if(!temp)
			{
				System.out.println(a2[i]);
			}
		}
	}

}
