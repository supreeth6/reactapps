package prog2;

public class initials {
	public static void main(String args[]) {
		String name="pupreeth l jeeryada";
		String s=name;
		String x=" ";
		for(int i=0;i<s.length();i++) {
			if(i==0||(s.charAt(i-1)==' '&& s.charAt(i)!=' ')){
			//	String y;
			//	y=charAt(0);
				x=x+s.charAt(i);
				
			}
		//	System.out.println(y);
		//	System.out.println(x);
			
		}
		System.out.println(x);
		
	}

}
