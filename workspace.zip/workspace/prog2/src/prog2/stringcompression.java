package prog2;

import java.util.Scanner;

public class stringcompression {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		String s;
		System.out.println("enter the string");
		s=scan.nextLine();
		String d=compress(s);
		System.out.println(d);
	}
	public static String compress(String s) {
		String out=" ";
		int sum=1;
		for(int i=0;i<s.length()-1;i++) {
			if(s.charAt(i)==s.charAt(i+1)) {
				sum++;
			}
			else
			{
				out=out+s.charAt(i)+sum;
				sum=1;
			}
		}
		out=out+s.charAt(s.length()-1)+sum;
	//	return out.length()<s.length()?out:s;
		return out;
	}

}
