package prog2;

import java.util.Scanner;

public class studentmarks
{
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int[] array=new int[10];
		System.out.println("enter the 10 students marks");
		for(int i=0;i<10;i++)
		{
			array[i]=scan.nextInt();
			if(array[i]<0||array[i]>25)
				break;
		}
		countmarks(array);
	}
	public static void countmarks(int[] array)
	{
		int count=1;
		for(int i=0;i<array.length;i++)
		{
			for(int j=i+1;j<array.length;j++)
			{
				if(array[i]==array[j])
				{
					count++;
				}
			}
			System.out.println("the marks"+array[i]+"scored by"+count);
			count=1;
		}
	}

}
