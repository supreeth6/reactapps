package prog2;

import java.util.Scanner;

public class Shop {
	public static void main(String args[]) {
		int id;
		String name;
		int revenue;
		int gstNumber;
		
		System.out.println("1.select one to add shop");
		System.out.println("2.Sort the shop based on gst number");
		System.out.println("3.Display the shop details having third highest revenue ");
		System.out.println("4.Search for a particular shop based on id");
		System.out.println("enter the choice");
		int ch=Scanner.nextInt();
	}

}
