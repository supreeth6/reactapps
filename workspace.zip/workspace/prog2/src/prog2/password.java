package prog2;

//import java.util.Scanner;

public class password {
	public static void main(String args[]) {
		//Scanner scan=new Scanner(System.in);
		String first="supreeth";
		String middle="s";
		String last="seeryada";
		int age=21;
		String password=" ";
		password=password+first.charAt(0);
		password=password+middle.charAt(0);
		password=password+last.charAt(0);
		password=password+age;
		System.out.println("password is"+password);
		}

}
