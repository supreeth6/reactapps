package prog2;

import java.util.Scanner;

public class Npng {
	static Scanner scan=new Scanner(System.in);
	public static String[] stringSwap(String str) {
		int space=0;
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)==' ') {
				space++;
			}
		}
		String[] words=new String[++space];
		int index=0;
		String temp=" ";
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)==' ') {
				words[index++]=temp;
				temp=" ";
			}else {
				temp+=str.charAt(i);
			}
		}
		words[index++]=temp;
		return words;
		
	}
	public static String swap(String str) {
		char[]ch=str.toCharArray();
		for(int i=0;i<ch.length;i++) {
			int k=0;
			while(i<ch.length && ch[i]!=' ')
				i++;
			char temp=ch[k];
			ch[k]=ch[i-1];
			ch[i-1]=temp;
		}
		return new String(ch);
	}
	public static void main(String args[]) {
		System.out.println("Enter the string");
		String string=scan.nextLine();
		String []result=stringSwap(string);
		String temp=result[0];
		result[0]=result[result.length-1];
		result[result.length-1]=temp;
		for(int i=0;i<result.length;i++) {
			System.out.println(result[i]+" ");
		}
		System.out.println();
		String first=result[0];
		String last=result[result.length-1];
		System.out.println(swap(first));
		for(int i=0;i<result.length;i++) {
			if( i==0 || i==result.length-1) {
				continue;
			}else {
				System.out.print(" "+result[i]+" ");
			}
		}
		System.out.print(swap(last));
	}
}
