const initialState = {
	questions: [],

	quizs: [],
};
const Reducer = (state = initialState, action) => {
	console.log("to update", state, action);

	switch (action.type) {
		case "ADD_QUESTION":
			const question = action.question;
			return {
				...state,
				questions: [...state.questions, question],
			};
		case "TAKE_QUIZ":
			const quiz = action.quiz;
			return {
				...state,
				quizs: [...state.quizs, quiz],
			};

		default:
			return state;
	}
};
export default Reducer;
