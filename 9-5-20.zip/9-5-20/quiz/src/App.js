import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import Addquestion from "./Pages/Addquestion";
import Addoptions from "./Pages/Addoptions";
import Takequiz from "./Pages/Takequiz";
import Viewscore from "./Pages/Viewscore";

export default class App extends Component {
	render() {
		return (
			<div>
				<AppBar position="static">
					<Toolbar>
						<Typography variant="h6"> Quiz application</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position="static" color="default">
					<Router>
						<ul>
							<li>
								<Link to="/Addquestion">Addquestion</Link>
							</li>
							{/* <li>
								<Link to="/Addoptions">Addoptions</Link>
							</li> */}
							<li>
								<Link to="/Takequiz">Takequiz</Link>
							</li>
							<li>
								<Link to="/Viewscore">Viewscore</Link>
							</li>
						</ul>
						<Switch>
							{/* <Route exact path="/" component={Login}></Route> */}
							<Route exact path="/Addquestion" component={Addquestion}></Route>
							{/* <Route exact path="/Addoptions" component={Addoptions}></Route> */}
							<Route exact path="/Takequiz" component={Takequiz}></Route>
							<Route exact path="/Viewscore" component={Viewscore}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
