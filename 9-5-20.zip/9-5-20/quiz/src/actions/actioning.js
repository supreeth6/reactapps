const adding = (actionType, question) => {
	console.log(question);
	return {
		type: actionType,
		question: question,
	};
};
// export const addingoptions = (actionType, question) => {
// 	console.log(question);
// 	return {
// 		type: actionType,
// 		question: question,
// 	};
// };

export const takequiz = (actionType, quiz) => {
	console.log(quiz);
	return {
		type: actionType,
		quiz: quiz,
	};
};
export default adding;
