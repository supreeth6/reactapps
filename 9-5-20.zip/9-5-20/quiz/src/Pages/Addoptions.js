// import React, { Component } from "react";
// import { connect } from "react-redux";

// import TextField from "@material-ui/core/TextField";
// import Button from "@material-ui/core/Button";
// import addingoptions from "../actions/actioning";
// // import addingseats from "../actions/actioning";

// class Addquestion extends Component {
// 	constructor(props) {
// 		super(props);
// 		this.state = {
// 			detailone: {
// 				option1: "",
// 				option2: "",
// 				option3: "",
// 			},
// 		};
// 	}
// 	handleChange = (e) => {
// 		let name = e.target.name;
// 		let value = e.target.value;
// 		this.setState({
// 			detailone: {
// 				...this.state.detailone,
// 				[name]: value,
// 			},
// 		});
// 	};

// 	addOptions = (e) => {
// 		e.preventDefault();
// 		console.log(this.props);
// 		let { dispatch } = this.props;
// 		dispatch(addingoptions("ADD_OPTIONS", this.state.detailone));
// 	};

// 	render() {
// 		return (
// 			<form>
// 				<div>
// 					<div>
// 						<label>
// 							option1
// 							<TextField
// 								id="outlined-basic"
// 								type="text"
// 								name="option1"
// 								variant="outlined"
// 								onChange={this.handleChange}
// 							/>
// 						</label>
// 					</div>
// 					<div>
// 						<label>
// 							option2
// 							<TextField
// 								id="outlined-basic"
// 								type="text"
// 								name="option2"
// 								variant="outlined"
// 								onChange={this.handleChange}
// 							/>
// 						</label>
// 					</div>
// 					<div>
// 						<label>
// 							option3
// 							<TextField
// 								id="outlined-basic"
// 								type="text"
// 								name="option3"
// 								variant="outlined"
// 								onChange={this.handleChange}
// 							/>
// 						</label>
// 					</div>
// 					<div>
// 						<label>
// 							option4
// 							<TextField
// 								id="outlined-basic"
// 								type="text"
// 								name="option4"
// 								variant="outlined"
// 								onChange={this.handleChange}
// 							/>
// 						</label>
// 					</div>
// 					<Button
// 						type="button"
// 						variant="contained"
// 						onClick={this.addOptions}
// 						color="primary"
// 					>
// 						Add option
// 					</Button>
// 				</div>
// 			</form>
// 		);
// 	}
// }
// const mapStateToProps = (state) => {
// 	console.log("sdfghj", state);
// 	return {
// 		optionadd: state,
// 	};
// };
// export default connect(mapStateToProps)(Addquestion);
