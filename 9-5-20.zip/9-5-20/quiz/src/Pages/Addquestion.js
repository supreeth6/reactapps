import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import adding from "../actions/actioning";
// import addingseats from "../actions/actioning";

class Addquestion extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detail: {
				question: "",
				option1: "",
				option2: "",
				option3: "",
				option4: "",
				answer: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detail: {
				...this.state.detail,
				[name]: value,
			},
		});
	};

	addQuestion = (e) => {
		e.preventDefault();
		console.log(this.props);
		let { dispatch } = this.props;
		dispatch(adding("ADD_QUESTION", this.state.detail));
		this.props.history.push("/Addquestion");
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Add question
							<TextField
								id="outlined-basic"
								type="text"
								name="question"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							option1
							<TextField
								id="outlined-basic"
								type="text"
								name="option1"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							option2
							<TextField
								id="outlined-basic"
								type="text"
								name="option2"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							option3
							<TextField
								id="outlined-basic"
								type="text"
								name="option3"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							option4
							<TextField
								id="outlined-basic"
								type="text"
								name="option4"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Answer
							<TextField
								id="outlined-basic"
								type="text"
								name="answer"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addQuestion}
						color="primary"
					>
						Add Question
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		questionadd: state,
	};
};
export default connect(mapStateToProps)(Addquestion);
