import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      detail:{
      allcomments:[]}
     
     };
  }
  render() {
    return (
      <div className="App">
        <button onClick={this.resetCommentFeed}>Reset comment feed</button>
        <button onClick={this.getAllComments}>Get all comments</button>
        {console.log(this.state)}
      </div>
    );
  }

  private resetCommentFeed = () => {
    fetch('/api/reset-comments', {
      method: 'post'
    });
  }
  private  getAllComments = () => {
    console.log("abcd");
    this.setState({...this.state});
    fetch(`/api/comments/`, {
      method: 'get'
    })
    // .then(response=>response.json())
    // .then(response=>console.log(response))
    .then(response=>{this.setState({
      allcomments:response.json()
    })})
    .catch(err=>{console.log(err)})
  }
  
}

export default App;
