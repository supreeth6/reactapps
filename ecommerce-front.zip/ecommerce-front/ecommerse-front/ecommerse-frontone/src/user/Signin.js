import React, { useState } from "react";
import Layout from "../core/Layout";

import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import { API } from "../config";
// import { Link } from "react-router-dom";

import { Redirect } from "react-router-dom";
import { signin } from "../auth";

const Signin = () => {
	const [values, setValues] = useState({
		email: "",
		password: "",
		error: "",
		loading: false,
		redirectToReferrer: false,
	});

	const { email, password, error, loading, redirectToReferrer } = values;

	const handleChange = (name) => (event) => {
		setValues({ ...values, error: false, [name]: event.target.value });
	};

	const clickSubmit = (event) => {
		event.preventDefault();
		setValues({ ...values, error: false, loading: true });
		signin({ email, password }).then((data) => {
			if (data.error) {
				setValues({ ...values, error: data.error, loading: false });
			} else {
				setValues({
					...values,

					redirectToReferrer: true,
				});
			}
		});
	};
	const useStyles = makeStyles((theme) => ({
		root: {
			"& > *": {
				margin: theme.spacing(1),
				width: "25ch",
			},
		},
	}));
	const classes = useStyles();

	const signUpForm = () => (
		<form className={classes.root} noValidate autoComplete="off">
			<div>
				<label>Email</label>
				<TextField
					id="outlined-basic"
					variant="outlined"
					onChange={handleChange("email")}
					type="email"
					value={email}
				/>
			</div>
			<div>
				<label>Password</label>
				<TextField
					id="outlined-basic"
					variant="outlined"
					onChange={handleChange("password")}
					type="password"
					value={password}
				/>
			</div>
			<Button onClick={clickSubmit}>Submit</Button>
		</form>
	);

	const showError = () => (
		<div style={{ display: error ? " " : "none" }}>{error}</div>
	);
	const showLoading = () =>
		loading && (
			<div>
				<h2>loading...</h2>
			</div>
		);
	const redirectUser = () => {
		if (redirectToReferrer) {
			return <Redirect to="/" />;
		}
	};

	return (
		<Layout title="Signin" description="Signin to mobile React E-commerce App">
			{showLoading()}
			{showError()}
			{signUpForm()}
			{redirectUser()}
		</Layout>
	);
};

export default Signin;
