import React, { useState } from "react";
import Layout from "../core/Layout";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import { API } from "../config";
// import { Link } from "react-router-dom";
import { signup } from "../auth";

const Signup = () => {
	const [values, setValues] = useState({
		name: "",
		email: "",
		password: "",
		error: "",
		success: false,
	});

	const { name, email, password, success, error } = values;

	const handleChange = (name) => (event) => {
		setValues({ ...values, error: false, [name]: event.target.value });
	};

	const clickSubmit = (event) => {
		event.preventDefault();
		setValues({ ...values, error: false });
		signup({ name, email, password }).then((data) => {
			if (data.error) {
				setValues({ ...values, error: data.error, success: false });
			} else {
				setValues({
					...values,
					name: "",
					email: " ",
					password: "",
					error: " ",
					success: true,
				});
			}
		});
	};
	const useStyles = makeStyles((theme) => ({
		root: {
			"& > *": {
				margin: theme.spacing(1),
				width: "25ch",
			},
		},
	}));
	const classes = useStyles();

	const signUpForm = () => (
		<form className={classes.root} noValidate autoComplete="off">
			<div>
				<label>Name</label>
				<TextField
					id="outlined-basic"
					// label="Outlined"
					variant="outlined"
					onChange={handleChange("name")}
					type="text"
					value={name}
				/>
			</div>
			<div>
				<label>Email</label>
				<TextField
					id="outlined-basic"
					// label="Outlined"
					variant="outlined"
					onChange={handleChange("email")}
					type="email"
					value={email}
				/>
			</div>
			<div>
				<label>Password</label>
				<TextField
					id="outlined-basic"
					// label="Outlined"
					variant="outlined"
					onChange={handleChange("password")}
					type="password"
					value={password}
				/>
			</div>
			<Button variant="contained" color="primary" onClick={clickSubmit}>
				Submit
			</Button>
		</form>
	);

	const showError = () => (
		<div style={{ display: error ? " " : "none" }}>{error}</div>
	);
	const showSuccess = () => (
		<div style={{ display: success ? " " : "none" }}>
			New account is created.Please <Link to="/signin">Signin</Link>
		</div>
	);
	return (
		<Layout title="Signup" description="Signup to mobile React E-commerce App">
			{showSuccess()}
			{showError()}
			{signUpForm()}
			{/* {JSON.stringify(values)} */}
		</Layout>
	);
};

export default Signup;
