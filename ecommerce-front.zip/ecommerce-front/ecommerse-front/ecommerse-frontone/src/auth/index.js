export const signup = (user) => {
	// console.log("check user", user);

	return (
		fetch(`http://localhost:8000/api/signup`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(user),
		})
			.then((response) => {
				return response.json();
			})
			// .then((data) => {
			// 	console.log("Success", data);
			// })
			.catch((error) => {
				console.log(error);
			})
	);
};

export const signin = (user) => {
	// console.log("check user", user);

	return (
		fetch(`http://localhost:8000/api/signin`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(user),
		})
			.then((response) => {
				return response.json();
			})
			// .then((data) => {
			// 	console.log("Success", data);
			// })
			.catch((error) => {
				console.log(error);
			})
	);
};
