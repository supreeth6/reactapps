import { getElementError } from '@testing-library/dom';
import React from 'react'
import { NavLink } from 'react-router-dom';

let curDate = new Date(2020,4,11,12);
curDate = curDate.getHours();
let greeting = '';
const cssStyle = {};

if (curDate >=1 && curDate <12){
    greeting = 'Good Morning';
    cssStyle.color = 'green';
}else if(curDate>=12 && curDate <19){
    greeting = "Good Afternoon";
    cssStyle.color = 'orange'
}else{
    greeting = "Good Night";
    cssStyle.color = 'black';
}

const Common = (props) => {
    return (
        <>
        <div className="modify">
          <h1 className="Greetings"> Heelo Sir,<span style={cssStyle}> {greeting} </span></h1>
        </div> 
        <section id="header" className="">
            <div className="container-fluid">
                <div className="col-10 mx-auto mt-5">
                <div className="row">
                    <div className="col-md-6 pt-5 pt-lg-0 order-lg-1">
                        <h1>{props.name}<strong className="brand-name"> Astrikos </strong> </h1>
                        <div className="my-3">
                          <NavLink to={props.visit} className="btn btn-success">{props.btname}</NavLink>
                        </div>
                    </div>

                    <div className="col-lg-6 order-1 order-lg-2 header-img">
                        <img src={props.imgsrc} className="img-fluid animated" alt="homeimg" />
                    </div>
                    </div>
                </div>
            </div>
        </section>
    </>
            
    
    )
}

export default Common
