import React, { useEffect, useState } from 'react'
import axios from "axios"

function MenuFile() {
    const [num, setNum] = useState()
    const [name, setName] = useState()
    const [date, setCreated] = useState()
    useEffect(() => {
        async function getData() {
            const res = await axios.get(
                `http://127.0.0.1:5000/api/${num}`
            )
            setName(res.data.name)
            setCreated(res.data.created_date.$date)
        }
        getData();

    })
    return (
           <>
            <select value={num} onChange={(e) => {
                setNum(e.target.value)
            }}>
                <option value="606bf632cb6eacddc05f2abc">Advisories & Guidelines</option>
                <option value="606bfb9fae233d53bce3bfc4">Public Awareness & Sanitation</option>
                <option value="606bfbffae233d53bce3bfc5">Incident Management</option>
                <option value="606bfc3eae233d53bce3bfc6">Law & Order & Traffic Surveillance</option>
                <option value="606bfc55ae233d53bce3bfc7">Food & Medical Supply</option>
                <option value="606bfc75ae233d53bce3bfc8">Cluster Containment & Disaster Management</option>
                <option value="606bfc97ae233d53bce3bfc9">Access to Real Time Data pertaining to all District Events</option>
                <option value="606bfcb7ae233d53bce3bfca">Emergency Response Management</option>
                <option value="606bfcceae233d53bce3bfcb">Pandemic Assessment & Threat Tool</option>
            </select>
            

            <div >
            <div class="p-4 mt-2 p-md-5 mb-4 text-white rounded bg-dark">
                <div className="col-md-6 px-0">
                    <h1 className="display-4 fst-italic">{name}</h1>
                    <h1 className="display-4 fst-italic">{date}</h1>
                    <p>Get the latest advisories and updates on COVID-19. Find out how to bring pass holders into Singapore. Read the requirements for Safe Management Measures at the workplace and our COVID-19 FAQs.</p>
                </div>
          </div>
          </div>
        </>
    )
}

export default MenuFile
