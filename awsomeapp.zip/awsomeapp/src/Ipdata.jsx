import React from 'react';

const Ip = "127.0.012345"


export default Ip