import React from 'react'
import Common from './Common'
import img from "../src/images/img1.jpg"

const About = () => {
    return (
        <>
        < Common
         name ='Welcome to About Page'
         imgsrc = {img}
         visit = '/contact'
         btname = "Contact Now"
          />
        </>
    )
}

export default About
