import './App.css';

function App() {
  return (
      <h1>hii</h1>
  );
}

export default App;
