import React from 'react';
import img from "../src/images/img1.jpg"
import Common from './Common'
import Ipdta from './Ipdata'

const Home = () => {
    return (
        <>
        < Common 
        name ='We are the Talented developer'
        imgsrc = {img}
        visit = '/about'
        btname = "Get Started"
        /> 
        </>
    );
};

export default Home