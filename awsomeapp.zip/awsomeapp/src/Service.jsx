import React, {useState} from 'react'


const Service = () => {

    const [data, setData] = useState({
        fullname:'',
        email:'',
        phone:'',
        msg:'',

    });

    const InputEvent = (event) =>{
        const {name, value} = event.target;
        setData((preVal) =>{
            return {
                ...preVal,
                [name]:value
            }
        })
    };

    const formSubmit = () => {};

    return (
        <>
            <div className="my-2">
                <h1 className="text-center">Contact us</h1>
            </div>
            <div className="container">
                <div className="row">
                    <div className="col-md-6 col-10 mx-auto">
                        <form onSubmit={formSubmit} >

                            <div className="mb-3">
                                <label className="form-label">Full Name</label>
                                <input type="text" className="form-control" id="exampleFullName" name="fullname" value={data.fullname}  onChange={InputEvent} placeholder="Enter your Name here" />
                            </div>
                            <div className="mb-3">
                                <label  className="form-label">Email</label>
                                <input type="email" className="form-control" id="exampleInputEmail1" name="email" value={data.email}  onChange={InputEvent}  placeholder="Enter your Email here" />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">phone</label>
                                <input type="password" className="form-control" id="exampleInputPhone" name="phone" value={data.phone}  onChange={InputEvent} placeholder="Enter your Phone Number here" />
                            </div>
                            <div className="mb-3">
                                <label  className="form-label">Message</label>
                                <textarea type="text" className="form-control" rows="3" id="exampleFormControlTextarea1" name="msg" value={data.msg}  onChange={InputEvent} placeholder="Write your message here"></textarea>
                            </div>
                            <div className="col-12">
                            <button type="submit" className="btn btn-primary">Submit</button>
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </>
    )
}

export default Service
