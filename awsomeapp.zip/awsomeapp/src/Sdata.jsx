import ml from '../src/images/imf2.jpg';
import AI from '../src/images/img3.jpg';
import app from '../src/images/img4.jpeg';
import DS from '../src/images/img5.jpg';
import mar from '../src/images/img6.jpeg';
import web from '../src/images/img1.jpg';

const  Sdata = [
    {
        imgsrc : web,
        title : "Machine Learning"
    },
    {
        imgsrc : ml,
        title : "Artificial Inteligence"
    },
    {
        imgsrc : AI,
        title : "Data Science"
    },
    {
        imgsrc : mar,
        title : "Machine Learning"
    },
    {
        imgsrc : DS,
        title : "Computer Vision"
    },
    {
        imgsrc : app,
        title : "Image Processing"
    },
]

export default Sdata;