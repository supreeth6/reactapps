import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import Addbus from "./components/Addbus";
import Booktickets from "./components/Booktickets";
import ViewDetails from "./components/ViewDetails";

export default class App extends Component {
	render() {
		return (
			<div>
				<AppBar position="static">
					<Toolbar>
						<Typography variant="h6"> Travel agency</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position="static" color="default">
					<Router>
						<ul>
							<li>
								<Link to="/Addbus">Addbus</Link>
							</li>
							<li>
								<Link to="/Booktickets">Booktickets</Link>
							</li>
							<li>
								<Link to="/viewdetails">Viewdetails</Link>
							</li>
						</ul>
						<Switch>
							{/* <Route exact path="/" component={Login}></Route> */}
							<Route exact path="/Addbus" component={Addbus}></Route>
							<Route exact path="/Booktickets" component={Booktickets}></Route>
							<Route exact path="/viewdetails" component={ViewDetails}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
