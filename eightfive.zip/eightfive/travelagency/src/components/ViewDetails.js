import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import finalbookticket from "../actions/actioning";

class ViewDetails extends Component {
	usage = (e) => {
		e.preventDefault();
		// console.log(e);
		// console.log(this.state.detailone);
		let { dispatch } = this.props;
		dispatch(finalbookticket("FINAL_BOOK_TICKET", this.props.teamss.seats));
	};
	render() {
		return (
			<TableContainer component={Paper}>
				<Table aria-label="simple table">
					<TableHead>
						<TableRow>
							<TableCell>Starting Point</TableCell>
							<TableCell>Ending Point</TableCell>
							<TableCell>No of seats</TableCell>
							{/* <TableCell>Description</TableCell> */}
						</TableRow>
					</TableHead>
					<TableBody>
						{this.props.teamss.ticket.map((team, index) => {
							console.log(team);
							return (
								<TableRow key={index}>
									<TableCell>{team.buses.start}</TableCell>
									<TableCell>{team.buses.destination}</TableCell>
									<TableCell>{team.buses.noofseats}</TableCell>
									<Button
										type="button"
										variant="contained"
										color="primary"
										onClick={this.usage}
									>
										Book
									</Button>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		teamss: state,
	};
};
export default connect(mapStateToProps)(ViewDetails);
