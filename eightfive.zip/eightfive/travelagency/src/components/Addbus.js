import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import adding from "../actions/actioning";
import addingseats from "../actions/actioning";

class Addbus extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detail: {
				// noofseats: "",
				type: "",
				make: "",
				startcities: "",
				endcities: "",
			},
			noofseats: 100,
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detail: {
				...this.state.detail,
				[name]: value,
			},
		});
	};
	handleChangeone = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detail: {
				...this.state.noofseats,
				[name]: value,
			},
		});
	};
	addBus = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(adding("ADD_BUS", this.state.detail));
	};
	addseats = (e) => {
		e.preventDefault();
		let { dispatch } = this.props;
		dispatch(addingseats("ADD_SEATS", this.state.noofseats));
	};
	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							No of seats
							<TextField
								id="outlined-basic"
								type="number"
								name="noofseats"
								variant="outlined"
								onChange={this.handleChangeone}
							/>
						</label>
					</div>
					<div>
						<label>
							Type
							<TextField
								id="outlined-basic"
								type="text"
								name="type"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Make
							<TextField
								id="outlined-basic"
								type="text"
								name="make"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							start cities
							<TextField
								id="outlined-basic"
								type="text"
								name="startcities"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							End cities
							<TextField
								id="outlined-basic"
								type="text"
								name="endcities"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addBus}
						color="primary"
					>
						Add Bus
					</Button>
					<Button
						type="button"
						variant="contained"
						onClick={this.addseats}
						color="primary"
					>
						Add seats
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		busadd: state,
	};
};
export default connect(mapStateToProps)(Addbus);
