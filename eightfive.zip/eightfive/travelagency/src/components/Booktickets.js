import React, { Component } from "react";

import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import { InputLabel, MenuItem } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import { bookticket } from "../actions/actioning";

class Booktickets extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detailone: {
				start: "",
				destination: "",
				noofseats: "",
			},
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			detailone: {
				...this.state.detailone,
				[name]: value,
			},
		});
	};
	addListone = (e) => {
		e.preventDefault();
		// console.log(e);
		console.log(this.state.detailone);
		let { dispatch } = this.props;
		dispatch(bookticket("BOOK_TICKET", this.state.detailone));
	};

	render() {
		return (
			<div>
				<form>
					<div>
						<br />
						<div>
							<FormControl>
								<InputLabel>Starting Point</InputLabel>
								<Select
									name="start"
									value={this.state.detailone.start}
									onChange={this.handleChange}
								>
									{this.props.ticketss.bus.map((a, b) => {
										console.log(a);
										return (
											<MenuItem value={a.startcities}>{a.startcities}</MenuItem>
										);
									})}

									{/* <MenuItem value="bangalore">Bangalore</MenuItem>
									<MenuItem value="Mysore">Mysore</MenuItem>
									<MenuItem value="Shimoga">Shimoga</MenuItem> */}
								</Select>
							</FormControl>
						</div>

						<br />

						<div>
							<FormControl>
								<InputLabel>Destination</InputLabel>
								<Select
									name="destination"
									value={this.state.detailone.destination}
									onChange={this.handleChange}
								>
									{this.props.ticketss.bus.map((a, b) => {
										console.log(a);
										return (
											<MenuItem value={a.endcities}>{a.endcities}</MenuItem>
										);
									})}
									{/* <MenuItem value="bangalore">Bangalore</MenuItem>
									<MenuItem value="Mysore">Mysore</MenuItem>
									<MenuItem value="Shimoga">Shimoga</MenuItem> */}
								</Select>
							</FormControl>
						</div>
						<div>
							<label>
								No of seats
								<TextField
									id="outlined-basic"
									type="number"
									name="noofseats"
									variant="outlined"
									onChange={this.handleChange}
								/>
							</label>
						</div>
					</div>
					<br />
					<br />

					<br />
					<br />
					<Button
						type="button"
						variant="contained"
						color="primary"
						onClick={this.addListone}
					>
						Submit
					</Button>
				</form>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	console.log("asdsdadsada", state);
	return {
		ticketss: state,
	};
};
export default connect(mapStateToProps)(Booktickets);
