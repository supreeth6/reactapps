const adding = (actionType, buses) => {
	console.log(buses);
	return {
		type: actionType,
		buses: buses,
	};
};
export default adding;

export const bookticket = (actionType, buses) => {
	console.log(buses);
	return {
		type: actionType,
		buses: buses,
	};
};
export const addingseats = (actionType, buses) => {
	console.log(buses);
	return {
		type: actionType,
		buses: buses,
	};
};
// export default bookticket;
export const finalbookticket = (actionType, buses) => {
	console.log(buses);
	return {
		type: actionType,
		buses: buses,
	};
};
