const initialState = {
	bus: [],
	ticket: [],
	seats: [],
};

const Reducer = (state = initialState, action) => {
	console.log("to update", state, action);

	switch (action.type) {
		case "ADD_BUS":
			const buses = action.buses;
			return {
				...state,
				bus: [...state.bus, buses],
			};

		case "BOOK_TICKET":
			// const { tickets } = action;
			return {
				...state,
				ticket: [...state.ticket, action],
			};
		case "ADD_SEATS":
			return {
				...state,
				seats: [...state.seats, action],
			};
		case "FINAL_BOOK_TICKET":
			return {
				...state,
				seats: Number(state.seats) - Number(state.ticket.noofseats),
			};

		default:
			return state;
	}
};
export default Reducer;
