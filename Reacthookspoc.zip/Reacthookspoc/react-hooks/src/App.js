import React, { useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import UserTable from "./tables/UserTable";

const App = () => {
	const usersData = [
		{ id: 1, name: "Supreeth", username: "supreeth123" },
		{ id: 2, name: "Abhishek", username: "abhishek123" }
	];
	const [users, setUsers] = useState(usersData);
	return (
		<div>
			<h1>Simple operations</h1>
			<h2>Add user</h2>
			<h2>View users</h2>
			<UserTable users={users} />
		</div>
	);
};

export default App;
