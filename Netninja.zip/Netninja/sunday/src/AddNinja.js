import React, { Component } from "react";

export default class AddNinja extends Component {
	state = {
		name: "",
		age: "",
		belt: ""
	};
	handleChange = e => {
		this.setState({
			[e.target.id]: e.target.value
		});
	};
	handlesubmit = e => {
		e.preventDefault();
		// console.log(this.state);
		this.props.addNinja(this.state);
	};
	render() {
		return (
			<div>
				<form onSubmit={this.handlesubmit}>
					<label htmlFor="name">Name:</label>
					<input type="text" id="name" onChange={this.handleChange} />
					<label htmlFor="name">Age:</label>
					<input type="text" id="age" onChange={this.handleChange} />
					<label htmlFor="name">Belts:</label>
					<input type="text" id="belts" onChange={this.handleChange} />
					<button>Submit</button>
				</form>
			</div>
		);
	}
}
