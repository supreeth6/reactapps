import React, { Component } from 'react'
import {Link,withRouter} from "react-router-dom";
import {fetchUsers,fetchSearchUsers} from '../../store/actions';
import  {Button, TableContainer,TableCell,TableHead,TableRow, Table, TableBody}  from '@material-ui/core'
import { connect } from 'react-redux';
export class UserDetails extends Component {
    componentDidMount(){
        console.log("i am tiger");
        const userdata = this.props.searchList.items.filter((item)=>item.login===this.props.match.params.items)
        this.props.dispatch(fetchUsers(userdata[0].repos_url))
        console.log(userdata);
        
    }
    render() {
       console.log(this.props);
       
        return (
            <TableContainer >
            <Table style={{ minWidth: 650 }}>
              <TableHead>
                <TableRow>
                  <TableCell>Git hub User</TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Node Id</TableCell>
                  <TableCell>Type of User</TableCell>
                </TableRow>
              </TableHead>
            <TableBody>
{this.props.userListdata? (
    <>
{this.props.userListdata.map((item)=>(
    <TableRow >
    <TableCell>
     <p><img src={item.owner.avatar_url} alt="avatar" width="250px" /></p>
    </TableCell>
    <TableCell>
    <p>{item.owner.login}</p>
    </TableCell>
    <TableCell>
    <p>{item.owner.node_id}</p>
    </TableCell>
    <TableCell>
    <p>{item.owner.type}</p>
    </TableCell>
    </TableRow>
   
))}
    </>
         ):<>(null)</>}
        </TableBody> 
              </Table>
              </TableContainer>
        )
    }
}
function mapStateToProps(state){
    console.log(state);
    return{
        userListdata: state.users,
        searchList: state.search,
    }
    
}
export default  withRouter(connect(mapStateToProps,null) (UserDetails))
