import {
    LIST_OF_USER_SUCCESS,
    LIST_OF_REPO_SUCCESS,
    LIST_OF_SEARCH_USER_SUCCESS,
    LIST_OF_FAILURE


} from "../constants/action-types"
const initialState =  {
    users:[],
    repo:[],
    search:[],
    error:""
}
const rootReducer =(state = initialState,action)=>{
    switch (action.type){
        case LIST_OF_SEARCH_USER_SUCCESS :{
            return{

                ...state ,search:action.payload
            };

        }
        case LIST_OF_USER_SUCCESS :{
            return{

                ...state ,users:action.payload
            };

        }
        case LIST_OF_REPO_SUCCESS :{
            return{

                ...state ,repo:action.payload
            };

        }
       
        case LIST_OF_FAILURE:{
            return{
                users:[],
                search:[],
                repo:[],
                error:""
            }
        }
        default: return state;
        
    }
   
}
export default rootReducer;