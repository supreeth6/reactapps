import React, { Component } from "react";
import { Route, Link } from "react-router-dom";
const user = ({ match }) => <p>{match.params.id}</p>;

export default class users extends Component {
	render() {
		// console.log(this.props);
		const { url } = this.props.match;
		return (
			<div>
				<h1>Users</h1>
				<strong>select the user</strong>
				{/* <p>{params.id}</p> */}
				<ul>
					<li>
						<Link to="/users/1">Supreeth</Link>
					</li>
					<li>
						<Link to="/users/2">Suhas</Link>
					</li>
					<li>
						<Link to="/users/3">Rajesh</Link>
					</li>
				</ul>
				<Route path="/users/:id" Component={user} />
			</div>
		);
	}
}
