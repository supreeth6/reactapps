import React, { Component } from "react";

export default class contact extends Component {
	onSubmit = () => {
		this.props.history.push("/");
	};
	render() {
		return (
			// <div>
			// 	<h1>Contact</h1>
			// </div>
			<form>
				<input placeholder="name" type="name" />
				<input placeholder="email" type="email" />
				<button onClick={this.onSubmit}>Submit</button>
			</form>
		);
	}
}
