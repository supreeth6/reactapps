import React, { Component } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";

export default class App extends Component {
	render() {
		return (
			<Formik
				initialValues={{
					nameofowner: "",
					vehicleTypes: "",
					noofwheels: "",
					vehiclenumber: "",
				}}
				validationSchema={Yup.object().shape({
					nameofowner: Yup.string().required("name is required"),
					vehiclenumber: Yup.string()
						.min(4, "should be 4")
						.required("required"),
					vehicleTypes: Yup.string().required("required"),
					noofwheels: Yup.string().required("required"),
				})}
				onSubmit={(values, { setErrors }) => {
					console.log(values);
					if (
						values.vehicleTypes === "non-geared" &&
						(values.noofwheels === "four" ||
							values.noofwheels === "eight" ||
							values.noofwheels === "ten")
					) {
						setErrors({ noofwheels: "error" });
					}
				}}
			>
				{({ dirty, isvalid, values, errors }) => {
					return (
						// {console.log(errors.noofwheels)}
						<Form>
							{console.log(errors.noofwheels)}
							{/* {console.log(values)} */}
							Name of owner:
							<Field name="nameofowner" />
							<ErrorMessage name="nameofowner" />
							Vehicle Number:
							<Field name="vehiclenumber" />
							<ErrorMessage name="vehiclenumber" />
							Vehicle Type:
							<Field name="vehicleTypes" as="select">
								<option value="">select</option>
								<option value="geared">Gear</option>
								<option value="non-geared">Non Gear</option>
							</Field>
							No of wheels:
							<Field name="noofwheels" as="select">
								<option value=" ">select</option>

								<option value="two">Two</option>
								<option value="four">Four</option>
								<option value="eight">Eight</option>
								<option value="ten">Ten</option>
							</Field>
							<ErrorMessage name="noofwheels" component="div" />
							<br />
							<button type="submit">submit</button>
						</Form>
					);
				}}
			</Formik>
		);
	}
}
