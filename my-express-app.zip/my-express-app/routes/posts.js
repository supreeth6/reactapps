const express = require("express");
const router = express.Router();
const Post = require("../Post");
var mongoose = require("mongoose");

//all posts

router.get("/", async (req, res) => {
	try {
		const posts = await Post.find();
		res.json(posts);
	} catch (err) {
		res.json({ message: err });
	}
});

//sumbit the post

router.post("/", async (req, res) => {
	// console.log(req.body);
	const post = new Post({
		title: req.body.title,
		description: req.body.description,
	});

	try {
		const savedPost = await post.save();
		res.json(savedPost);
	} catch (err) {
		res.json({ message: err });
	}
});

//delete one post

router.delete("/:postId", async (req, res) => {
	console.log(req.body);
	try {
		const removedPost = await Post.remove({ _id: req.params.postId });
		res.json(removedPost);
	} catch (err) {
		res.json({ message: err });
	}
});

//update onepost

router.patch("/:postId", async (req, res) => {
	try {
		const updatedPost = await Post.updateOne(
			{ _id: req.params.postId },
			{ $set: { title: req.body.title } }
		);
		res.json(updatedPost);
	} catch (err) {
		res.json({ message: err });
	}
});

//update multiple post

router.put("/update/:_id/:id", (req, res) => {
	console.log(req.params);
	console.log("i am stuk");

	Post.updateMany(
		{
			_id: {
				$in: [
					mongoose.Types.ObjectId(req.params._id),
					mongoose.Types.ObjectId(req.params.id),
				],
			},
		},
		{ title: "universe" },
		function (err, doc) {
			res.send("am updated");
		}
	);
});

router.put("/updateone/:id", async (req, res) => {
	console.log("something");
	try {
		const updatedPostone = await Post.updateOne(
			{ _id: req.params.id },
			{ $set: { title: req.body.title } }
		);
		res.json(updatedPostone);
	} catch (err) {
		res.json({ message: err });
	}
});
//delete multiple post

router.delete("/deletes/:_id/:id", (req, res) => {
	console.log("hello i got");
	console.log(req.params);
	Post.remove(
		{
			_id: {
				$in: [
					mongoose.Types.ObjectId(req.params._id),
					mongoose.Types.ObjectId(req.params.id),
				],
			},
		},
		function (err, doc) {
			res.send("am deleted");
		}
	);
});

// router.delete("/:_postId/:postId", async (req, res) => {
// 	try {
// 		const removemulpost = await Post.remove(
// 			{ _id: req.params.postId },
// 			{ id: req.params.postId }
// 		);
// 		res.json(removemulpost);
// 	} catch (err) {
// 		res.json({ message: err });
// 	}
// });

// router.post("/idex", (req, res) => {
// 	console.log("req", req.body);
// 	let temp = req.body;
// 	console.log(temp.length);
// 	let removedpost = [];
// 	for (i = 0; i < req.body.length; i++) {
// 		console.log(temp[i].title);
// 		removedpost = Post.remove({ _id: temp[i].title });
// 		console.log(removedpost);

// 		// removedpost.push(removedpost1);
// 	}
// 	// res.json(removedpost1);
// 	// res.send(removedpost);
// });

module.exports = router;
