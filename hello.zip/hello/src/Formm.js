import React, { Component } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';

export default class Formm extends Component {
  render() {
    return (
      <Formik
        initialValues={{
          name: '',
          number: '',
          vehicleType: '',
          wheels: '',
        }}
        validationSchema={Yup.object().shape({
          name: Yup.string().required('Name is required'),
          /* number:Yup.string().matches() */
          number: Yup.string().min(10, 'should be 10').required('required'),
          vehicleType: Yup.string().required('required'),
          wheels: Yup.string().required('required'),
        })}
        onSubmit={(values, { setErrors }) => {
          console.log(values);
          if (
            values.vehicleType === 'non-geared' &&
            (values.wheels === 'four' ||
              values.wheels === 'eight' ||
              values.wheels === 'ten')
          ) {
            setErrors({ wheels: 'error' });
          }
        }}
      >
        {({ dirty, isValid, values, errors }) => {
          return (
            <Form>
              {console.log(errors.wheels)}
              NAME:
              <Field name="name" />
              <br></br>
              <ErrorMessage name="name" component="div" />
              NUMBER:
              <Field name="number" />
              <br></br>
              <ErrorMessage name="number" component="div" />
              <br></br>
              VEHICLE-TYPE
              <Field name="vehicleType" as="select">
                <option value="">select</option>
                <option value="geared">Gear</option>
                <option value="non-geared">Non-Gear</option>
              </Field>
              <br></br>
              wheels:
              <Field name="wheels" as="select">
                <option value="">select</option>
                <option value="two">TWO</option>
                <option value="four">FOUR</option>
                <option value="eight">EIGHT</option>
                <option value="ten">TEN</option>/
              </Field>
              <ErrorMessage name="wheels" component="div" />
              {/* {values.vehicleType === 'geared' ? (
                <Field name="wheels" as="select">
                  <option value="">select</option>
                  <option value="two">TWO</option>
                  <option value="four">FOUR</option>
                </Field>
              ) : (
                <Field name="wheels" as="select">
                  <option value="">select</option>
                  <option value="eight">EIGHT</option>
                  <option value="ten">TEN</option>
                </Field>
              )} */}
              <br></br>
              <button type="submit" disabled={!dirty || !isValid}>
                Click
              </button>
            </Form>
          );
        }}
      </Formik>
    );
  }
}
