const express = require("express");
const router = express.Router();
const bodyparser = require("body-parser");
app.use(bodyparser.json());

router.get("/customers", (req, res) => {
	let customer = req.body;
	var sql = "SET";
});
