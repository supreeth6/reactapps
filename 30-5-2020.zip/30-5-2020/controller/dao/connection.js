const mysql = require("mysql");
var mysqlConnection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "Welcome@123",
	database: "store",
	multipleStatements: true,
});

exports.module.mysqlConnection = mysqlConnection;
