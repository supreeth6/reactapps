const mysql = require("mysql");
const express = require("express");
const bodyparser = require("body-parser");
var app = express();
var PDFDocument = require("pdfkit");
var fs = require("fs");
var path = require("path");
var cors = require("cors");
var jwt = require("jsonwebtoken");
var http = require("http");
var Cryptr = require("cryptr"),
	cryptr = new Cryptr("myTotallySecretKey");
var atob = require("atob");
const expressValidator = require("express-validator");
// app.use(expressValidator());
//var router = app.Router();
app.use(bodyparser.json());
// var customer = require("./models/Customer");
// app.use(customer);

var mysqlConnection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "Welcome@123",
	database: "store",
	multipleStatements: true,
});

mysqlConnection.connect((err) => {
	if (!err) console.log("Connection Established Successfully");
	else console.log("Connection Failed!" + JSON.stringify(err, undefined, 2));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`listneing ${port}`));

// app.post("/signup", (req, res) => {
// 	// var fname = req.body.firstname;
// 	// var lname = req.body.lastname;
// 	// var pass = req.body.password;
// 	// var email = req.body.email;
// 	// var dec_pass = atob(pass);
// 	// var encrypted_pass = cryptr.encrypt(dec_pass);
// 	let signupuser = req.body;
// 	var sql =
// 		"INSERT INTO logins(firstname','lastname','email','passwor') VALUES ?";
// 	// fname +
// 	// " ' ,' " +
// 	// lname +
// 	// " ','" +
// 	// email +
// 	// " ','" +
// 	// encrypted_pass +
// 	// " ')";
// 	var values = [
// 		[
// 			signupuser.firstname,
// 			signupuser.lastname,
// 			signupuser.passwor,
// 			signupuser.email,
// 		],
// 	];

// 	mysqlConnection.query(sql, [values], function (err, result) {
// 		if (err) throw err;
// 		console.log("signuphit");
// 		res.json({ values });

// 		// res.end(JSON.stringify(result));
// 	});
// });
// app.post("/signin", (req, res) => {
// 	var name = req.body.email;
// 	var pass = req.body.password;
// 	var dec_pass = atob(pass);
// 	var encrypted_pass = cryptr.encrypt(dec_pass);

// 	var sql =
// 		"SELECT id, first_name, last_name, email FROM `login` WHERE `email`='" +
// 		name +
// 		"' and password = '" +
// 		encrypted_pass +
// 		"'";

// 	mysqlConnection.query(sql, function (err, results) {
// 		if (results != "") {
// 			console.log(JSON.stringify(results));

// 			var data = JSON.stringify(results);

// 			var secret = "TOPSECRETTTTT";
// 			var now = Math.floor(Date.now() / 1000),
// 				iat = now - 10,
// 				expiresIn = 3600,
// 				expr = now + expiresIn,
// 				notBefore = now - 10,
// 				jwtId = Math.random().toString(36).substring(7);
// 			var payload = {
// 				iat: iat,
// 				jwtid: jwtId,
// 				audience: "TEST",
// 				data: data,
// 			};

// 			jwt.sign(
// 				payload,
// 				secret,
// 				{ algorithm: "HS256", expiresIn: expiresIn },
// 				function (err, token) {
// 					if (err) {
// 						console.log("Error occurred while generating token");
// 						console.log(err);
// 						return false;
// 					} else {
// 						if (token != false) {
// 							//res.send(token);
// 							res.header();
// 							res.json({
// 								results: { status: "true" },
// 								token: token,
// 								data: results,
// 							});
// 							res.end();
// 						} else {
// 							res.send("Could not create token");
// 							res.end();
// 						}
// 					}
// 				}
// 			);
// 		} else if (results == "") {
// 			console.log("not a user");
// 		}
// 	});
// });

app.post("/customer", (req, res) => {
	// console.log("hello");
	// let token = jwtgeneration(req, res);
	// console.log(token);
	let customer = req.body;
	if (req.body.phone_number.length !== 10) {
		res.json("enter valid phone no");
	}
	console.log(customer);
	var sql = "INSERT INTO users (name,retailer, phone_number,cid) VALUES ?";

	var values = [
		[customer.name, customer.retailer, customer.phone_number, customer.cid],
	];
	mysqlConnection.query(sql, [values], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ values });
	});
});

app.post("/customer/credit", (req, res) => {
	let credit = req.body;
	console.log(credit);
	var sql =
		"INSERT INTO credit (cid, amount,description,transaction_time) VALUES ?";

	var values = [[credit.cid, credit.amount, credit.description, new Date()]];
	mysqlConnection.query(sql, [values], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ values });
	});
});

app.post("/customer/debit", (req, res) => {
	let debit = req.body;
	console.log(debit);
	var sql =
		"INSERT INTO debit (cid, amount,description,transaction_time) VALUES ?";

	var values = [[debit.cid, debit.amount, debit.description, new Date()]];
	mysqlConnection.query(sql, [values], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ values });
	});
});

app.get("/customer/:cid/logs", (req, res) => {
	let cid = req.params.cid;
	console.log(cid);

	var sql =
		"SELECT cu.name, (c.amount) , (d.amount) FROM users cu, debit d , credit c WHERE cu.cid=? and c.cid=? and d.cid = ?";

	mysqlConnection.query(sql, [cid, cid, cid], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ result });
	});
});

app.get("/customer/info", (req, res) => {
	var sql =
		"SELECT cu.name, c.amount , d.amount FROM users cu, debit d , credit c";

	mysqlConnection.query(sql, function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ result });
	});
});

app.get("/customer/infopdf", (req, res) => {
	dummy2(req, res);
});

async function dummy() {
	var sql =
		"SELECT cu.name, c.amount , d.amount FROM users cu, debit d , credit c";

	mysqlConnection.query(sql, function (err, result) {
		console.log(result);
		if (err) throw err;
		console.log("1 record inserted");
		doc = new PDFDocument();
		doc.pipe(fs.createWriteStream("out.pdf", result));
		// doc.font("font/PaletinoBold.ttf").fontsize(25).text(100, 100);
	});
}

async function dummy2(req, res) {
	await dummy();

	var file = fs.createReadStream("out.pdf", "binary");
	var stat = fs.statSync("out.pdf");
	res.setHeader("Content-Length", stat.size);
	res.setHeader("Content-Type", "application/pdf");
	res.setHeader("Content-Disposition", "attachment; filename=quote.pdf");
	//res.pipe(file, "binary");
	res.end();
}

var secret_key = "akhfljalfsdfgksajdhfk";

function jwtgeneration(req, res) {
	let jwt_token;
	jwt.sign(
		{
			name: req.body.name,
		},
		secret_key,
		{ algorithm: "HS256", expiresIn: 36000 },

		(err, token) => {
			res.json({ token });
		}
	);
}

app.post("/customer/login2", (req, res) => {
	jwtgeneration(req, res);
});
