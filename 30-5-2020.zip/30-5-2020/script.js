const mysql = require("mysql");
const express = require("express");
const bodyparser = require("body-parser");
var app = express();
var PDFDocument = require("pdfkit");
var fs = require("fs");
var path = require("path");
//var router = app.Router();
app.use(bodyparser.json());
// var customer = require("./models/Customer");
// app.use(customer);

var mysqlConnection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "Welcome@123",
	database: "store",
	multipleStatements: true,
});

mysqlConnection.connect((err) => {
	if (!err) console.log("Connection Established Successfully");
	else console.log("Connection Failed!" + JSON.stringify(err, undefined, 2));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`listneing ${port}`));

app.post("/customer", (req, res) => {
	let customer = req.body;
	console.log(customer);
	var sql = "INSERT INTO customer (name, phone_number,cid) VALUES ?";

	var values = [[customer.name, customer.phone_number, customer.cid]];
	mysqlConnection.query(sql, [values], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ values });
	});
});

app.post("/customer/credit", (req, res) => {
	let credit = req.body;
	console.log(credit);
	var sql = "INSERT INTO credit (cid, amount,transaction_time) VALUES ?";

	var values = [[credit.cid, credit.amount, new Date()]];
	mysqlConnection.query(sql, [values], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ values });
	});
});

app.post("/customer/debit", (req, res) => {
	let debit = req.body;
	console.log(debit);
	var sql = "INSERT INTO debit (cid, amount,transaction_time) VALUES ?";

	var values = [[debit.cid, debit.amount, new Date()]];
	mysqlConnection.query(sql, [values], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ values });
	});
});

app.get("/customer/:cid/logs", (req, res) => {
	let cid = req.params.cid;
	console.log(cid);

	var sql =
		"SELECT cu.name, sum(c.amount) , sum(d.amount) FROM customer cu, debit d , credit c WHERE cu.cid=? and c.cid=? and d.cid = ?";

	mysqlConnection.query(sql, [cid, cid, cid], function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ result });
	});
});

app.get("/customer/info", (req, res) => {
	var sql =
		"SELECT cu.name, c.amount , d.amount FROM customer cu, debit d , credit c";

	mysqlConnection.query(sql, function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		res.json({ result });
	});
});

app.get("/customer/infopdf", (req, res) => {
	dummy2(req, res);
});

async function dummy() {
	var sql =
		"SELECT cu.name, c.amount , d.amount FROM customer cu, debit d , credit c";

	mysqlConnection.query(sql, function (err, result) {
		if (err) throw err;
		console.log("1 record inserted");
		doc = new PDFDocument();
		doc.pipe(fs.createWriteStream("out.pdf", result));
		// doc.font("font/PaletinoBold.ttf").fontsize(25).text(100, 100);
	});
}

async function dummy2(req, res) {
	await dummy();

	var file = fs.createReadStream("out.pdf", "binary");
	var stat = fs.statSync("out.pdf");
	res.setHeader("Content-Length", stat.size);
	res.setHeader("Content-Type", "application/pdf");
	res.setHeader("Content-Disposition", "attachment; filename=quote.pdf");
	//res.pipe(file, "binary");
	res.end();
}
