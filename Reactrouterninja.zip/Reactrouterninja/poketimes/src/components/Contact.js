import React from "react";

const Contact = (props) => {
	// setTimeout(() => {
	// 	props.history.push("./About.js");
	// }, 2000);
	return (
		<div className="container">
			<h4 className="center">Contact </h4>
			<p>Lorem etyuiop sdfghjkl xcvbnm,</p>
		</div>
	);
};

export default Contact;
