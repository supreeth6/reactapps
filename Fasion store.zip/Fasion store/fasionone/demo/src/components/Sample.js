import React from 'react'

export default function Sample() {
  const log = () => console.log('logging')
  return <div>Sample</div>
}
