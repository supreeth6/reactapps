import React, { Component } from 'react'

export default class Supreeth extends Component {
  render() {
    return <div>supreet</div>
  }
}
