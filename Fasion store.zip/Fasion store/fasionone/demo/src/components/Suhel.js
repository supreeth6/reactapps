import React, { Component } from 'react'

export default class Suhel extends Component {
  render() {
    return (
      <div>
        <h1>hello</h1>
      </div>
    )
  }
}
