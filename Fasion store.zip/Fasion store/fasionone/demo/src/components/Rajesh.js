import React, { Component } from 'react'

class Rajesh extends Component {
  render() {
    return <div>Rajesh</div>
  }
}

export default Rajesh
