import React, { Component } from 'react'

export class Prateek extends Component {
    render() {
        return (
            <div>
                Prateek's commit
            </div>
        )
    }
}

export default Prateek
