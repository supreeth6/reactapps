import React, { Component } from "react";
import App from "./APP";
import AddItem from "./AddItem";

export default class Add extends Component {
	constructor() {
		super();
		this.state = {
			lists: [],
			items: {}
		};
	}
	handleAddList(list) {
		let lists = this.state.lists;
		lists.push(list);
		let person = list;
		this.setState({
			lists: lists
		});
	}
	handleAddItem(item) {
		let items = this.state;
		this.setState({
			items: items
		});
	}
	render() {
		return (
			<div className="Add">
				<AddList addlist={this.handleAddList.bind(this)} />
				<div id="listsDiv" className="List">
					<Lists
						lists={this.state.lists}
						items={this.state.items}
						addItem={this.handleAddItem.bind(this)}
					/>
				</div>
			</div>
		);
	}
}
export default Add;
