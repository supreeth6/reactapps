import React, { Component } from "react";

export default class AddItem extends Component {
	constructor() {
		super();
		this.state = {
			newItem: {}
		};
	}
	handleSubmit(e) {
		e.preventDefault();
		if (this.refs.id.value === "") {
			alert("Add item");
		} else {
			this.setState(
				{
					name: this.refs.id.value
				},
				function() {
					this.props.addItem(this.state);
				}
			);
		}
	}
	render() {
		var divName = "add" + this.props.idName;
		return (
			<div className="addItemDiv">
				<h4>Add {this.props.idName}</h4>
				<form ref="form" onSubmit={this.handleSubmit.bind(this)}>
					<div id={divName} ref={divName}>
						<label>Name</label>
						<br />
						<input type="text" ref="id" />
					</div>
					<br />
				</form>
			</div>
		);
	}
}
export default AddItem;
