import React from "react";
// import logo from './logo.svg';
// import './App.css';

function App() {
	return (
		<div>
			<form>
				<label>
					Dress code
					<input type="text" name="name" onChange={handleAddItem} />
					<br />
					Brand
					<input type="text" name="name" onChange={handleAddItem} />
					<br />
					Gender
					<input type="text" name="name" onChange={handleAddItem} />
					<br />
					Types
					<input type="text" name="name" onChange={handleAddItem} />
					<br />
					Price
					<input type="text" name="name" onChange={handleAddItem} />
					<br />
					Stock
					<input type="text" name="name" onChange={handleAddItem} />
					<br />
					<input type="submit" value="submit" onChange={handleSubmit} />
				</label>
			</form>
		</div>
	);
}
// ReactDOM.render(<App />, document.getElementById("root"));

export default App;
