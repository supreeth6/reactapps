import React, { Component } from "react";

export default class Lists extends Component {
	constructor(props) {
		super(props);
	}
	render() {
        const Lists = [{ "lists": "items " }, { "lists": "items" }];
    const Items=Lists.map((d)=><li key={d.name}>{d.name}</li>
		return <div></div>;
	}
}
