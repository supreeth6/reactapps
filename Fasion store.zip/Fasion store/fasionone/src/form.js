// import React, { Component } from "react";

// export default class form extends Component {
// 	render() {
// 		return (
// 			<div>
// 				<form>
// 					<label>
// 						Name:
// 						<input type="text" name="name" />
// 					</label>
// 				</form>
// 			</div>
// 		);
// 	}
// }
