package captwo;

import java.util.Scanner;

public class SoftwareMain {
	public static void main(String []args) {
		Scanner scan =new Scanner(System.in);
		Software[] soft=null;
		Software[] result=null;
		boolean flag=false;
		
		do {
			System.out.println("1.Add software");
			System.out.println("2.sort based on cost");
			System.out.println("3.Search software based on id");
			System.out.println("4.Exit");
			
			System.out.println("enter your choice");
			int choice=scan.nextInt();
			
			switch(choice) {
			case 1:System.out.println("enter how many software needed");
			int n=scan.nextInt();
			
			soft=new Software[n];
			
			for(int i=0;i<soft.length;i++) {
				System.out.println("enter the id");
				int id=scan.nextInt();
				System.out.println("enter the liscense number");
				long lisno=scan.nextLong();
				System.out.println("enter the Name");
				String name=scan.nextLine();
				scan.nextLine();
				System.out.println("enter the cost");
				int cost=scan.nextInt();
				soft[i]=new Software(id,lisno,name,cost);
				
			}
			System.out.println("Softwares are ....");
			for(int i=0;i<soft.length;i++) {
				System.out.println(soft[i]);
			}
			break;
			
			case 2:{
				result=sort(soft);
				System.out.println("Sorted softwares ");
				for(int i=0;i<soft.length;i++) {
					System.out.println(result[i]);
					
			}
				System.out.println("Enter the id");
				int sid=scan.nextInt();
				Lsearch(soft,sid);
				break;
			}
			case 3:Software[] result1=sortID(soft);
			for(int i=0;i<soft.length;i++) {
				System.out.println(result1[i]);
			}
			System.out.println("Enter the software ID");
			int softID=scan.nextInt();
			int position =binsearch(result1,softID,0,result1.length-1);
			if(position>=0)
			{
				System.out.println(result1[position]);
			}
			else {
				System.out.println("not found");
			}
			break;
			
		
			
		}
		
	}while(true);
	}
	private static Software [] sort(Software[] soft) {
		for(int i=0;i<soft.length;i++) {
			int item=soft[i].getCost();
			Software temp=soft[i];
			int j=i-1;
			while(j>-1 && soft[i].getCost()>item) {
				soft[j+1]=soft[j];
				j--;
			}
			
		
		soft[j+1]=temp;
	}
	return soft;
	}
	private static void Lsearch(Software[] soft,int key)
	{
		for(int i=0;i<soft.length;i++)
		{
			if(soft[i].getId()==key) {
				System.out.println("id found");
			}
			else
			{
				System.out.println("id not found");
			}
		}
	}
	private static Software[] sortID(Software[] soft) {
		for(int i=0;i<soft.length;i++)
		{
			int item=soft[i].getCost();
			Software temp=soft[i];
			int j=i-1;
			while(j>-1 && soft[i].getCost()>item)
			{
				soft[j+1]=soft[j];
				j--;
			}
			soft[j+1]=temp;
		}
		return soft;
	}
	private static int binsearch(Software[] soft,int key,int low,int high) {
		int mid=(low+high)/2;
		while(low<=high)
		{
			if(soft[mid].getId()==key) {
				return mid;
			}
			else if(soft[mid].getId()<key) {
				low=mid+1;
			}
			else
				high=mid-1;
			mid=(low+high)/2;
		}
		return -1;
	}
}


