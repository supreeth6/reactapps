package captwo;

import java.util.Scanner;

public class PersonMain {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		Person[] person=null;
		//Person[]result=null;
		boolean flag=false;
		person = new Person[1];
		for (int i = 0; i < person.length; i++) {
			System.out.println("Enter the name");
	        String name = scan.nextLine();
			scan.nextLine();
			System.out.println("enter the address of the person");
			String address = scan.nextLine();
			System.out.println("enter the simcard");
			String simcard = scan.next();
			person[i] = new Person(name,address,simcard);
		}
		
		System.out.println("Enter the number of simcards");
		int n = scan.nextInt();
		sim= new simcard[n];
		for (int i = 0; i < simcard.length; i++) {
			System.out.println("Enter the number in simcard");
			int simcardnumber = scan.nextInt();
			scan.nextLine();
			System.out.println("enter the balance");
			int balance = scan.nextInt();
			System.out.println("enter the network provider");
			String networkprovider = scan.nextLine();
			person[i] = new simcard(simcardnumber,balance, networkprovider);
		}
		

		do {
			System.out.println("1.Print all the details of person");
			System.out.println("2.sort the sim card based on balance");
			System.out.println("3.Recharge the balance");
			System.out.println("4.Exit");
			System.out.println("enter the choice");
			int choice = scan.nextInt();

			switch (choice) {
			case 1: 
				System.out.println("The person details are");
				for(int i=0;i<n;i++) {
					
				
				System.out.println(person[i]);
				}
				
			case 2: 
				int result = sort(balance);
				for (int i = 0; i < person.length; i++) {
					System.out.println(result[i]);
				}
				break;
			
			case 3: {
				result = recharge(sim);
				System.out.println();
				break;
			}
			case 4: {
				System.exit(0);
			}			

			}

		} while (true);
	}
	public static void sort(int balance) {
		for (int i = 0; i<person.length; i++) {
				for (int j = 0; j < person[i].getsimcards(); j++) {
							if(Person[i].simcard[j].getBalance()<Person[i].simcard[i].getBalance())
								
							{
								 getBalance[j] = getBalance[j+1];
								 balance[j] =simcard[i];
								 simcard[i] = object;
							}
						}
					}
					for (int j = 0; j < simcard.length; j++) {
						
						System.out.println(simcard[j]);
					}
					
				}

	}
	


