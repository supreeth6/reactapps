package captwo;

public class simcard {
	public static int length;
	int number;
	int balance;
	String networkprovider;
	public simcard() {
		super();
		// TODO Auto-generated constructor stub
	}
	public simcard(int number, int balance, String networkprovider) {
		super();
		this.number = number;
		this.balance = balance;
		this.networkprovider = networkprovider;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getNetworkprovider() {
		return networkprovider;
	}
	public void setNetworkprovider(String networkprovider) {
		this.networkprovider = networkprovider;
	}

}
