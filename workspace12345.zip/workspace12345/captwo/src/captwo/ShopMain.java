package captwo;

import java.util.Scanner;

public class ShopMain {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Shop[] shop = null;
		Shop[] result = null;
		boolean flag = false;

		do {
			System.out.println("1.Add shop");
			System.out.println("2.sort by GST number");
			System.out.println("3.Display the shop having third heighest revenue");
			System.out.println("4.Search for the particular shop");
			System.out.println("5.Exit");
			System.out.println("enter the choice");
			int choice = scan.nextInt();

			switch (choice) {
			case 1: {
				System.out.println("Enter the number of shops");
				int n = scan.nextInt();
				shop = new Shop[n];
				for (int i = 0; i < shop.length; i++) {
					System.out.println("Enter the id");
					int id = scan.nextInt();
					scan.nextLine();
					System.out.println("enter the name");
					String name = scan.nextLine();
					System.out.println("enter the revenue");
					int revenue = scan.nextInt();
					System.out.println("enter the gst number");
					int gstno = scan.nextInt();
					shop[i] = new Shop(id, name, revenue, gstno);
				}
				System.out.println("Dates are __");
				for (int i = 0; i < n; i++) {
					System.out.println(shop[i]);
				}
				break;

			}
			case 2: {
				result = sort(shop);
				for (int i = 0; i < shop.length; i++) {
					System.out.println(result[i]);
				}
				break;
			}
			case 3: {
				result = thirdhighest(shop);
				System.out.println("Third heighest is" + result[result.length - 3]);
				break;
			}
			case 4: {
				Shop[] result1 = sortId(shop);
				for (int i = 0; i < shop.length; i++) {
					System.out.println(result1[i]);
				}
				System.out.println("enter the shop id");
				int shopid = scan.nextInt();
				int position = binsearch(result1,shopid, 0, result1.length - 1);
				if (position >= 0) {
					System.out.println(result1[position]);
				} else {
					System.out.println("not found");
				}
				break;

			}
			case 5: {
				System.exit(0);
			}

			}

		} while (true);
	}

	private static Shop[] sort(Shop[] shop) {
		for (int i = 0; i < shop.length; i++) {
			int item = shop[i].getGstno();
			Shop temp = shop[i];
			int j = i - 1;
			while (j > -1 && shop[i].getGstno() > item) {
				shop[j + 1] = temp;
			}
		}
			return shop;
	}
	
	private static Shop[] sortId(Shop[] shop) {
		for (int i = 0; i < shop.length; i++) {
			int item = shop[i].getGstno();
			Shop temp = shop[i];
			int j = i - 1;
			while (j > -1 && shop[i].getGstno() > item) {
				shop[j + 1] = temp;
			}
		}
			return shop;
	}

	private static Shop[] thirdhighest(Shop[] shop) {
		for (int i = 0; i < shop.length; i++) {
			int item = (int) shop[i].getRevenue();
			Shop temp = shop[i];
			int j = i - 1;
			while (j > -1 && shop[i].getRevenue() > item) {
				shop[j + 1] = shop[j];
				j--;
			}
			shop[j + 1] = temp;
		}
		return shop;
	}

	private static int binsearch(Shop[] shop, int key, int low, int high) {
		while (low <= high) {
			int mid = (low + high) / 2;
			if (shop[mid].getId() == key) {
				return mid;
			} else if (shop[mid].getId() > key) {
				return binsearch(shop, key, low, high);
			} else
				return binsearch(shop, key, low, high);
		}
		return -1;
	}
}
