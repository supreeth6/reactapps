package captwo;

public class Person {

String name;
String address;
String simcard;
public Person() {
	super();
	// TODO Auto-generated constructor stub
}
public Person(String name, String address,  String simcard) {
	super();
	this.name = name;
	this.address = address;
	this.simcard = simcard;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getSimcard() {
	return simcard;
}
public void setSimcard(String simcard) {
	this.simcard = simcard;
}
}
