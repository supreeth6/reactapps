package captwo;

import java.util.Scanner;

public class Codingchallenge2 {static Scanner scan =new Scanner(System.in);
static int row;
static int col;
static String arr[][]=new String[row][col];
public static void main(String args[]) {
  boolean bool=true;
	do
	{
		System.out.println("Press 1 for taking two d string matrix");
		System.out.println("Press 2 for replacing vowels with %");
		System.out.println("Press 3 for counting the number of spaces");
		System.out.println("Press 4 for making lower case to upper case and vice versa");
	    System.out.println("Enter your choice");
	    int choice=scan.nextInt();
	    switch(choice)
	    {
	    case 1:String res1[][]=inputstringmatrix();
	    	   System.out.println(res1);
	    		break;
	    case 2:String res2=replacevowels();
	           System.out.println(res2);
	    		break;
	    case 3:int res3=countspaces();
	    		System.out.println(res3);
	    		break;
	    case 4:String res4=lctoup();
	    		System.out.println(res4);
	    		break;
	    default:System.out.println("enter the correct choice");
	    }
	}while(bool);
}
public static String[][] inputstringmatrix() {
	System.out.println("enter the number of rows");
	 row=scan.nextInt();
	System.out.println("enter the number of columns");
	 col=scan.nextInt();
	//String arr[][]=new String[row][col];
	System.out.println("enter the elements");
	for(int i=0;i<row;i++) {
		for(int j=0;j<col;j++) {
			arr[i][j]=scan.nextLine();
			//System.out.println(arr);
		}
	}
	for(int i=0;i<row;i++) {
		for(int j=0;j<col;j++) {
			System.out.println("The input matrix is "+arr[i][j]);
		}
	}
	return arr;
}
public static String[][] replacevowels(String[][]res1) {
	//String str="mindtree";
	String strnew=" ";
	for(int i=0;i<row;i++) {
		for(int j=0;j<col;j++)
	if(res1.charAt[i][j]=='a'||res1.charAt[i][j]=='e'||res1.charAt[i][j]=='i'||res1.charAt[i][j]=='o'||res1.charAt[i][]=='u') {
		strnew+="%";
	}
	else {
		strnew+=res1.charAt(i);
	}
	}
	return strnew;
}
public static int countspaces() {
	int space=0;
	String str2="welcome to possible mindtree";
	for(int i=0;i<str2.length();i++) {
		if(str2.charAt(i)==' ') {
			space++;
		}
	}
	String[] words=new String[++space];
	int index=0;
	String temp=" ";
	for(int i=0;i<str2.length();i++) {
		if(str2.charAt(i)==' ') {
			words[index++]=temp;
			temp=" ";
		}else {
			temp+=str2.charAt(i);
		}
	}
	words[index++]=temp;
	return space;
}
public static String lctoup() {
	String string;
	System.out.println("enter the string");
	string=scan.next();
	String resulting="";
	for(int i=0;i<string.length();i++) {
	if(string.charAt(i)>=97 && string.charAt(i)<=122)
	{
		resulting+=(char)(string.charAt(i)-32);
	}
	else {
		resulting+=(char)(string.charAt(i)+32);
	}
	//System.out.println(resulting);
	}
	System.out.println(resulting);
	return string;
}


}
