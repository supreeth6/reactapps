package captwo;

import java.util.Scanner;

public class CoffeeMain {
	static Scanner sc=new Scanner(System.in);
	public static void main(String args[]) {
		String cust_name;
		String mob_no;
		double feedback;
		System.out.println("enter the number of customers");
		int n=sc.nextInt();
		Coffee[] c=new Coffee[n];
		for(int i=0;i<n;i++) {
			System.out.println("enter the name");
			cust_name=sc.nextLine();
			sc.nextLine();
			System.out.println("enter the moblie number");
			mob_no=sc.nextLine();
			System.out.println("enter the ratings between 0 and 5");
			feedback=sc.nextDouble();
			if(feedback>=0 && feedback<=5) {
				feedback=feedback;
			}
			else {
				System.out.println("please give proper rating");
			}
			//sc.nextInt();
		}
		Coffee c1=new Coffee();
		c1.averageFeedback(c,n);
		c1.maxmin(c,n);
		c1.print(c,n);
	}
	

}
