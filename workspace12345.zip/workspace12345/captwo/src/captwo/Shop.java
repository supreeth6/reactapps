package captwo;

public class Shop {
	int id;
	String name;
	int revenue;
	int gstno;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public Shop(int id, String name, int revenue, int gstno) {
		super();
		this.id = id;
		this.name = name;
		this.revenue = revenue;
		this.gstno = gstno;
	}
	public Shop() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRevenue() {
		return revenue;
	}
	public void setRevenue(int revenue) {
		this.revenue = revenue;
	}
	public int getGstno() {
		return gstno;
	}
	public void setGstno(int gstno) {
		this.gstno = gstno;
	}
	@Override
	public String toString() {
		return "Shop [id=" + id + ", name=" + name + ", revenue=" + revenue + ", gstno=" + gstno + "]";
	}
	
	

}
