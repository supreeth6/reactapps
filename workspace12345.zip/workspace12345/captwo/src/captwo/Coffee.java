package captwo;

public class Coffee {
String name;
String mobileno;
double rating;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public double getRating() {
	return rating;
}
public void setRating(double rating) {
	this.rating = rating;
}
//@Override
//public String toString() {
//	return "Coffee [name=" + name + ", mobileno=" + mobileno + ", rating=" + rating + "]";
//}
public Coffee(String name, String mobileno, double rating) {
	super();
	this.name = name;
	this.mobileno = mobileno;
	this.rating = rating;
}
public Coffee() {
	super();
	// TODO Auto-generated constructor stub
}
static void print(Coffee[] obj,int n) {
	for(int i=0;i<n;i++) {
		System.out.println(obj[i].name+" ");
		System.out.println(obj[i].mobileno+" ");
		System.out.println(obj[i].rating+" ");
	}
}
void averageFeedback(Coffee[] obj,int n) {
	double sum=0;
	for(int i=0;i<n;i++) {
		sum=sum+obj[i].rating;
	}
	double avgrating=sum/n;
	System.out.println("Average Feedbackis"+avgrating);
}
void maxmin(Coffee[]obj,int n) {
	double maxterm=obj[0].rating;
	double minterm=obj[0].rating;
	for(int i=0;i<n;i++) {
		if(minterm>obj[i].rating) {
			minterm=obj[i].rating;
		}
		if(maxterm<obj[i].rating) {
			maxterm=obj[i].rating;
		}
	}
	for(int i=0;i<n;i++) {
		if(minterm==obj[i].rating) {
			System.out.println("Minimum rating is"+obj[i].rating);
		}
		if(maxterm==obj[i].rating) {
			System.out.println("Maximum rating is"+obj[i].rating);
		}
	}
}

}
