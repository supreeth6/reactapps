package captwo;

public class Software {
private int id;
private long lisno;
private String name;
private int cost;
public Software() {
	super();
	// TODO Auto-generated constructor stub
}
public Software(int id, long lisno, String name, int cost) {
	super();
	this.id = id;
	this.lisno = lisno;
	this.name = name;
	this.cost = cost;
}
@Override
public String toString() {
	return "Software [id=" + id + ", lisno=" + lisno + ", name=" + name + ", cost=" + cost + "]";
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public long getLisno() {
	return lisno;
}
public void setLisno(long lisno) {
	this.lisno = lisno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}
}
