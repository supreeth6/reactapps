package captwo;

import java.lang.reflect.Array;
import java.util.Scanner;

public class Onddtotwod {
	static Scanner scan = new Scanner(System.in);

	public static void main(String args[]) {
		//int row = 0;
		//int col = 0;
		String[][] strarray = null;

		boolean bool = true;
		do {
			System.out.println("1.take the 1d array and convert into 2d array");
			System.out.println("2.count the number of characters in 2d array");
			System.out.println("3.move each row one step down and last one at the top");

			System.out.println("Enter your choice");
			int choice = scan.nextInt();

			switch (choice) {
			case 1:
				twodconversion();

				break;

			case 2:
				int c = countchar(strarray);
				System.out.println(c);
				break;
			case 3:
				moverows(strarray);
				break;
			case 4:
				System.exit(1);
				break;
			default:
				System.out.println("enter the correct choice");
				break;
			}
		} while (bool);
	}

	public static void twodconversion() {
		/*
		 * System.out.println("enter the number of ond d array"); int n=scan.nextInt();
		 * System.out.println("enter the size of one d array"); int m=scan.nextInt();
		 * //String[] arr1= new String[m]; String [][]arr2=new String [n][m]; int k=0;
		 * for(int i=0;i<arr2.length-1;i++) { for(int j=0;j<arr2.length-1;j++ ) {
		 * arr2[i][j]=arr1[k]; } } for(int i=0;i<arr2.length-1;i++) { for(int
		 * j=0;j<arr2.length-1;j++ ) {
		 * 
		 * 
		 * System.out.println("the two d array is"+arr2[i][j] ); } }
		 */
		System.out.println("enter the row");
		int row = scan.nextInt();
		System.out.println("enter the column");
		int col = scan.nextInt();
		String[][] strarray = new String[row][col];
		System.out.println("Enter the string array");
		scan.nextLine();
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				strarray[i][j] = scan.nextLine();
			}
		}
		System.out.println("Input Array ");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.println("the inputed array is" + strarray[i][j]);
			}
		}

	}

	public static int countchar(String[][] strarray) {
		int count = 0;
		for (int i = 0; i < strarray.length-1; i++) {
			for (int j = 0; j < strarray.length-1; j++) {
				String temp = strarray[i][j];
				for (int k = 0; k < temp.length(); k++) {
					if (temp.charAt(k) != ' ')
						count++;
				}
			}
		}
		return count;
	}

	public static void moverows(String[][] strarray) {
		String temp[][] = null;
		for (int i = 0; i < strarray.length-1; i++) {
			for (int j = 0; j < strarray.length-1; j++) {
				strarray[i][j] = strarray[i + 1][j];

			}
		}

		for (int i = 0; i < strarray.length-1; i++) {
			for (int j = 0; j < strarray.length-1; j++) {
				System.out.println(strarray[i][j]);
			}

		}
	}
}
