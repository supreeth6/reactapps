package captwo;

import java.util.Scanner;

public class StudentMain {
	static Scanner scan = new Scanner(System.in);

	public static void main(String args[]) {
		// Scanner scan=new Scanner(System.in);
		Students[] result = null;
		System.out.println("Enter the number of students");
		int n = scan.nextInt();
		Students[] s = new Students[n];
		for (int i = 0; i < s.length; i++) {
			System.out.println("Enter the name");
			String name = scan.nextLine();
			scan.nextLine();
			System.out.println("enter the roll number");
			int rollno = scan.nextInt();
			System.out.println("enter the gender");
			char gender = scan.next().charAt(0);
			boolean flag=true;
			while(flag) {
			System.out.println("enter the rank");
			int rank = scan.nextInt();
			//boolean flag=true;
			//while(flag) {
			if(1<=rank && rank<=s.length) {
			s[i] = new Students(name, rollno, gender, rank);
			flag=false;
			}
			else {
				flag=true;
			}
			}
		}
		System.out.println("students details are __");
		for (int i = 0; i < n; i++) {
			System.out.println(s[i]);
		}
		do {
			System.out.println("1.sex ratio among the students");
			System.out.println("2.sort the students based on rank");
			System.out.println("3.update the rank of student for a particular roll no");
			System.out.println("enter the choice");
			int choice = scan.nextInt();

			switch (choice) {
			case 1:
				sexratio(s);
				break;

			case 2:
				result = sort(s);
				System.out.println("sorted based on rank");
				for (int i = 0; i < s.length; i++) {
					System.out.println(result[i]);
				}
				break;

			case 3:
				uprl(s);
				break;

			}

		} while (true);
	}

	private static Students[] sort(Students[] s) {
		for (int i = 0; i < s.length; i++) {
			int item = s[i].getRank();
			Students temp = s[i];
			int j = i - 1;
			while (j > -1 && s[i].getRank() > item) {
				s[j + 1] = s[j];
				j--;
			}

			s[j + 1] = temp;
		}
		return s;
	}

	private static Students[] uprl(Students[] s) {
		System.out.println("enter the rollno of student for whom the rank should be updated ");
		int rn = scan.nextInt();
		System.out.println("enter the rank to be updated");
		int rk=scan.nextInt();
		for (int i = 0; i < s.length; i++) {
			boolean flag = true;
			while (flag) {
				if (s[i].getRollno() == rn) {
					s[i].setRank(rk);
					flag = false;
				} else {
					flag = true;
				}
			}
		}
		return s;
	}

	private static Students[] sexratio(Students[] s) {
		int malecount = 0;
		int femalecount = 0;

		for (int i = 0; i < s.length; i++) {
			if (s[i].getGender() == 'M' || s[i].getGender() == 'm') {
				malecount++;
			} else {
				femalecount++;
			}

			int mratio = malecount / s.length;
			int fratio = femalecount / s.length;
			System.out.println("Ratio of male and female is" + mratio + ":" + fratio);
		}
		return s;
	}
}
