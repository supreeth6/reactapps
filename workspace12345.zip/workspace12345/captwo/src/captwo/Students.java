package captwo;

public class Students {
	private String name;
	private int rollno;
	private char gender;
	private int rank;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Students(String name, int rollno, char gender, int rank) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.gender = gender;
		this.rank = rank;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Students [name=" + name + ", rollno=" + rollno + ", gender=" + gender + ", rank=" + rank + "]";
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}

}
