package captwo;

import java.util.Scanner;

public class Codingchallange {

	static Scanner scan = new Scanner(System.in);

	public static void main(String args[]) {

		System.out.println("enter the row");
		int row = scan.nextInt();
		System.out.println("enter the column");
		int col = scan.nextInt();
		String[][] strarray = new String[row][col];
		System.out.println("Enter the string array");
		scan.nextLine();
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				strarray[i][j] = scan.nextLine();
			}
		}

		boolean bool = true;
		do {
			System.out.println("Press 1 for taking two d string matrix");
			System.out.println("Press 2 for replacing vowels with %");
			System.out.println("Press 3 for counting the number of spaces");
			System.out.println("Press 4 for making lower case to upper case and vice versa");
			System.out.println("Enter your choice");
			int choice = scan.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Input Array ");
				for (int i = 0; i < strarray.length; i++) {
					for (int j = 0; j < strarray.length; j++) {
						System.out.println(strarray[i][j]);
					}
				}
				break;

			case 2: String[][] res2=new String[row][col];
				res2 = replacevowels(strarray, row, col);
				for (int i = 0; i < row; i++) 
				{
					for (int j = 0; j < col; j++) 
					{
						System.out.print(res2[i][j]+"  ");
					}
					System.out.println();
				}
				break;
			case 3:
				int res3 = countspaces(strarray,row,col);
				System.out.println(res3);
				break;
			case 4:String[][] res9=new String[row][col];
				res9= lowToUp(strarray, row, col);
				for (int i = 0; i < row; i++) 
				{
					for (int j = 0; j < col; j++) 
					{
						System.out.print(res9[i][j]+"  ");
					}
					System.out.println();
				}
				break;
			default:
				System.out.println("enter the correct choice");
				break;
			}
		} while (bool);
	}

	private static String[][] lowToUp(String[][] strarray, int row, int col) 
	{
		String[][] resarray = new String[row][col];
		
		int i,j;
		String str="";
		for (i = 0; i < row; i++) 
		{
			
			for (j = 0; j < col; j++) 
			{
				String temp = strarray[i][j];
				for (int k = 0; k < temp.length(); k++) 
				{
					if(temp.charAt(k)>=65 && temp.charAt(k)<=90)
						str=str+(char)(temp.charAt(k)+32);
					else
						str+=(char)(temp.charAt(k)-32);	
				}
				resarray[i][j]=str;
				
				str="";
			}
			
		}
		return resarray;
	}

	private static int countspaces(String[][] strarray, int row, int col) 
	{
		int count=0;
		for (int i = 0; i < row; i++) 
		{
			for (int j = 0; j < col; j++) 
			{
				String temp = strarray[i][j];
				for (int k = 0; k < temp.length(); k++) 
				{
					if(temp.charAt(k)==' ')
						count++;		
				}
			}
		}
		return count;
	}

	
	public static String[][] replacevowels(String[][] str, int row, int col) {
		String[][] resarray = new String[row][col];

		String strnew = "";
		for (int i = 0; i < row; i++) 
		{
			for (int j = 0; j < col; j++) 
			{
				String temp = str[i][j];
				for (int k = 0; k < temp.length(); k++) 
				{
					if (temp.charAt(k) == 'a' || temp.charAt(k) == 'e' || temp.charAt(k) == 'i' || temp.charAt(k) == 'o'
							|| temp.charAt(k) == 'u' || temp.charAt(k) == 'A' || temp.charAt(k) == 'E' || temp.charAt(k) == 'I'
							|| temp.charAt(k) == 'O' || temp.charAt(k) == 'U') 
					{
						strnew += '%';
					}
					else 
					{
						strnew += temp.charAt(k);
					}
				}
				
				resarray[i][j] = strnew;
				
				strnew="";

			}
		}

		return resarray;
	}

	
}
