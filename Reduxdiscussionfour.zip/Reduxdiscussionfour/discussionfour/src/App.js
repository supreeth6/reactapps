// import React, { Component } from "react";
// import { connect } from "react-redux";
// import { thunk_action_creator } from "./actions/fetchAction";
// import Users from "./Users";
// import AppBar from "@material-ui/core/AppBar";
// import Toolbar from "@material-ui/core/Toolbar";
// import Typography from "@material-ui/core/Typography";

// class App extends Component {
// 	handleSubmit = (e) => {
// 		e.preventDefault();
// 		const username = this.getUsername.value;
// 		this.props.dispatch(thunk_action_creator(username));
// 		this.getUsername.value = "";
// 	};
// 	render() {
// 		console.log(this.props.data);
// 		return (
// 			<div>
// 				<AppBar position="static">Enter the github username</AppBar>
// 				<form onSubmit={this.handleSubmit}>
// 					<input
// 						type="text"
// 						required
// 						ref={(input) => (this.getUsername = input)}
// 					/>
// 					<button>Submit</button>
// 				</form>
// 				<Users user={this.props.data} />
// 			</div>
// 		);
// 	}
// }

// const mapStateToProps = (state) => {
// 	return {
// 		data: state,
// 	};
// };
// export default connect(mapStateToProps)(App);
import React, { Component } from "react";
import { connect } from "react-redux";
import UserInfo from "./Users";
import { thunk_action_creator } from "./actions/fetchAction";

class App extends Component {
	handleSubmit = (e) => {
		e.preventDefault();
		const username = this.getUsername.value;
		this.props.dispatch(thunk_action_creator(username));
		this.getUsername.value = " ";
		console.log(username);
	};

	render() {
		console.log(this.props.data);
		return (
			<div>
				<form onSubmit={this.handleSubmit}>
					<h2>Enter the Username</h2>
					<input
						type="text"
						placeholder="Enter  Username"
						required
						ref={(input) => (this.getUsername = input)}
					/>
					<button>Submit</button>
				</form>
				{/* {this.props.data.isFetching ? <h3>Loading ...</h3> : null}
				{this.props.data.isError ? <h3>No such User exists.</h3> : null} */}
				{Object.keys(this.props.data.userData).length > 0 ? (
					<UserInfo user={this.props.data.userData} />
				) : null}
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	return {
		data: state,
	};
};
export default connect(mapStateToProps)(App);
