import store from "../store";
export const receive_post = (post) => {
	return {
		type: "FETCHED_USER",
		data: post,
	};
};

export const thunk_action_creator = () => {
	// console.log(detectedstate);

	// store.dispatch(fetch_post());
	return function (dispatch, getState) {
		return fetch(`https://api.github.com/search/users?q=rakesh`)
			.then((data) => data.json())
			.then((data) => {
				if (data.message === "Not Found") {
					throw new Error("No such data found!!");
				} else dispatch(receive_post(data));
			});
		// .catch((err) => dispatch(receive_error()));
	};
};
