const initialState = {
	userData: {},
};

const asyncReducer = (state = initialState, action) => {
	console.log(action);
	switch (action.type) {
		case "FETCHED_USER":
			return Object.assign({}, state, {
				userData: action.data,
			});
			return state;
	}
};

export default asyncReducer;
