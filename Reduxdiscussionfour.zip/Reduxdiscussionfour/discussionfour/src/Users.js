// import React, { component } from "react";

// const Users = (props) => {
// 	return (
// 		<div>
// 			<div>
// 				<img src={props.user} />
// 			</div>
// 			<div>
// 				<h1>{props.user}</h1>
// 			</div>
// 		</div>
// 	);
// };
// export default Users;
import React, { component } from "react";
const UserInfo = (props) => {
	return (
		<div>
			<div>
				<img src={props.user.avatar_url} alt="avatar" width="250px" />
			</div>
			<div>
				<h1>{props.user.name}</h1>
				<p>
					<strong>Bio:</strong>
					{props.user.bio}
				</p>
				<p>
					<strong>Location:</strong>
					{props.user.location}
				</p>
				<p>
					<strong>Followers:</strong>
					{props.user.followers}
				</p>
				<p>
					<strong>Following:</strong>
					{props.user.following}
				</p>
			</div>
		</div>
	);
};

export default UserInfo;
