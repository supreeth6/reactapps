const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cart');
const authMiddleware = require('../middlewares/auth');

router
  .get('/', authMiddleware.verifyUser, cartController.getCart)
  .post('/', authMiddleware.verifyUser, cartController.addCart)
  .put('/', authMiddleware.verifyUser, cartController.removeCart);
module.exports = router;

