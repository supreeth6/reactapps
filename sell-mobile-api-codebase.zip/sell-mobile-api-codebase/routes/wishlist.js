const express = require('express');
const router = express.Router();
const wishListController = require('../controllers/wishlist');
const authMiddleware = require('../middlewares/auth');

router
  .get('/', authMiddleware.verifyUser, wishListController.getWishLists)
  .post('/', authMiddleware.verifyUser, wishListController.addWishList)
  .put('/', authMiddleware.verifyUser, wishListController.removeWishlist);

module.exports = router;
