const express = require("express");
const router = express.Router();
const authController = require("../controllers/auth");
const passport = require("passport");
const authMiddleware = require("../middlewares/auth");

router
  .get(
    "/google",
    passport.authenticate("google", {
      scope: [
        "profile",
        "email"
      ],
      session: false
    })
  )
  .get(
    "/google/callback",
    passport.authenticate("google", {
      session: false
    }),
    authController.googleCallback
  )
  .get("/logout", authController.logout)
  .get("/verify", authMiddleware.authorize);

module.exports = router;
