const express = require('express');
const router = express.Router();
const mobileController = require("../controllers/seller")
// const mobile=require("../models/Mobile")

router

    //get all mobiles of a particular seller
    .get('/:sellerId', mobileController.getcurrentmobile)

    //post the mobile details
    .post('/mobiles', mobileController.postmymobile)
    
    //delete the mobiles posted 
    .put('/delete', mobileController.Deletemymobile);



module.exports = router;