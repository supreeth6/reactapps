const express = require("express");
const router = express.Router();
const mobileController = require("../controllers/mobiles")
const Mobile = require("../models/Mobile"); 

router
  // get specific mobile with id
  .get("/:id", mobileController.getMobile)
  //get all mobiles
  .get("/", mobileController.getAllMobiles)
  //update mobiles with buyerId, buyerName and isBought
  .put("/bought", mobileController.updateMobiles)

module.exports = router;
