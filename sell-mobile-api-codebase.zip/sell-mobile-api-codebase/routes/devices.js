const express = require('express');
const router = express.Router();

const deviceController = require('../controllers/devices')

router
    //get all possible search terms
    .get('/searchTerm', deviceController.getSearchTerm)
    //get all brands from database
    .get('/brands', deviceController.getBrands)
    //get all models of a particular brand from database
    .get('/:brand/', deviceController.getModels)
    //get all specification for a particular model of a particular brand from database
    .get('/:brand/:model/', deviceController.getDesc)
    

module.exports = router;