const express = require('express');
const router = express.Router();
const Mobile = require("../models/Mobile");
router
.post("/reject",(req,res)=>{
  Mobile.updateOne({_id:req.body.payload},{isRejected:true},(err,mobile)=>res.send(
    "deleted"
  ))
})
module.exports = router;
