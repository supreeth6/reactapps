const express = require("express");
const router = express();
const usersRouter = require("./users");
const sellerRouter = require("./seller");
const adminRouter = require("./admin");
const authRouter = require("./auth");
const devicesRouter = require("./devices");
const mobileRouter = require("./mobile");
const searchController = require("../controllers/search");
const mobileController = require("../controllers/mobiles");
const cityController = require('../controllers/cities');
const wishlistRouter = require('./wishlist');
const cartRouter = require('./cartItem');
const imagesRouter = require('./images')
/* GET home page. */
//authentication router
router
    .use("/auth", authRouter)
    .use("/users", usersRouter)
    .use("/seller", sellerRouter)
    .use("/admin", adminRouter)
    .use("/devices", devicesRouter)
    .use("/mobile", mobileRouter)
    .use("/wishlist", wishlistRouter)
    .use("/cart", cartRouter)
    .use("/images", imagesRouter)
router
    .post("/search", searchController.search)
    .post("/search-by-model", searchController.searchmodel)
    .post("/search-by-brand", searchController.searchbrand)
    .get("/cities", cityController.getCities)

module.exports = router;
