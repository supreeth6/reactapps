const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  googleId: String,
  type: {type:String,default:"customer"},
  photo:String,
  name: String,
  email: String
});

module.exports = mongoose.model("user", UserSchema);
