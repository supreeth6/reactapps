const mongoose = require("mongoose");

const ImagesSchema = new mongoose.Schema({
    url: String,
});

module.exports = mongoose.model("Image", ImagesSchema);