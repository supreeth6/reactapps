const mongoose = require("mongoose");

const MobileSchema = new mongoose.Schema({
    brandname: String,
    model: String,
    location: {},
    price: Number,
    camera: String,
    charging: String,
    switching: String,
    condition: String,
    sellerId: String,
    buyerId: String,
    buyerName: String,
    sellerName: String,
    isBought: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    isRejected: { type: Boolean, default: false },
    DoO: String,
    transId: String
});

module.exports = mongoose.model("Mobile", MobileSchema);