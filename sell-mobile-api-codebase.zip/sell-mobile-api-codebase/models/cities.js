const mongoose = require("mongoose");

const CitiesSchema = new mongoose.Schema({
    city: String,
    lat: String,
    lng: String,
    admin: String
});

module.exports = mongoose.model("cities", CitiesSchema);