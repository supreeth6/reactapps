const mongoose = require("mongoose");

const CartSchema = new mongoose.Schema({
    mobiles: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Mobile'
      }]
});
module.exports = mongoose.model("cart", CartSchema);