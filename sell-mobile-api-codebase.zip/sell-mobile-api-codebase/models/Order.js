const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
    mobileId: String,
    sellerId: String,
    buyerId: String,
    date: Date
});

module.exports = mongoose.model("order", OrderSchema);
