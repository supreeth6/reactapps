const mongoose = require("mongoose");

const DeviceSchema = new mongoose.Schema({
    brand: String,
    model: String,
    network_technology: { type: String, default: "-" },
    launch_announced: { type: String, default: "-" },
    launch_status: { type: String, default: "-" },
    body_dimensions: { type: String, default: "-" },
    body_weight: { type: String, default: "-" },
    body_sim: { type: String, default: "-" },
    display_size: { type: String, default: "-" },
    display_resolution: { type: String, default: "-" },
    platform_os: { type: String, default: "-" },
    memory_card_slot: { type: String, default: "-" },
    memory_internal: { type: String, default: "-" },
    main_camera_single: { type: String, default: "-" },
    selfie_camera_single: { type: String, default: "-" },
    battery: { type: String, default: "-" }
});

module.exports = mongoose.model("device", DeviceSchema);
