const mongoose = require("mongoose");

var SearchSchema = new mongoose.Schema({
    mobile_id: String,
    DeviceName:String,
    Brand:String
});

module.exports = mongoose.model("search", SearchSchema);