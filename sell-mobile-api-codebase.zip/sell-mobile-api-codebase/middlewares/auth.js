const jwt = require("jsonwebtoken");
const authConfig = require("../config/auth");
const User = require("../models/User");

module.exports = {
  // to authorize user
  authorize: (req, res, next) => {
    // check authorization headers
    if (req.headers.authorization) {
      const token = req.headers.authorization.split(" ");
      if (token[1] != "null") {
        // verify the token found in header
        jwt.verify(token[1], authConfig.jwtAuth.secretKey, (err, data) => {
          if (err) {
            console.log("invalid token")
            res.sendStatus(403);
          } else {
            User.find({ googleId: data.id }, (err, user) => {
              if (err){ console.log("no user found");res.sendStatus(403) }
              else res.json(user);
            });
          }
        });
      } else res.sendStatus(403);
    }
    //  if no authorization header send 403 forbidden
    else res.sendStatus(403);
  },

  verifyUser: (req, res, next) => {
    // check authorization headers
    if (req.headers.authorization) {
      const token = req.headers.authorization.split(" ");
      if (token[1] != "null") {
        // verify the token found in header
        jwt.verify(token[1], authConfig.jwtAuth.secretKey, (err, data) => {
          if (err) {
            console.log("invalid token")
            res.sendStatus(403);
          } else {
            User.find({ googleId: data.id }, (err, user) => {
              if (err){ console.log("no user found");res.sendStatus(403) }
              else {
                req.body.user=user[0];
                next();
              }
            });
          }
        });
      } else res.sendStatus(403);
    }
    //  if no authorization header send 403 forbidden
    else res.sendStatus(403);
  },

};
