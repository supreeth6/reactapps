const jwt = require("jsonwebtoken");
const Auth = require("../config/auth");

module.exports = {
  // google Callback controller
  googleCallback: (req, res, next) => {
    const token = jwt.sign(
      { id: req.user.googleId, accessToken: req.user.accessToken },
      Auth.jwtAuth.secretKey,
      {
        expiresIn: "1d"
      }
    );
    res.redirect(Auth.googleAuth.redirectURL + token);
  },
  // logout controller
  logout: (req, res, next) => {
    req.logOut();
    res.send("logout success...");
  },
  // verify controller
  verify: (req, res, next) => {
    res.json(req.body);
  }
};
