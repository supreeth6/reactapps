const Cart = require('../models/Cart');

module.exports = {
  getCart: (req, res) => {
    Cart.findById(req.body.user._id)
      .populate({ path: 'mobiles', match: { isRejected: false, isDeleted: false } })
      .exec((err, mobiles) => {
        res.json(mobiles);
      });
  },
  addCart: (req, res) => {
    Cart.updateOne(
      { _id: req.body.user._id },
      { $addToSet: { mobiles: req.body.mobile_id } },
      { upsert: true },
      (err, mobile) => {
        res.status(200).send(mobile);
      },
    );
  },
  removeCart: (req, res) => {
    Cart.updateOne(
      { _id: req.body.user._id },
      { $pull: { mobiles: req.body.mobile_id } },
      (err, mobile) => {
        res.status(200).send(mobile);
      },
    );
  },
};
