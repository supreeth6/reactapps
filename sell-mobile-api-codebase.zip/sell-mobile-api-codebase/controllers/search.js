const mobile = require('../models/Mobile');

module.exports = {
  search: (req, res) => {
    let a = req.body.term.split(/ (.+)/);
    mobile
      .find({
        model: a[1],
      })
      .then((mymobile) => res.json(mymobile))
      .catch((e) => console.error(e));
  },
  searchmodel: (req, res) => {
    console.log(req.body.term);
    mobile
      .find({
        model: req.body.term,
        isBought: false,
        isDeleted: false,
        isRejected: false,
      })
      .then((mymobile) => res.json(mymobile))
      .catch((e) => console.error(e));
  },
  searchbrand: (req, res) => {
    mobile
      .find({
        brandname: req.body.term,
        isBought: false,
        isDeleted: false,
        isRejected: false,
      })
      .then((mymobile) => res.json(mymobile))
      .catch((e) => console.error(e));
  },
};
