const cities = require("../models/Cities");

module.exports = {
    getCities: (req, res) => {
        cities.find({}, (err, cities) => {
            if (err) res.send(err);
            else res.json(cities);
        });
    }
}