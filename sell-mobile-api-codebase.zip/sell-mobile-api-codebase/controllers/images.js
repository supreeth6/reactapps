const image = require("../models/Images");

module.exports = {
    getImage: (req, res) => {
        image.findById(req.params.mobileId, (err, images) => {
            if (err) res.send(err);
            else res.send(images.url);
        });
    },
}