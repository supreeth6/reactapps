const seller = require("../models/User");

module.exports = {
  getSeller: (req, res) => {
    seller.findById(req.params.sellerId, (err, seller) => {
      if (err) throw err;
      res.json({user: seller})
    }); 
  }
};
