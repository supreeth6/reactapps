const seller = require('../models/Mobile');
const images = require('../models/Images');
module.exports = {
  getcurrentmobile: (req, res) => {
    seller.find({ sellerId: req.params.sellerId }, (err, mobile) => {
      if (err) {
        res.send(err);
      } else {
        res.json(mobile);
      }
    });
  },
  postmymobile: (req, res) => {
    const mobiles = new seller(req.body.payload.mobileData);

    const photo = req.body.payload.mobileData.photo;
    mobiles
      .save()
      .then((mobile) => {
        const image = new images({ _id: mobile._id, url: photo });
        image
          .save()
          .then(() => {
            res.json(mobile);
          })
          .catch((err) => {
            res.send(404);
          });
      })
      .catch((err) => {
        res.status(404).send('Could not post');
      });
  },

  Deletemymobile: (req, res) => {
    seller.updateOne(
      { _id: req.body.mobile },
      { isDeleted: true },
      (err, mobile) => {
        if (err) throw err;
        res.json({ mobile });
      },
    );
  },

};
