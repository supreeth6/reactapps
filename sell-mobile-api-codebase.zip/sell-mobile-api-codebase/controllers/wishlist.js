const WishList = require('../models/Wishlist');

module.exports = {
  getWishLists: (req, res) => {
      console.log(req.body)
    WishList.findById(req.body.user._id)
      .populate({path:'mobiles',match:{isRejected:false, isDeleted: false}})
      .exec((err, mobiles) => {
        res.json(mobiles);
      });
  },
  addWishList: (req, res) => {
    WishList.updateOne(
      { _id: req.body.user._id },
      { $addToSet: { mobiles: req.body.mobile_id } },
      { upsert: true },
      (err, mobile) => {
        res.status(200).json(mobile);
      },
    );
  },
  removeWishlist: (req, res) => {
    WishList.updateOne(
      { _id: req.body.user._id },
      { $pull: { mobiles: req.body.mobile_id } },
      (err, mobile) => {
        res.status(200).json(mobile);
      },
    );
  },
};
