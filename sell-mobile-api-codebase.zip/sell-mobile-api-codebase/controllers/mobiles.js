const mobile = require("../models/Mobile");

module.exports = {
    getAllMobiles: (req, res) => {
        mobile.find({ isDeleted: false }, (err, mobiles) => {
            if (err) res.send(err);
            else res.json(mobiles);
        });
    },
    getMobile: (req, res) => {
        mobile.findById(req.params.id, (err, mobile) => {
            if (err) res.send(err);
            else res.json(mobile);
        })
    },
    updateMobiles: (req, res) => {
        mobile.updateOne({ _id: req.body.id }, { isBought: true, buyerId: req.body.buyerId, buyerName: req.body.buyerName, DoO: req.body.DoO, transId: req.body.transId },
            (err, added) => {
                if (err) throw err;
                res.json({ changes: added })
            })
    },
}