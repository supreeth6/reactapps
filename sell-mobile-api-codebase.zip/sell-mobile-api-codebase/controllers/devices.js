const device = require('../models/Devices');
module.exports = {
  getBrands: (req, res) => {
    device.distinct('brand', (err, brands) => {
      if (err) throw err;
      res.json({ Brands: brands });
    });
  },
  getModels: (req, res) => {
    const brand = req.params.brand;
    const models = [];
    device.find({ brand: brand }, (err, mobiles) => {
      if (err) throw err;
      mobiles.map((mob) => {
        models.push(mob.model);
      });
      res.json({ Models: models });
    });
  },
  getDesc: (req, res) => {
    const brand = req.params.brand;
    const model = req.params.model;
    device.find({ brand: brand, model: model }, (err, desc) => {
      if (err) throw err;
      res.json(desc[0]);
    });
  },
  getSearchTerm: (req, res) => {
    let data = [];
    device.find(async (err, mobiles) => {
      if (err) throw err;
      await mobiles.map((item) => data.push(`${item.brand} ${item.model}`));
      res.send(data);
    });
  },
};
