module.exports = {
  googleAuth: {
    clientID:
      "893248251713-plk4r43cvb8sna7oa3gr22856tgmqsk7.apps.googleusercontent.com",
    clientSecret: "Q7NPtS3Ems1zSQZ7Dp0BeI4U",
    // callbackURL: "http://localhost:3000/api/auth/google/callback",
    callbackURL: "https://sell-mobile-api.azurewebsites.net/api/auth/google/callback",
    // redirectURL: "http://localhost:3001/login/",
    redirectURL: "https://sell-mobile.azurewebsites.net/login/"
  },
  jwtAuth: {
    secretKey: "teamOIG"
  }
};

