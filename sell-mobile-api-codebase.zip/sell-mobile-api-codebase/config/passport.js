const GoogleStrategy = require("passport-google-oauth2").Strategy;
const User = require("../models/User")
const authConfig = require("./auth");
const passport = require("passport");

app.use(passport.initialize());
passport.use(
  new GoogleStrategy(
    {
      clientID: authConfig.googleAuth.clientID,
      clientSecret: authConfig.googleAuth.clientSecret,
      callbackURL: authConfig.googleAuth.callbackURL
    },
    function (accessToken, refreshToken, profile, done) {
      User.find({ googleId: profile.id }, (err, user) => {
        if (user.length) {
          return done(err, { accessToken, googleId: profile.id });
        } else {
          const user = new User({ googleId: profile.id, name: profile.displayName ,
            photo:profile.picture,
            email: profile.email  })
          user.save(
            (err, user) => {
              return done(err, { accessToken, googleId: profile.id });
            }
          );
        }
      });
    }
  )
);
