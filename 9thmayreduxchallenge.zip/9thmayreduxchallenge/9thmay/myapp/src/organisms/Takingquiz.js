import React, { Component } from 'react'

export default class Takingquiz extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
