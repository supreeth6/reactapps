
export const addaction = (details) => {
    
    return {
        type: "ADD",
        details:details
    }
}

// export const addoption = (obj) => {
    
//     return {
//         type: "ADD",
//         obj:obj
//     }
// }

export const addQuestion = (question) =>( {
      
    }
}