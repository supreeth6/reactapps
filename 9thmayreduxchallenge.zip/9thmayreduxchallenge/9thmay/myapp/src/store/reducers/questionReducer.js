// const initialState={
//     initialdetails:[]
//   }
//   const reducer=(state=initialState, action)=>{
//       switch(action.type){
//           case "ADD":
//               return{
//                   ...state,
//                   initialdetails:[...state.initialdetails,action.details],
                
//               }
//               case "ERROR":{
//                   return{
//                       ...state,
//                       error:action.set
//                   }
//               }
//               default: return state;
//       }
//   }
//   export default reducer;










  import * as actionTypes from "../actions/actionTypes";
//import { addQuestionUtil, addAnswerUtil } from '../utils'

const initialState = {
    quiz: [],

};

const questionReducer = (state = initialState, action) => {
    console.log(action);
    switch (action.type) {
        case actionTypes.ADD_QUESTION:
            console.log(action)
            return {
                ...state,
                // quiz: addQuestionUtil(state.quiz, action.question)
                quiz:[...state.quiz,action.question]
            };
        default:
            return state;
    }
};

export default questionReducer;