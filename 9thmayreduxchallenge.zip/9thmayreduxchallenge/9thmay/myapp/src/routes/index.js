// import React, { Component } from 'react'
// import {Switch,Route} from 'react-router-dom'
// import Adding from "../organisms/adding";
// import Home from "../organisms/Home";
// import Takingquiz from "../organisms/Takingquiz";
// import Radio from "../organisms/Radio"
//  export default class Routes extends Component {
//     render() {
//         return (
//             <div>
//                  <Switch>
//                     <Route exact path="/" component={Home}></Route>
//                     <Route exact path="/add" component={Adding} ></Route>
//                     <Route exact path="/addoption" component={Radio} ></Route>
//                     <Route exact path="/takingquiz" component={Takingquiz} ></Route>
//                 </Switch>
//             </div>
//         )
//     }
// }










import React from 'react'
import { Route, Switch } from 'react-router-dom';
import AddQuestionsPage from '../pages/AddQuestionsPage/index';
import QuizPage from '../pages/QuizPage/index'

const Routes = (props) => {
    return (
        <>
            <Switch>
                <Route
                    path="/"
                    component={(props) => <AddQuestionsPage />}
                    exact={true}
                />
                <Route
                    path="/quiz"
                    component={(props) => <QuizPage />}
                    exact={true}
                />
            </Switch>
        </>
    )

}


export default Routes