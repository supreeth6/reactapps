import React, { Component } from 'react'
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import {Form,Row,Col,Container} from 'react-bootstrap'
import NativeSelect from '@material-ui/core/NativeSelect';
import InputBase from '@material-ui/core/InputBase';
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import {fetchbitcoinprice,fetchbitcoinchartprice} from "../Reducers/actions"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
const data = [
    {
      name: 'Page A',
      uv: 4000,
      pv: 2400,
      amt: 2400,
    },
    {
      name: 'Page B',
      uv: 3000,
      pv: 1398,
      amt: 2210,
    },
    {
      name: 'Page C',
      uv: 2000,
      pv: 9800,
      amt: 2290,
    },
    {
      name: 'Page D',
      uv: 2780,
      pv: 3908,
      amt: 2000,
    },
    {
      name: 'Page E',
      uv: 1890,
      pv: 4800,
      amt: 2181,
    },
    {
      name: 'Page F',
      uv: 2390,
      pv: 3800,
      amt: 2500,
    },
    {
      name: 'Page G',
      uv: 3490,
      pv: 4300,
      amt: 2100,
    },
  ];
const bpi={"2013-09-01":82.6899,"2013-09-02":81.8975,"2013-09-03":82.0227,"2013-09-04":77.1907,"2013-09-05":77.2935,"2013-09-06":74.4607,"2013-09-07":76.153,"2013-09-08":74.5782,"2013-09-09":76.4907,"2013-09-10":77.2445}
 class Bitcoingraph extends Component {
    componentDidMount() {
        let { dispatch } = this.props;
    
        dispatch(fetchbitcoinprice());
        // console.log(result,"this is result")
      }
      constructor(props) {
        super(props);
        this.state = {
            detail:{
          pricechange:"",
         
            },
            chartdata:[]
         };
      }
      handleChangeprice = (e) => {
        let name = e.target.name;
        let value = e.target.value;
        let keys=e.target.id;
        console.log(this.props.states[value].code,"names");
        let { dispatch } = this.props;
    
        dispatch(fetchbitcoinchartprice(this.props.states[value].code));
          this.setState({
          detail: {
            ...this.state.detail,
            [name]: this.props.states[value].rate,
            
          },
          ...this.state.chartdata=
          this.props.chartstates

          
        });
       
       
      };
    render() {
      // let result;
// let finalres=[];
//       if(this.props.chartstates){

//       let chartdata=this.props?.chartstates;
//       console.log(chartdata,"chartstate");
//       let temp=[];
//        let newtemp=Object?.keys(chartdata)?.map(key=>({id:key, value: bpi[key]}));
//       // let temp;
//       temp.push(newtemp);
//       finalres=temp
//        console.log(finalres,"redfj")
//       }
let res
if(this.state.chartdata){
 res=Object?.keys(this.state.chartdata)?.map(key=>({id:key, value: bpi[key]}));
 console.log(res)
}
console.log(res)
        return (
            <div>
                <Grid container spacing={3}>
       
        <Grid item xs={6}>
        1 Bitcoin Equals
              <br/>
              <Form.Group >
                  {/* <Form.Label  size="lg">Method Type</Form.Label> */}
                  <Form.Control
                    size="lg"
                    as="select"
                    // size="lg"
                    name="pricechange"
                    
                    // value={this.props.states?.USD?.rate}
                    onChange={this.handleChangeprice}
                  >
                    {/* {this.props.states?.map(p => {
    return (
      <option key={p.id}>{p.name}</option>
    )
  })} */}
                   
                        <option  id={this.props.states?.USD?.code} value={"USD"} >{this.props.states?.USD?.description}</option>
                        <option id={this.props.states?.GBP?.code} value={"GBP"} >{this.props.states?.GBP?.description}</option>
                        <option id={this.props.states?.EUR?.code} value={"EUR"} >{this.props.states?.EUR?.description}</option>

                  </Form.Control>
                </Form.Group>
                {this.state.detail.pricechange}
                {this.state.detail.code}
        </Grid>
        <Grid item xs={6}>
          {/* <ResponsiveContainer width="100%" height="100%"> */}
        <LineChart
          width={500}
          height={300}
          data={res}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          {/* <CartesianGrid strokeDasharray="3 3" /> */}
          <XAxis dataKey="id" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} />
          {/* <Line type="monotone" dataKey="name" stroke="#82ca9d" /> */}
        </LineChart>
      {/* </ResponsiveContainer> */}
        </Grid>
       
      </Grid>
            </div>
        )
    }
}
function mapStateToProps(state) {
 console.log("this is state",state.chartprice.bpi)
    return {
      states: state?.price?.bpi,
      chartstates:state?.chartprice?.bpi
    };
  }
  
  export default withRouter(connect(mapStateToProps)(Bitcoingraph));
