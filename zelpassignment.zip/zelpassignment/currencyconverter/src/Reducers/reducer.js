import {BITCOIN_PRICE_REQUEST,BITCOIN_PRICE_CHART_REQUEST} from "./action-types"

const initialState = {
    
    price: [],
    chartprice:[]
  };

const Reducer = (state = initialState, action) => {
    switch (action.type) {
        case BITCOIN_PRICE_REQUEST: {
            console.log(action);
            return {
              ...state,
              price: action.payload,
            };
          }
          case BITCOIN_PRICE_CHART_REQUEST: {
            console.log(action);
            return {
              ...state,
              chartprice: action.payload,
            };
          }
  
      default:
        return state;
    }
  };
  export default Reducer;
  