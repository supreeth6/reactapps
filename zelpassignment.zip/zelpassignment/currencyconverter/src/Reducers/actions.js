import axios from "axios";
import {BITCOIN_PRICE_REQUEST,BITCOIN_PRICE_CHART_REQUEST} from "./action-types"

export function bitcoinsuccessSuccess(payload) {
    return { type: BITCOIN_PRICE_REQUEST, payload: payload };
  }
 

  
  export const fetchbitcoinprice = () => {
    return function (dispatch) {
      axios
        .get("https://api.coindesk.com/v1/bpi/currentprice.json")
        .then((response) => {
          console.log(response.data);
          dispatch(bitcoinsuccessSuccess(response.data));
        })
        .catch((error) => {
        //   dispatch(bitcoinFailure());
        console.log("some error occured")
        });
    };
  };
  export function bitcoinchartSuccess(payload) {
    return { type: BITCOIN_PRICE_CHART_REQUEST, payload: payload };
  }
 

  
  export const fetchbitcoinchartprice = (a) => {
    console.log(a,"this is a ")
    return function (dispatch) {
      console.log(`https://api.coindesk.com/v1/bpi/historical/close.json?currency=${a}&start=2013-09-01&end=2013-09-10`)
      axios
        .get(`https://api.coindesk.com/v1/bpi/historical/close.json?currency=${a}&start=2013-09-01&end=2013-09-10`)
        .then((response) => {
          console.log(response.data);
          dispatch(bitcoinchartSuccess(response.data,"THIS IS RESPONSE"));
        })
        .catch((error) => {
        //   dispatch(bitcoinFailure());
        console.log("some error occured")
        });
    };
  };