import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { addTables } from "../store/action";
import { addSeats } from "../store/action";

class AddTables extends Component {
	constructor(props) {
		super(props);
		this.state = {
			addTables: 0,
			addSeats: 0,
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};

	addTabless = (e) => {
		e.preventDefault();
		// let { dispatch } = this.props;
		this.props.dispatch(addTables(this.state.addTables * this.state.addSeats));
		this.props.dispatch(addSeats(this.state.addSeats));
		this.props.history.push("/");
	};

	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Add Tables
							<TextField
								id="outlined-basic"
								type="number"
								name="addTables"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Add seats at one table
							<TextField
								id="outlined-basic"
								type="number"
								name="addSeats"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<Button
						type="button"
						variant="contained"
						onClick={this.addTabless}
						color="primary"
					>
						Add Tables
					</Button>
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		tableadd: state,
	};
};
export default connect(mapStateToProps)(AddTables);
