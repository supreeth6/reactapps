import React, { Component } from "react";
import { connect } from "react-redux";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import { InputLabel, MenuItem } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import { reduceseats } from "../store/action";

class Orderfood extends Component {
	constructor(props) {
		super(props);
		this.state = {
			dishes: "",
			noofPeople: 0,
			quantities: "",
			orderedThing: [],
			dish: [],
		};
	}

	HandleChange = (event) => {
		console.log(event.target.value);
		this.setState({
			[event.target.name]: event.target.value,
		});
	};
	item = () => {
		this.setState({ dish: [...this.state.dish, this.state.dishes] });
	};

	HandleClick = () => {
		const orderItem = this.props.dishes.filter(
			(element) => element.name === this.state.dishes
		);
		this.props.dispatch(reduceseats(this.state.noofPeople));
		console.log(orderItem, "orderitem");
		const newList = orderItem.map((item) => {
			if (item.name === this.state.dishes) {
				console.log(item, this.state.quantities, "item");
				return {
					...item,
					addSeats: this.state.noofPeople,
					price: item.price * this.state.quantities * (18 / 100),
					timeToMake: item.timeToMake,
				};
			}
			return { ...item };
		});
		console.log(newList);
		this.setState({ orderedThing: newList });
	};
	render() {
		return (
			<div>
				<div>
					<div>
						<label>
							No of people
							<TextField
								id="outlined-basic"
								type="text"
								name="noofPeople"
								variant="outlined"
								onChange={this.HandleChange}
							/>
						</label>
					</div>
				</div>

				<div>
					<InputLabel htmlFor="age-native-simple">Dishes</InputLabel>
					<Select
						LabelId="demo-simple-select-label"
						id="demo-simple-select"
						onChange={this.HandleChange}
						name="dishes"
						fullwidth
					>
						{this.props.dishes.map((element) => (
							<MenuItem value={element.name}>{element.name}</MenuItem>
						))}
					</Select>
					<div>{this.props.tables}</div>
					{/* {Number(this.props.tables) - Number(this.state.noofPeople) * Number()} */}
				</div>
				<div>
					<button onClick={this.item}>AddMoreItem</button>
					<div>
						{this.state.dish
							? this.state.dish.map((element) => {
									return <div>{element}</div>;
							  })
							: " "}
					</div>
				</div>
				<div>
					<div>
						<label>
							Quantities
							<TextField
								id="outlined-basic"
								type="text"
								name="quantities"
								variant="outlined"
								onChange={this.HandleChange}
							/>
						</label>
					</div>
				</div>
				<Button
					onClick={this.HandleClick}
					varient="contained"
					color="secondary"
				>
					Orderfood
				</Button>
				{this.state.orderedThing.length ? (
					<div>
						<p>Total cost:{this.state.orderedThing[0].price}</p>
						<p>Total Time:{this.state.orderedThing[0].timeToMake}min</p>
					</div>
				) : (
					""
				)}
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	console.log(state);
	return {
		dishes: state.dishes,
		tables: state.tables,
		// seats:state.seats
	};
};

export default connect(mapStateToProps)(Orderfood);
