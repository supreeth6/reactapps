import React, { Component } from "react";
import { connect } from "react-redux";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
// import adding from "../actions/actioning";
// import addingseats from "../actions/actioning";
import { addDishes } from "../store/action";

class Addmenu extends Component {
	constructor(props) {
		super(props);
		this.state = {
			name: "",
			price: "",
			timeToMake: "",
			// addTables: "",
			// addSeats: "",
		};
	}
	handleChange = (e) => {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			...this.state,
			[name]: value,
		});
	};
	// handleChangeone = (e) => {
	// 	let name = e.target.name;
	// 	let value = e.target.value;
	// 	this.setState({
	// 		detail: {
	// 			...this.state.noofseats,
	// 			[name]: value,
	// 		},
	// 	});
	// };
	addMenu = (e) => {
		e.preventDefault();
		// let { dispatch } = this.props;
		this.props.dispatch(addDishes(this.state));
		this.props.history.push("/");
	};
	// addseats = (e) => {
	// 	e.preventDefault();
	// 	let { dispatch } = this.props;
	// 	dispatch(addingseats("ADD_SEATS", this.state.noofseats));
	// };
	render() {
		return (
			<form>
				<div>
					<div>
						<label>
							Name
							<TextField
								id="outlined-basic"
								type="text"
								name="name"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Price
							<TextField
								id="outlined-basic"
								type="number"
								name="price"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Time
							<TextField
								id="outlined-basic"
								type="text"
								name="timeToMake"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					{/* <div>
						<label>
							Add Tables
							<TextField
								id="outlined-basic"
								type="text"
								name="addTables"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div>
					<div>
						<label>
							Add seats
							<TextField
								id="outlined-basic"
								type="text"
								name="addSeats"
								variant="outlined"
								onChange={this.handleChange}
							/>
						</label>
					</div> */}
					<Button
						type="button"
						variant="contained"
						onClick={this.addMenu}
						color="primary"
					>
						Add Menu
					</Button>
					{/* <Button
						type="button"
						variant="contained"
						onClick={this.addseats}
						color="primary"
					>
						Add seats
					</Button> */}
				</div>
			</form>
		);
	}
}
const mapStateToProps = (state) => {
	console.log("sdfghj", state);
	return {
		menuadd: state,
	};
};
export default connect(mapStateToProps)(Addmenu);
