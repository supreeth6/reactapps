import React, { Component } from "react";
import { Link } from "react-router-dom";
import { AppBar } from "@material-ui/core";

export default class HomePage extends Component {
	render() {
		return (
			<div>
				<AppBar
					style={{
						color: "white",
					}}
				>
					<Link style={{ color: "white" }} to="/Addmenu">
						Adding Menu
					</Link>
					<Link style={{ color: "white" }} to="/Orderfood">
						Food ordering
					</Link>
					<Link style={{ color: "white" }} to="/AddTables">
						Add Tables
					</Link>
				</AppBar>
			</div>
		);
	}
}
