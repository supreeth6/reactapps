import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
// import Button from "@material-ui/core/Button";
import Addmenu from "../components/Addmenu";
import Orderfood from "../components/Orderfood";
import AddTables from "../components/AddTables";
import HomePage from "../components/HomePage";

export default class Routes extends Component {
	render() {
		return (
			<div>
				<AppBar position="static">
					<Toolbar>
						<Typography variant="h6">Restorent Booking Management</Typography>
					</Toolbar>
				</AppBar>
				<AppBar position="static" color="default">
					<Router>
						{/* <ul>
							<li>
								<Link to="/Addmenu">Addmenu</Link>
							</li>
							<li>
								<Link to="/Orderfood">OrderFood</Link>
							</li>
							<li>
								<Link to="/Billing">Billing</Link>
							</li>
						</ul> */}
						<Switch>
							{/* <Route exact path="/" component={Login}></Route> */}
							<Route exact path="/" component={HomePage}></Route>
							<Route exact path="/Addmenu" component={Addmenu}></Route>
							<Route exact path="/Orderfood" component={Orderfood}></Route>
							<Route exact path="/AddTables" component={AddTables}></Route>
						</Switch>
					</Router>
				</AppBar>
			</div>
		);
	}
}
