const initialState = {
	dishes: [],
	tables: 0,
	seats: 0,
};

const reducer = (state = initialState, action) => {
	// eslint-disable-next-line
	console.log(action, state);

	switch (action.type) {
		case "ADD_DISHES":
			return {
				...state,
				dishes: [...state.dishes, action.details],
			};
		case "ADD_TABLES":
			return {
				...state,
				tables: Number(state.tables) + Number(action.detailone),
			};
		case "ADD_SEATS":
			return {
				...state,
				seats: Number(state.seats) + Number(action.detailtwo),
			};
		case "SUBTRACT_SEATS":
			return {
				...state,
				seats: Number(state.seats) - Number(action.detailthree),
			};
	}
};
export default reducer;
