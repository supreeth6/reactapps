export const addDishes = (details) => {
	console.log(details);
	return {
		type: "ADD_DISHES",
		details: details,
	};
};
// export default addDishes;

export const addTables = (detailone) => {
	console.log(detailone);
	return {
		type: "ADD_TABLES",
		detailone: detailone,
	};
};

export const addSeats = (detailtwo) => {
	console.log(detailtwo);
	return {
		type: "ADD_SEATS",
		detailtwo: detailtwo,
	};
};
export const reduceseats = (detailthree) => {
	console.log(detailthree);
	return {
		type: "SUBTRACT_SEATS",
		detailthree: detailthree,
	};
};
